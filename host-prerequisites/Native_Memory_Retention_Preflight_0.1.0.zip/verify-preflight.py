#!/usr/bin/env python3
"""Offline integrity/boundary checks; Node execution is reported separately."""
from pathlib import Path
import hashlib
import io
import json
import zipfile

root = Path(__file__).resolve().parent
digest = lambda data: hashlib.sha256(data).hexdigest()
manifest = json.loads((root / 'MANIFEST.json').read_text())
for name, expected in manifest.items():
    target = (root / name).resolve()
    assert target.is_relative_to(root), name
    data = target.read_bytes()
    assert len(data) == expected['bytes'] and digest(data) == expected['sha256'], name

candidate = (root / 'Host_Save_Binding_0.1.0-rc.1_Source.zip').read_bytes()
assert digest(candidate) == '733156af7682f7f5f0e8e19145235f89a30179e9736654ade099877f45fff8bf'
with zipfile.ZipFile(io.BytesIO(candidate)) as z:
    source_manifest = json.loads(z.read('FILE_MANIFEST.json'))
    # The canonical manifest shape is checked without assuming its ordering.
    for name, entry in source_manifest.items():
        data = z.read(name)
        assert len(data) == entry['bytes'] and digest(data) == entry['sha256'], name
    files = json.loads(z.read('CANDIDATE_FILES.json'))
    assert len(files) == 5 and len(source_manifest) == 44
    for name, entry in files.items():
        assert digest(z.read('candidate/' + name)) == entry['candidateSHA256']
        if entry['baseSHA256']:
            assert digest(z.read('baseline/' + name)) == entry['baseSHA256']
    assert len(z.read('save-binding.patch').splitlines()) == 302
    assert len(z.read('candidate/scripts/regressions/agent-run-swipe-binding.regression.ts').splitlines()) == 179

for index_name, folder in [('SOURCE_INDEX.json', 'source-c565014'), ('V2_5_1_SOURCE_HASHES.json', 'source-v2.5.1')]:
    for name, expected in json.loads((root / index_name).read_text()).items():
        data = (root / folder / name).read_bytes()
        assert len(data) == expected['bytes'] and digest(data) == expected['sha256'], name

for folder in ['source-c565014', 'source-v2.5.1']:
    context = (root / folder / 'packages/server/src/services/generation/advanced-memory-context.ts').read_text()
    ltm = (root / folder / 'packages/server/src/services/generation/long-term-memory-runtime.ts').read_text()
    assert 'Optional recall omitted to fit the complete formatted request.' in context
    assert 'Long-term memory recall failed; continuing without recalled context' in ltm
storage = (root / 'source-v2.5.1/packages/server/src/services/storage/agents.storage.ts').read_text()
save_input = storage.split('async saveRun(input: {', 1)[1].split('}) {', 1)[0]
assert 'swipeIndex' not in save_input
assert 'swipeIndex: message?.activeSwipeIndex ?? null' in storage

receipt = json.loads((root / 'VERIFICATION.json').read_text())
assert receipt['runtimeChanged'] is False and receipt['liveStateChanged'] is False
assert all(item['exitCode'] == 0 for item in receipt['executedSuites'])
probe_text = (root / 'logs/native-memory-boundaries.log').read_text()
probe = json.loads(probe_text[probe_text.index('{'):])
assert probe['pass'] is True and probe['groups'] == 6 and probe['paidProviderCalls'] == 0
print(json.dumps({
    'pass': True, 'packageFilesVerified': len(manifest),
    'originalCandidateManifestFiles': len(source_manifest), 'candidateFiles': len(files),
    'pinnedNativeSourceFiles': len(json.loads((root / 'SOURCE_INDEX.json').read_text())),
    'v2_5_1SourceFiles': 4,
    'recordedHostSuitesPassed': len(receipt['executedSuites']), 'recordedFocusedGroupsPassed': probe['groups'],
    'runtimeChanged': False, 'liveStateChanged': False,
    'executionScope': 'Python artifact/boundary checks executed. Node results are verified supplied receipts, not rerun by this script.'
}, indent=2))
