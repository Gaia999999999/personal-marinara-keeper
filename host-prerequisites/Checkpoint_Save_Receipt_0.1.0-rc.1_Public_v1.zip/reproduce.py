"""Run explicitly chosen synthetic checks with logs; never installs dependencies."""
import argparse
import datetime
import json
import os
from pathlib import Path
import subprocess
import sys

parser=argparse.ArgumentParser()
parser.add_argument('lane',choices=['baseline-proof','baseline-red','focused','related','full'])
parser.add_argument('--host',required=True,type=Path)
args=parser.parse_args()
host=args.host.resolve()
assert (host/'packages/server/node_modules/tsx/dist/loader.mjs').exists(), 'Restore frozen development dependencies first; see START_HERE.md.'
node=['node','--import','./packages/server/node_modules/tsx/dist/loader.mjs']
suites=['checkpoint-save-receipt','checkpoint-durable-storage'] if args.lane=='focused' else [
 'agent-run-swipe-binding','agent-previous-output','capability-agent-runtime',
 'capability-persistence-permissions','agent-retry-batching','agent-runtime','generation-output','file-backed-shutdown','tracker-sections']
if args.lane in ['baseline-proof','baseline-red']: suites=['checkpoint-save-receipt']
commands=[node+[f'scripts/regressions/{name}.regression.ts'] for name in suites]
if args.lane=='full': commands=[['pnpm.cmd' if os.name=='nt' else 'pnpm','check']]
environment=os.environ.copy()
if args.lane=='baseline-proof': environment['REPRODUCE_BASELINE']='1'
else: environment.pop('REPRODUCE_BASELINE',None)
out=host.parent/('receipt-reproduction-'+datetime.datetime.now().strftime('%Y%m%d-%H%M%S-%f'))
out.mkdir()
temp=out/'temporary-fixtures'
temp.mkdir()
environment['TMP']=environment['TEMP']=environment['TMPDIR']=str(temp)
results=[]
for index,command in enumerate(commands):
    with (out/f'{index:02d}.log').open('x',encoding='utf-8') as log:
        result=subprocess.run(command,cwd=host,env=environment,stdout=log,stderr=subprocess.STDOUT)
    record=dict(command=command,exitCode=result.returncode)
    results.append(record)
    print(json.dumps(record),flush=True)
(out/'RESULTS.json').write_text(json.dumps(results,indent=2),encoding='utf-8')
print('Actual reproduction logs:',out)
sys.exit(any(r['exitCode'] for r in results))
