"""Verify public package integrity and provenance; never reruns implementation tests."""
import argparse
import difflib
import hashlib
import json
from pathlib import Path
import re
import tarfile

parser = argparse.ArgumentParser()
parser.add_argument('--source-archive', type=Path)
args = parser.parse_args()
root = Path(__file__).resolve().parent
def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()
manifest = json.loads((root/'MANIFEST.json').read_text(encoding='utf-8'))
assert not any(name.endswith(('.zip', '.tar.gz', '.tgz')) for name in manifest), 'Nested source archives are not needed.'
for name, expected in manifest.items():
    path = (root/name).resolve()
    assert path.is_relative_to(root.resolve()) and path.is_file(), name
    assert path.stat().st_size == expected['bytes'] and sha(path) == expected['sha256'], name
    if name.startswith('evidence/'):
        text = path.read_text(encoding='utf-8')
        assert not re.search(r'(?<![\w])[A-Za-z]:[\\/]', text), 'Absolute local drive path in evidence.'
        assert not re.search(r'/(?:home|Users|tmp)/', text), 'Absolute local home/temp path in evidence.'
identities = json.loads((root/'SOURCE_IDENTITIES.json').read_text(encoding='utf-8'))
f2 = json.loads((root/'inputs/F2_CANDIDATE_FILES.json').read_text(encoding='utf-8'))
for name, info in f2.items():
    assert sha(root/'f2-overlay'/name) == info['candidateSHA256'], name
patch = []
for name, info in identities['receiptCandidateFiles'].items():
    target = root/'candidate'/name
    assert sha(target) == info['candidateSHA256'], name
    old = (root/'f2-overlay'/name).read_bytes() if info['baselineSHA256'] else b''
    if old:
        assert hashlib.sha256(old).hexdigest() == info['baselineSHA256'], name
    patch.extend(difflib.unified_diff(old.decode().splitlines(True), target.read_bytes().decode().splitlines(True),
                 fromfile='a/'+name if old else '/dev/null', tofile='b/'+name))
assert ''.join(patch).encode() == (root/'receipt-repair.patch').read_bytes(), 'Patch/source mismatch.'
ledger = json.loads((root/'EVIDENCE_PROVENANCE.json').read_text(encoding='utf-8'))
for entry in ledger['files']:
    path = root/entry['publicFile']
    assert sha(path) == entry['publicSHA256']
    assert (entry['originalSHA256'] != entry['publicSHA256']) == entry['bytesChanged']
verification = json.loads((root/'evidence/VERIFICATION.json').read_text(encoding='utf-8'))
assert verification['fullHostCheck']['exitCode'] == 0
assert verification['trackerBaselineLimitation']['baseline']['exitCode'] == 1
assert verification['trackerBaselineLimitation']['candidate']['exitCode'] == 1
source_verified = False
if args.source_archive:
    reference = json.loads((root/'PUBLIC_SOURCE_REFERENCES.json').read_text(encoding='utf-8'))['upstreamHost']
    assert args.source_archive.stat().st_size == reference['bytes'] and sha(args.source_archive) == reference['sha256']
    with tarfile.open(args.source_archive) as tar:
        prefix = 'Marinara-Engine-' + reference['commit'] + '/'
        for name, info in f2.items():
            if info['baseSHA256']:
                assert hashlib.sha256(tar.extractfile(prefix+name).read()).hexdigest() == info['baseSHA256'], name
    source_verified = True
print(json.dumps(dict(packageIntegrity=True, manifestFiles=len(manifest), evidenceProvenance=True,
  candidateAndF2Hashes=True, patchMatches=True, pinnedExternalArchiveVerified=source_verified,
  runtimeTestsRerun=False), indent=2))
