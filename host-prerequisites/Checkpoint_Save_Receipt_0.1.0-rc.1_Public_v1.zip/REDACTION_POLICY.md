# Public evidence transformation

Files under `evidence` are copies of previously recorded evidence. No tests were executed to manufacture new evidence for this packaging change.

- Local project roots become `{WORKSPACE}`; account home roots become `{USER_HOME}`.
- Local interpreter and executable roots become `{PYTHON_RUNTIME}` and `{NODE_RUNTIME}`.
- Sandbox/temp roots become `{SANDBOX_TEMP}` or `{ABSOLUTE_PATH}`. Standalone local account identifiers become `{LOCAL_ACCOUNT}` if present.
- Source-relative paths, route names, file/line references outside the replaced root, exit codes, pass/failure classifications, source SHA-256 values, numeric measurements and timestamps are retained. Windows separators in the remaining relative suffix may remain visible.
- JSON receipts are parsed before/after redaction to verify every numeric/boolean/null value is unchanged, object keys/array lengths match, and every string is either unchanged or exactly the stated path/account transformation. Original formatting is retained; no JSON reserialization is needed.
- Logs are transformed only by the listed path/account substitutions. They are explicitly labeled redacted copies; no claim of byte identity applies when any substitution changes their bytes.

EVIDENCE_PROVENANCE.json identifies each original full-ZIP member, original size/SHA-256, public member, public size/SHA-256, modification status and redaction counts by category. Counts do not disclose the removed identifiers. The original full ZIP and source checkpoints are preserved unchanged. The public manifest describes public bytes; it does not replace the original artifact's manifest.

Candidate, regression, F2 and patch bytes are copied unchanged and checked against their existing source identities. Public source references and this package's documentation are newly authored packaging metadata. The bundled LICENSE and applicable source notices are retained.
