# Checkpoint Save Receipt — compact public source package

This is a packaging-only public edition of the existing review candidate. No implementation, regression assertions, candidate files, or source hashes changed. No implementation or expensive regression checks were repeated for this publication change. Independent Argon review remains required; no installation or promotion is authorized.

The complete original `Checkpoint_Save_Receipt_0.1.0-rc.1_Audit_v2.zip` remains unchanged locally for Argon's independent audit. Its bytes/SHA-256 are recorded in PUBLIC_SOURCE_REFERENCES.json. This compact edition omits the large upstream archive, the supplied independent report, and the unchanged native runtime ZIP. It includes the exact necessary candidate and F2 overlay, patch, regressions, license, audit instructions, labeled evidence copies and reproduction tools.

## Evidence is labeled, not silently replaced

Read EVIDENCE_PROVENANCE.json and REDACTION_POLICY.md. Files under `evidence` are public derivatives of previously executed test evidence; local paths/accounts are replaced by neutral markers. Their original and public hashes are distinct where bytes changed. Test outcomes, exit codes, timings, timestamps, source hashes and pass/failure text remain unchanged apart from path/account substitution. No redacted log is described as byte-identical to its original. The original raw evidence remains inside the unchanged full audit ZIP.

Prior full host check and ten relevant suites passed on the existing candidate. The broader tracker-sections test fails identically on unchanged F2 and candidate at WORLD_SENTINEL placement, line 201; it remains a baseline limitation, not a pass. Environment-limited attempts are retained with their failures. Consult evidence/VERIFICATION.json and LIMITATIONS.md.

## Pinned public reproduction

The upstream archive is publicly available, 103,585,597 bytes, SHA-256 `4b2a3b305b7a7d9afa6100517a0af841858ea38a8ab659ecac8fdb6260821382`, at exact Marinara commit `c56501495a8baf76c258e76534c8728a9b7859bb`. PUBLIC_SOURCE_REFERENCES.json supplies the immutable codeload download URL, repository URL, source identities and AGPL-3.0 provenance.

From a fresh unpacked public package:

1. Run `python verify-package.py` to verify the public manifest, evidence provenance, F2/candidate hashes, and exact patch/source agreement. This executes no runtime regressions.
2. Obtain the pinned public source using `python fetch-source.py source-cache/marinara-c565014.tar.gz`, or supply an already downloaded exact archive. The helper verifies byte count/SHA-256 before saving and refuses to overwrite an existing destination.
3. Run `python verify-package.py --source-archive source-cache/marinara-c565014.tar.gz` to verify the external archive and exact F2 baseline inputs.
4. Reconstruct new disposable source trees with `python prepare-host.py baseline work/baseline --source-archive source-cache/marinara-c565014.tar.gz` and the equivalent command with `candidate work/candidate`. Existing destinations are rejected. The complete pinned upstream tree is reconstructed, then the bundled exact F2 overlay and candidate are applied.
5. In each reconstructed checkout, use Node 24 and the host's hash-pinned pnpm from package.json. Restore dependencies with `pnpm install --frozen-lockfile --ignore-scripts`, then run `pnpm --filter @marinara-engine/shared build`. The source archive supplies the frozen lockfile/build metadata. Registry access or a dependency cache is required; offline dependency restoration is not promised.
6. Optional independent reviewer execution: `python reproduce.py baseline-proof --host work/baseline`, `python reproduce.py baseline-red --host work/baseline` (expected contract failure), and `python reproduce.py focused --host work/candidate`. Use `related` or `full` for broader checks if needed. All fixture completions are synthetic; generation-output/tracker tests require local loopback access. No owner data or paid credentials should be used. These commands have not been rerun merely for public packaging.

Read ARGON_BRIEF.md for the exact adversarial review scope. The original full package remains the unchanged handoff for the existing independent Argon audit gate; this public edition does not supersede that audit artifact.
