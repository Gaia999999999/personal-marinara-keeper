# Native Memory Retention Preflight 0.1.0

A reproducible evidence package and proposed retention contract. It is not an installable Keeper release, a host update, or a completed archive implementation.

## Offline checks

Unpack, then run `python3 verify-preflight.py`. This needs Python's standard library only. It validates package/source identities, the exact original candidate and current-version boundary evidence. Node test logs are supplied evidence; the Python checker does not pretend to rerun Node.

## Runtime probes

Use an isolated checkout of Marinara commit `c56501495a8baf76c258e76534c8728a9b7859bb`. Unpack the included Host_Save_Binding_0.1.0-rc.1_Source.zip and follow its README to apply the exact candidate, install pinned dependencies and build shared. Do not point any command at an owner's running installation or data.

From this unpacked folder, set HOST_ROOT to that isolated checkout and run with Node 24 / pnpm 10.34.5 dependencies:

```bash
HOST_ROOT=/absolute/path/to/isolated-host node --import /absolute/path/to/isolated-host/packages/server/node_modules/tsx/dist/loader.mjs native-memory-boundaries.mjs
```

If this environment cannot enumerate NICs, add `--import ./headless-host-env.mjs` before the loader. That helper substitutes an empty inventory only for ERR_SYSTEM_ERROR.

From the isolated host root run each included upstream suite using:

```bash
node --import ./packages/server/node_modules/tsx/dist/loader.mjs scripts/regressions/advanced-memory-context.regression.ts
```

Repeat for advanced-memory-recall, advanced-memory-audience, advanced-memory-core and memory-recall-exclusivity. Their supplied source copies are byte-identical to the pinned host. These tests use temporary synthetic data and local mock providers. The six-group boundary probe supplies synthetic prepared recall/service responses while exercising actual host request assembly, LTM fallback, fingerprints and metadata remapping. It makes no provider calls.

The host source files included under source-c565014 are review excerpts by file, not a complete runnable host checkout. source-v2.5.1 contains four exact fetched files from commit `8042ef6ec638801de45b8d82f82cd2dea85f51a4`; they are **source-inspected only**, not mixed into the executable c565014 tree. See SOURCE_INDEX.json and V2_5_1_SOURCE_HASHES.json. Host code and upstream tests remain AGPL-3.0; LICENSE is included.

No live/private chat or checkpoint export is included. Retained campaign state remains unchanged. This public package cannot independently replay private campaign records and does not claim to.
