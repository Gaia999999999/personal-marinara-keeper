"""Reconstruct exact baseline or candidate from a hash-verified public source archive."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import tarfile

parser = argparse.ArgumentParser()
parser.add_argument('lane', choices=['baseline', 'candidate'])
parser.add_argument('destination', type=Path)
parser.add_argument('--source-archive', required=True, type=Path)
args = parser.parse_args()
root = Path(__file__).resolve().parent
dest = args.destination.resolve()
assert not dest.exists(), 'Destination must not exist; existing files are never overwritten.'
reference = json.loads((root/'PUBLIC_SOURCE_REFERENCES.json').read_text(encoding='utf-8'))['upstreamHost']
assert args.source_archive.stat().st_size == reference['bytes']
with args.source_archive.open('rb') as stream:
    assert hashlib.file_digest(stream, 'sha256').hexdigest() == reference['sha256']
identities = json.loads((root/'SOURCE_IDENTITIES.json').read_text(encoding='utf-8'))
dest.mkdir(parents=True)
with tarfile.open(args.source_archive) as tar:
    prefix = 'Marinara-Engine-' + reference['commit'] + '/'
    for entry in tar.getmembers():
        if entry.isdir():
            continue
        assert entry.isfile() and entry.name.startswith(prefix), entry.name
        target = (dest/entry.name[len(prefix):]).resolve()
        assert target.is_relative_to(dest), 'Unsafe upstream archive member.'
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open('xb') as stream:
            stream.write(tar.extractfile(entry).read())
for overlay in ['f2-overlay'] + (['candidate'] if args.lane == 'candidate' else []):
    for source in (root/overlay).rglob('*'):
        if source.is_file():
            target = dest/source.relative_to(root/overlay)
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(source.read_bytes())
if args.lane == 'baseline':
    for name in ['checkpoint-save-receipt.regression.ts', 'checkpoint-durable-storage.regression.ts']:
        relative = Path('scripts/regressions')/name
        shutil.copyfile(root/'candidate'/relative, dest/relative)
for name, info in identities['receiptCandidateFiles'].items():
    expected = info['candidateSHA256'] if args.lane == 'candidate' or info['baselineSHA256'] is None else info['baselineSHA256']
    assert hashlib.sha256((dest/name).read_bytes()).hexdigest() == expected, name
print('Reconstructed and verified ' + args.lane + '; no runtime tests or dependency installation performed.')
