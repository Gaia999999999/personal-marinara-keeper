# Proposed native-assisted retention contract — for adversarial review

Status: proposed contract, backed by executable host probes; not installed or implemented. Current runtime remains strict Keeper 4.1.11 plus the unchanged reviewed Host Save-Binding 0.1.0-rc.1 source candidate.

## Owners and authority

1. **Active Keeper checkpoint** owns current custody/status, quiet cast, relationships and their still-governing causes, private access/exclusions, unresolved plans, standing corrections/directives and downstream route/return/evacuation conditions. The current 22,000-character and per-group row limits remain enforced until a reviewed lifecycle change is implemented. No condition is retired because the immediate tactical leg or scene changed.
2. **Exact cold history** must preserve every deliberately removed accepted record, its identity, authority/provenance, audiences/exclusions, negation/conditions and successor links. Proposed backing: already persisted native Keeper run snapshots, verified by exact content hash and selected-history lineage, not newly summarized prose and not merely a mutable run ID. This reuses existing storage only if the host can guarantee reachability and explicit failure on missing or changed snapshots.
3. **Native Advanced Memory** can select historical scenes/excerpts for prose. Its summaries and relevance scores have no authority to close a plan, grant character knowledge, alter a relationship, delete a row, or create current evidence. Its own transfers and audience checks remain in effect. Normal semantic recall and the Long-Term Memory agent are separate components, not automatically enabled companions.

## Proposed transaction boundary

- A future lifecycle proposal identifies exact existing records, not arbitrary free-text paraphrases. It supplies a complete destination for every necessary field and dependency. Only explicit, evidence-supported closure or a separately validated equivalent active representation can justify ceasing to keep a record active. “Old”, “completed”, an audience subset, or model confidence alone is insufficient.
- Before any removal, the host must return the exact accepted predecessor snapshot and prove that it belongs to the selected message/swipe lineage and current agent/chat. The runtime verifies its complete hash and domain equality. Current `context.loadPreviousOutput` alone does not supply this new contract.
- A future accepted active checkpoint would contain a bounded root reference to the verified exact historical snapshot and any earlier reachable root. Publishing active state and that reference must be one native result publication. No external mutable document is made authoritative merely because finalization ran.
- Missing snapshot, hash mismatch, wrong scope, ambiguous lineage, stale selection, partial successor chain, unsupported import mapping, or failed save must reject without replacing the previous checkpoint. No fallback to the latest run, prose identity, fuzzy anchors or a fabricated seed.
- Native rows are not currently immutable: same run ID can be updated, and messages/runs can be removed. The implementation must either protect referenced snapshot versions through a supported host retention contract or detect invalidation and block dependent work. The audit must determine whether reusing this store is actually simpler and sufficient; it must not assume that “already saved” means immutable forever.
- A new active/history envelope would be a substantive storage change, not a cosmetic encoding trick. Character/row caps must not be silently reinterpreted to hide active facts outside the cap. Exact historical bytes may grow on disk; claim only bounded active context when justified, never bounded total history or unlimited simultaneous active obligations.

## Pre-prose and knowledge requirements

- Governing causes and constraints must be present in the active spine without depending on optional recall. A character may appreciate a rescue while retaining unresolved resentment about an earlier abandonment. Neither a current stance label nor occasional retrieval is a sufficient substitute for that causal condition.
- If any active transition or prompt depends on a cold record, that dependency needs exact resolution before it can be used. A mandatory dependency failure must stop the dependent generation; the current optional prompt contributor / memory fallback contracts do not provide this guarantee.
- Optional episode recall may fail or be omitted only when it is not carrying a governing active fact. Do not claim semantic certainty about arbitrary historical questions when the relevant source was not retrieved.
- Historical receipt access cannot confer new in-world access. Preserve original known_by/not_known_by and distinguish narrator visibility, a character remembering their own experience, a heard claim, and grounded disclosure. Dormancy is not evidence of closure or permission to forget.
- Native memories remain advisory context for prose. Keeper's current evidence catalog and source-currentness requirements must not treat a recalled historical quote as a newly performed action or current disclosure.

## Lifecycle and portability

- Required before release: two identical-text sibling swipes; branch before/after a cold root; accepted successor after a branch; delayed/failed publication; deleted/overwritten/missing historical run; selected-swipe switch; altered source content; changed agent/chat; imported reminted IDs with a validated mapping; unsupported/missing mapping; exact export/import round trip of all reachable history.
- Native Advanced Memory transfer tests prove only its own records. They do not certify this proposed Keeper graph. No installation, migration or seed replacement follows merely from native export support.
- A first supported release should restrict lifecycle operations to the narrow verified class it can preserve exactly. Do not enable model-authored arbitrary retire, semantic coalescing, eviction or broad scene rollups as a shortcut.

## Mandatory acceptance battery for any later runnable candidate

1. The actual downstream evacuation/route rewrite case must retain every unresolved clause and its audience.
2. Near-cap active state; second new obligation at capacity rejects atomically; no quiet-cast or active-directive loss.
3. Exact historical record round trip, including original provenance, audience/exclusions, conditional/negated facts, beliefs and linked successors.
4. A rescue changes only supported relationship dimensions; no automatic trust, forgiveness, disclosure or cancellation of prior grievance.
5. Cold record missing/tampered/stale/wrong-lineage cases; no alternative-root fallback; no new active publication on rejection.
6. Required historical dependency failure blocks dependent prose/updates; optional episode omission leaves all active pins intact.
7. Native memory off, failure, retrieval miss, wrong-audience scene, changed-source fingerprint and budget truncation cannot authorize retirement or grant knowledge.
8. Save-binding, author-correction, strict evidence/currentness, #23 compatibility, atomic rejection and all current caps continue passing.
9. Native export/import/branch mapping and successor-chain recovery are exercised end-to-end against exact supported host versions.

These are gates for a later implementation, not tests this preflight claims to pass. The six new executable probes establish existing host boundaries only.
