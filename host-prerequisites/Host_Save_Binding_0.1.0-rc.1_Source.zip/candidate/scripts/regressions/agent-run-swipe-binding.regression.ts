import assert from "node:assert/strict";
import { mkdtempSync, rmSync } from "node:fs";
import { createRequire } from "node:module";
import { tmpdir } from "node:os";
import { join } from "node:path";
const dir = mkdtempSync(join(tmpdir(), "marinara-save-binding-"));
process.env.DATA_DIR = dir;
process.env.FILE_STORAGE_DIR = join(dir, "storage");
process.env.NODE_ENV = "test";
process.env.MARINARA_LITE = "true";
process.env.LOG_LEVEL = "silent";
const requireServer = createRequire(new URL("../../packages/server/package.json", import.meta.url));
const Fastify = requireServer("fastify");
const { getDB, closeDB } = await import("../../packages/server/src/db/connection.js");
const { generateRoutes } = await import("../../packages/server/src/routes/generate.routes.js");
const { createChatsStorage } = await import("../../packages/server/src/services/storage/chats.storage.js");
const { createAgentsStorage } = await import("../../packages/server/src/services/storage/agents.storage.js");
const { createConnectionsStorage } = await import("../../packages/server/src/services/storage/connections.storage.js");
const { createPromptsStorage } = await import("../../packages/server/src/services/storage/prompts.storage.js");
const { OpenAIProvider } = await import("../../packages/server/src/services/llm/providers/openai.provider.js");
const { registerCapabilityService } =
  await import("../../packages/server/src/services/capability-packages/capability-service-registry.service.js");
const { agentRuns, messages } = await import("../../packages/server/src/db/schema/index.js");
const originalChat = OpenAIProvider.prototype.chat;
const originalComplete = OpenAIProvider.prototype.chatComplete;
OpenAIProvider.prototype.chat = async function* () {
  yield "Identical reply.";
};
OpenAIProvider.prototype.chatComplete = async () => ({
  content: "Identical reply.",
  toolCalls: [],
  finishReason: "stop",
  usage: { promptTokens: 1, completionTokens: 1, totalTokens: 2 },
});
const db = await getDB();
const chats = createChatsStorage(db);
const agents = createAgentsStorage(db);
const app = Fastify();
app.decorate("db", db);
app.decorate("activeGenerations", new Map());
await app.register(generateRoutes, { prefix: "/api/generate" });
let finalizations = 0;
let target = "";
let selectAfterFinalize = 1;
const release = registerCapabilityService("agent-runtime:save-binding", {
  prepareContext: () => ({ fixture: true }),
  finalizeResult: async ({ result }: any) => {
    const replies = (await db.select().from(messages)).filter((m) => m.role === "assistant");
    target = replies.at(-1)!.id;
    const finalized = {
      ...result,
      success: true,
      error: null,
      type: "context_injection",
      data: { text: `CHECKPOINT_${++finalizations}`, "agent-context": `PRIVATE_${finalizations}` },
    };
    if ((await chats.getSwipes(target)).length === 1) await chats.addSwipe(target, "Identical reply.", true);
    await chats.setActiveSwipe(target, selectAfterFinalize);
    return finalized;
  },
});
try {
  const connection = await createConnectionsStorage(db).create({
    name: "Synthetic only",
    provider: "openai",
    model: "fixture",
    apiKey: "fixture",
    maxContext: 8192,
  });
  const preset = await createPromptsStorage(db).create({
    name: "Fixture",
    parameters: { maxTokens: 128 },
    wrapFormat: "xml",
  });
  const chat = await chats.create({
    name: "Save binding",
    mode: "roleplay",
    characterIds: [],
    connectionId: connection.id,
    promptPresetId: preset!.id,
  });
  const agent = await agents.create({
    type: "save-binding",
    name: "Save binding",
    phase: "post_processing",
    connectionId: connection.id,
    promptTemplate: "Return fixture",
    settings: { resultType: "context_injection", batchWithOtherAgents: false },
  });
  assert.ok(chat && agent);
  await chats.patchMetadata(chat.id, {
    enableAgents: true,
    activeAgentIds: ["save-binding"],
    enableTools: false,
    automaticSummaryEnabled: false,
  });
  const generation = await app.inject({
    method: "POST",
    url: "/api/generate",
    payload: { chatId: chat.id, userMessage: "Look around.", streaming: false },
  });
  assert.equal(generation.statusCode, 200, generation.body);
  assert.equal(finalizations, 1, generation.body);
  let runs = await db.select().from(agentRuns);
  assert.equal(runs.length, 1);
  assert.equal(runs[0].swipeIndex, 0, "ordinary route must publish to processed swipe zero");
  assert.equal(
    await agents.getPreviousOutput(agent.id, chat.id),
    null,
    "identical sibling must not inherit accepted output",
  );
  await chats.setActiveSwipe(target, 0);
  assert.equal(((await agents.getPreviousOutput(agent.id, chat.id)) as any).text, "CHECKPOINT_1");
  const retry = await app.inject({
    method: "POST",
    url: "/api/generate/retry-agents",
    payload: { chatId: chat.id, agentTypes: ["save-binding"] },
  });
  assert.equal(retry.statusCode, 200, retry.body);
  assert.equal(finalizations, 2, retry.body);
  runs = await db.select().from(agentRuns);
  assert.equal(runs.length, 2);
  assert.ok(
    runs.every((r) => r.swipeIndex === 0),
    "manual retry must retain captured target despite selection switch",
  );
  assert.equal(await agents.getPreviousOutput(agent.id, chat.id), null);
  await chats.setActiveSwipe(target, 0);
  assert.equal(((await agents.getPreviousOutput(agent.id, chat.id)) as any).text, "CHECKPOINT_2");
  await chats.setActiveSwipe(target, 1);
  selectAfterFinalize = 0;
  await app.inject({
    method: "POST",
    url: "/api/generate/retry-agents",
    payload: { chatId: chat.id, agentTypes: ["save-binding"] },
  });
  assert.equal(finalizations, 3);
  runs = await db.select().from(agentRuns);
  assert.equal(runs.at(-1)!.swipeIndex, 1);
  assert.equal(((await agents.getPreviousOutput(agent.id, chat.id)) as any).text, "CHECKPOINT_2");
  const result = {
    agentId: agent.id,
    agentType: agent.type,
    type: "context_injection",
    data: { text: "storage", "agent-context": null },
    tokensUsed: 0,
    durationMs: 0,
    success: true,
    error: null,
  };
  const input = { agentConfigId: agent.id, chatId: chat.id, messageId: target, result };
  await chats.setActiveSwipe(target, 1);
  await agents.saveRun({ ...input, swipeIndex: 0 });
  assert.equal((await db.select().from(agentRuns)).at(-1)!.swipeIndex, 0);
  await agents.saveRun(input);
  assert.equal(
    (await db.select().from(agentRuns)).at(-1)!.swipeIndex,
    1,
    "legacy omission retains active-swipe fallback",
  );
  const before = await db.select().from(agentRuns);
  for (const swipeIndex of [-1, 0.5, NaN, Infinity, Number.MAX_SAFE_INTEGER + 1, 99]) {
    await assert.rejects(agents.saveRun({ ...input, swipeIndex }));
    assert.deepEqual(await db.select().from(agentRuns), before);
  }
  await assert.rejects(agents.saveRun({ ...input, swipeIndex: 0, messageId: "missing" }));
  await assert.rejects(agents.saveRun({ ...input, swipeIndex: 0, chatId: "foreign-chat" }));
  assert.deepEqual(await db.select().from(agentRuns), before);
  console.log(
    "PASS: ordinary route, retry zero/nonzero, identical sibling isolation, explicit zero, legacy fallback, eight rejection/non-mutation controls",
  );
} finally {
  release();
  OpenAIProvider.prototype.chat = originalChat;
  OpenAIProvider.prototype.chatComplete = originalComplete;
  await app.close();
  await closeDB();
  rmSync(dir, { recursive: true, force: true });
}
