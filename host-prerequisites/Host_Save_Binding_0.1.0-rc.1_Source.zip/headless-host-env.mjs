import os from 'node:os';
import {syncBuiltinESMExports} from 'node:module';
try { os.networkInterfaces(); } catch(error) {
 if(error?.code !== 'ERR_SYSTEM_ERROR') throw error;
 os.networkInterfaces=()=>({}); syncBuiltinESMExports();
 process.stderr.write('TEST ENV: unavailable network inventory represented as empty.\n');
}
