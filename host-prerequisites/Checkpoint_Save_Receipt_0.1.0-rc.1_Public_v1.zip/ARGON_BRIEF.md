# Independent adversarial audit brief

Give a scoped PASS / REVISE / BLOCKED verdict for this exact checkpoint-save receipt candidate. Identify the inspected ZIP's byte length/SHA-256 and the source hashes. Separate checks you execute, code you inspect, and supplied logs. Do not invent fixtures, routes, storage engines, run counts, or coverage. This host uses file-native JSON storage.

Reproduce the baseline false success and challenge the actual candidate paths:

- Ordinary generation and manual retry: can a successful finalized capability receipt appear before the required run bytes are flushed? Inspect both raw SSE and the common generation-output adapter.
- Does the transaction/flush really prevent rejected inserted/replaced rows from remaining in memory or appearing on a later flush/reopen? Challenge flush failure before and after partial disk work, rollback failure, concurrent writes, and explicit target rejection. Distinguish inherited storage guarantees from new code and state any hardware/crash limits.
- Does a persistence failure yield exactly one failure with no success receipt, unsaved data, extra provider call, or automatic persistence retry? Does a subsequent explicit attempt recover correctly?
- Preserve F2's captured message/swipe binding, explicit zero/nonzero, sibling isolation, invalid targets and legacy omission. Trace historical custom read-behind ownership and note actual execution gaps.
- Check that existing runtime validation rejections and non-capability/image/lorebook/tracker paths retain their intended behavior. The selected scope is capability agents with registered result finalizers on ordinary post-processing and manual retry; do not assume every other saveRun caller or every agent effect is durable.
- Verify that the candidate makes no Keeper prompt/runtime/schema/cap/authority/audience/retention changes and that the stable native ZIP is unchanged.

Review the baseline/candidate tracker failure comparison. Do not infer it is caused by this patch, or that this patch fixes it. Challenge any candidate-specific regression using an executable sequence or a precise source trace.

The native-memory audit's CE3/H4/CR4 motivate this prerequisite. The remaining retention contracts, immutable history, cold-root lifecycle, pre-prose mandatory dependencies, import/branch mapping, and installation remain outside this candidate. The accepted F2 PASS is not reopened without a concrete new regression.

Report findings by severity with exact file/line references, expected and observed behavior, and reproduction instructions. If all focused requirements pass, explain the scope and outstanding qualifications. Do not accept the candidate on the owner's behalf, implement changes, publish artifacts, install anything into the owner's application, or make live/paid calls.
