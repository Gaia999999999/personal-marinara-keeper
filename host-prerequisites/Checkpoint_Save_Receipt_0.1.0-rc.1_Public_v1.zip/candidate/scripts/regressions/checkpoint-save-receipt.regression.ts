import assert from "node:assert/strict";
import { mkdtempSync, readFileSync, readdirSync, existsSync, rmSync } from "node:fs";
import { createRequire } from "node:module";
import { tmpdir } from "node:os";
import { join } from "node:path";

const dir = mkdtempSync(join(tmpdir(), "marinara-checkpoint-receipt-"));
process.env.DATA_DIR = dir;
process.env.FILE_STORAGE_DIR = join(dir, "storage");
process.env.NODE_ENV = "production";
process.env.MARINARA_LITE = "true";
process.env.LOG_LEVEL = "silent";
const requireServer = createRequire(new URL("../../packages/server/package.json", import.meta.url));
const Fastify = requireServer("fastify");
const { getDB, closeDB } = await import("../../packages/server/src/db/connection.js");
const { generateRoutes } = await import("../../packages/server/src/routes/generate.routes.js");
const { createChatsStorage } = await import("../../packages/server/src/services/storage/chats.storage.js");
const { createAgentsStorage } = await import("../../packages/server/src/services/storage/agents.storage.js");
const { createConnectionsStorage } = await import("../../packages/server/src/services/storage/connections.storage.js");
const { createPromptsStorage } = await import("../../packages/server/src/services/storage/prompts.storage.js");
const { OpenAIProvider } = await import("../../packages/server/src/services/llm/providers/openai.provider.js");
const { registerCapabilityService } =
  await import("../../packages/server/src/services/capability-packages/capability-service-registry.service.js");
const { agentRuns } = await import("../../packages/server/src/db/schema/index.js");
const originalChat = OpenAIProvider.prototype.chat;
const originalComplete = OpenAIProvider.prototype.chatComplete;
let providerCalls = 0;
OpenAIProvider.prototype.chat = async function* () {
  providerCalls++;
  yield "Synthetic reply.";
};
OpenAIProvider.prototype.chatComplete = async () => {
  providerCalls++;
  return {
    content: "Synthetic reply.",
    toolCalls: [],
    finishReason: "stop",
    usage: { promptTokens: 1, completionTokens: 1, totalTokens: 2 },
  };
};
const db = await getDB();
const chats = createChatsStorage(db);
const agents = createAgentsStorage(db);
const app = Fastify();
app.decorate("db", db);
app.decorate("activeGenerations", new Map());
let fault: "none" | "write" | "flush" | "reject" = "none";
let sequence = 0;
let writes = 0;
let flushes = 0;
let armed = false;
let receipts: any[] = [];
const insert = db.insert.bind(db);
const flush = db._fileStore.flush.bind(db._fileStore);
db.insert = ((table: any) => {
  if (table === agentRuns && armed) {
    writes++;
    if (fault === "write") throw new Error("Injected checkpoint write failure");
  }
  return insert(table);
}) as typeof db.insert;
db._fileStore.flush = async () => {
  if (armed) {
    flushes++;
    if (fault === "flush") throw new Error("Injected checkpoint flush failure");
  }
  await flush();
};
function diskContains(marker: string) {
  const root = join(db._fileStore.rootDir, "tables", "agent_runs");
  if (!existsSync(root)) return false;
  return readdirSync(root)
    .filter((name) => name.endsWith(".json"))
    .some((name) => readFileSync(join(root, name), "utf8").includes(marker));
}
app.addHook("onRequest", async (_request: any, reply: any) => {
  const write = reply.raw.write.bind(reply.raw);
  reply.raw.write = (chunk: any, ...args: any[]) => {
    for (const line of String(chunk).split("\n")) {
      if (!line.startsWith("data: ")) continue;
      const event = JSON.parse(line.slice(6));
      if (event.type === "agent_result" && event.data?.agentType === "receipt-fixture") {
        receipts.push({ ...event.data, diskHasCurrent: diskContains(`CHECKPOINT_${sequence}`), writes, flushes });
      }
    }
    return write(chunk, ...args);
  };
});
await app.register(generateRoutes, { prefix: "/api/generate" });
const release = registerCapabilityService("agent-runtime:receipt-fixture", {
  prepareContext: () => ({ fixture: true }),
  finalizeResult: ({ result }: any) => {
    sequence++;
    armed = true;
    return {
      ...result,
      success: fault !== "reject",
      error: fault === "reject" ? "Rejected proposal" : null,
      type: "context_injection",
      data: { text: `CHECKPOINT_${sequence}`, "agent-context": "PRIVATE" },
    };
  },
});
try {
  const connection = await createConnectionsStorage(db).create({
    name: "Synthetic",
    provider: "openai",
    model: "fixture",
    apiKey: "fixture",
    maxContext: 8192,
  });
  const preset = await createPromptsStorage(db).create({
    name: "Fixture",
    parameters: { maxTokens: 128 },
    wrapFormat: "xml",
  });
  const agent = await agents.create({
    type: "receipt-fixture",
    name: "Checkpoint fixture",
    phase: "post_processing",
    connectionId: connection.id,
    promptTemplate: "Return fixture",
    settings: { resultType: "context_injection", batchWithOtherAgents: false },
  });
  const chat = await chats.create({
    name: "Checkpoint receipt",
    mode: "roleplay",
    characterIds: [],
    connectionId: connection.id,
    promptPresetId: preset!.id,
  });
  await chats.patchMetadata(chat.id, {
    enableAgents: true,
    activeAgentIds: ["receipt-fixture"],
    enableTools: false,
    automaticSummaryEnabled: false,
  });
  async function request(path: "ordinary" | "retry", nextFault: typeof fault) {
    armed = false;
    await flush();
    fault = nextFault;
    writes = 0;
    flushes = 0;
    receipts = [];
    const previousCalls = providerCalls;
    const previousSequence = sequence;
    const response = await app.inject({
      method: "POST",
      url: path === "ordinary" ? "/api/generate" : "/api/generate/retry-agents",
      payload:
        path === "ordinary"
          ? { chatId: chat.id, userMessage: "Look.", streaming: false }
          : { chatId: chat.id, agentTypes: ["receipt-fixture"] },
    });
    armed = false;
    assert.equal(response.statusCode, 200, response.body);
    assert.equal(sequence, previousSequence + 1, "one finalization; no automatic retry");
    assert.equal(
      providerCalls - previousCalls,
      path === "ordinary" ? 2 : 1,
      "mocked completion count; no persistence retry",
    );
    assert.equal(receipts.length, 1, "one final receipt per finalized capability result");
    return receipts[0];
  }
  if (process.env.REPRODUCE_BASELINE === "1") {
    for (const path of ["ordinary", "retry"] as const) {
      const receipt = await request(path, "write");
      assert.equal(receipt.success, true, "baseline exposes false success");
      assert.equal(receipt.diskHasCurrent, false);
      assert.equal(receipt.writes, 0, "baseline receipt precedes save attempt");
      assert.equal((await db.select().from(agentRuns)).length, 0);
      console.log(`REPRODUCED: ${path} emits success before a swallowed write failure; no checkpoint saved`);
    }
  } else {
    for (const path of ["ordinary", "retry"] as const) {
      const success = await request(path, "none");
      assert.equal(success.success, true);
      assert.equal(success.diskHasCurrent, true, "success bytes must already be on disk at SSE emission");
      assert.equal(success.writes, 1);
      assert.equal(success.flushes, 1);
      const previous = await db.select().from(agentRuns);
      for (const nextFault of ["write", "flush"] as const) {
        const failure = await request(path, nextFault);
        assert.equal(failure.success, false);
        assert.match(failure.error, /persist|sav|checkpoint/i);
        assert.equal(failure.data, null, "unsaved proposal cannot masquerade as accepted state");
        assert.equal(failure.writes, 1, "no automatic save retry");
        assert.deepEqual(await db.select().from(agentRuns), previous, "previous checkpoint rows preserved");
        await flush();
        assert.equal(
          diskContains(`CHECKPOINT_${sequence}`),
          false,
          "later flush must not resurrect rejected checkpoint",
        );
      }
      const recovered = await request(path, "none");
      assert.equal(recovered.success, true);
      assert.equal(recovered.diskHasCurrent, true);
      const rejected = await request(path, "reject");
      assert.equal(rejected.success, false, "runtime validation rejection is retained");
      console.log(
        `PASS: ${path}: durable success, write/flush failure preservation, one failure/no retry, recovery, validation rejection`,
      );
    }
  }
} finally {
  armed = false;
  db.insert = insert;
  db._fileStore.flush = flush;
  release();
  OpenAIProvider.prototype.chat = originalChat;
  OpenAIProvider.prototype.chatComplete = originalComplete;
  await app.close();
  await closeDB();
  const resolved = dir.replaceAll("\\", "/");
  assert.ok(resolved.startsWith(tmpdir().replaceAll("\\", "/") + "/marinara-checkpoint-receipt-"));
  rmSync(dir, { recursive: true, force: true });
}
