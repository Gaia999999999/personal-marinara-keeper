// Differential runtime checks on synthetic inputs. No provider or host calls.
import assert from 'node:assert/strict';
import {makeRuntime as stable,PACKAGE_ID} from './baseline416/package/server.mjs';
import {makeRuntime as reviewedRc1} from './reviewedRc1/package/server.mjs';
import {makeRuntime as candidate} from './candidate/package/server.mjs';
import {baseline,context} from './candidate/tests/fixtures.mjs';
const agent={id:'comparison',type:PACKAGE_ID,phase:'post_processing',settings:{contextSize:24,jsonContextOutput:false}};
const results=[];
const scenarios=[
 {name:'OOC restoration with self rejects',user:'<ooc>Restore Alex earlier securing the blue kit. Only Alex knows; no new action.</ooc>',route:'self',pass:false},
 {name:'explicit author restoration accepts',user:'<ooc>Restore Alex earlier securing the blue kit. Only Alex knows; no new action.</ooc>',route:'author_correction',pass:true},
 {name:'current in-world self remains valid',user:'I alone secure the blue kit in the rear compartment.',route:'self',pass:true},
 {name:'ordinary roleplay cannot authorize author correction',user:'I alone secure the blue kit in the rear compartment.',route:'author_correction',pass:false},
 {name:'mixed current author and genuine scene self selects eligible scene',user:'<ooc>Keep the weather unchanged.</ooc> I alone secure the blue kit in the rear compartment.',route:'self',pass:true},
 {name:'extra invalid ID rejects',user:'<ooc>Restore Alex securing the blue kit; only Alex knows.</ooc>',route:'author_correction',pass:false,edit:t=>t.access[0].evidence.push('E999999')},
 {name:'evidence count remains bounded at six',user:'<ooc>Restore Alex securing the blue kit; only Alex knows.</ooc>',route:'author_correction',pass:false,edit:t=>t.access[0].evidence=Array(7).fill(t.access[0].evidence[0])},
 {name:'foreground hard bound remains 240',user:'<ooc>Restore Alex securing the blue kit; only Alex knows.</ooc>',route:'author_correction',pass:false,edit:t=>t.scene='x'.repeat(241)},
 {name:'missing recipient rejects',user:'<ooc>Restore Alex securing the blue kit; only Alex knows.</ooc>',route:'author_correction',pass:false,edit:t=>t.access[0].who=['unknown_person']},
 {name:'wrong-kind canon access rejects',user:'<ooc>Restore Alex securing the blue kit; only Alex knows.</ooc>',route:'canon',pass:false}
];
for(const scenario of scenarios){
 const b=baseline(),before=JSON.stringify(b),ctx={...context(scenario.user,'Acknowledged; the scene remains paused.'),loadPreviousOutput:async()=>b},pair=[];
 for(const factory of [stable,reviewedRc1,candidate]){
  const runtime=factory(),p=await runtime.prepareContext({agent,context:ctx});assert(!p.blocked,p.blocked);
  const ids=p.sources.filter(s=>s.current&&['author','user'].includes(s.kind)).map(s=>s.id);
  const t={turn:p.turn,through:'Recorded the supported memory change.',scene:null,changes:[{op:'set',ref:'ledger:blue_kit',data:{kind:'state',fact:'Alex secured the blue kit in the rear compartment.',truth:'established'},evidence:ids}],access:[{ref:'ledger:blue_kit',who:['alex'],stance:'knows',route:scenario.route,from:null,evidence:[...ids]}],complete:true};
  scenario.edit?.(t);const original=JSON.stringify(t);
  const r=await runtime.finalizeResult({agent,context:ctx,preparedContext:p,result:{agentId:agent.id,type:'context_injection',success:true,data:{text:JSON.stringify(t)}}});
  assert.equal(r.success,scenario.pass,r.error);assert.equal(JSON.stringify(t),original);assert.equal(JSON.stringify(b),before);
  pair.push(r.success?JSON.parse(r.data.text):null);
 }
 assert.deepEqual(pair[0],pair[1]);assert.deepEqual(pair[0],pair[2]);results.push({name:scenario.name,accepted:scenario.pass,identicalStateOrRejection:true,baselineAndProposalUnchanged:true});
}
console.log(JSON.stringify({cases:results.length,runtimes:3,runtimeExecutions:results.length*3,allPassed:true,results,scope:'Synthetic differential checks; no model compliance or arbitrary-text semantic proof.'},null,2));
