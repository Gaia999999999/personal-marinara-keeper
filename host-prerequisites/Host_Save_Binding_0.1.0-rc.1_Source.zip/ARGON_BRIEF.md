# Focused read-only audit — Host Save-Binding 0.1.0-rc.1

Audit the exact candidate in this bundle. Do not edit repositories, install it, run providers, or authorize a live story call. Give PASS / PASS WITH QUALIFICATIONS / REVISE for this limited host repair, with reproducible findings distinguished from inherited limitations.

## Source of truth

Host baseline: Marinara 2.5.0 / `c56501495a8baf76c258e76534c8728a9b7859bb`. Source tar SHA-256 `4b2a3b305b7a7d9afa6100517a0af841858ea38a8ab659ecac8fdb6260821382`.
Stable Keeper: 4.1.11 / `10249ee2b21cb8c9429e5db5df634e43232c08b5`, native ZIP SHA-256 `454357ecdccf56295ca3ea5c88f198e2e5c960c15790015e67064cf793cd8570`. No Keeper change.
This is a host prerequisite, not a new Keeper release or archive implementation. The owner's retained live checkpoint and prior private audit package remain authoritative and unchanged. This public source bundle deliberately contains no private chat/export/checkpoint material.

## Independent disposition of the retention audit

- **F1: valid missing supported contract.** Post-generation native preparation is too late for prose recall. The prompt context request lacks the required accepted-run/regeneration lineage resolver. Additionally, `collectCapabilityPromptContext` catches errors/timeouts and skips the contributor, so merely adding a contributor cannot enforce mandatory-memory fail-closed behavior. Archive/pre-prose API design is deferred. This is not a proof that all possible integrations are impossible.
- **F2: valid concrete host defect; implemented narrowly.** `saveRun` rereads mutable UI selection after finalization. Ordinary and retry routes already captured a target. Pass that message/swipe pair into persistence and validate explicit targets. Identical visible prose cannot serve as distinct swipe identity. Keeper anchors/recovery are unchanged. No claim that the race corrupted the owner's actual retained checkpoint.
- **F3: valid future archive prerequisites.** Document creation is not automatically idempotent; finalization success can precede accepted-run persistence, which may fail or be aborted. Future content-addressed staging needs verified idempotence and accepted-root reachability; never pick the latest document. This candidate does not repair success-receipt semantics or implement cross-store atomicity.
- **F4: valid preservation warning; reject the deletion shortcut.** Holder containment does not establish historical fact redundancy. Distinct earlier facts can matter even when audiences match, and event/completed records can contain active conditions. The reported counterfactual headroom is not a valid transaction or proof of safe deletion. No archive, retirement, coalescing, stale-holder rewrite or successor-link weakening is included.
- **F5: valid portability and branch prerequisites.** Separate capability documents are not equivalent to a self-contained chat export, and reminted message IDs require explicit reviewed lineage mapping. Whole-app backup behavior is not proved by chat-export behavior. No fuzzy anchor recovery is added.
- **F6: no demonstrated existing cap bypass.** Although the intermediate legacy meter differs, `keeper-core.inspect` subsequently enforces the complete `storedCharacters(input)` cap including anchor/successor information. The 35% guard compares expanded logical state and excludes cosmetic-equivalent domains. A representation threshold flip alone does not demonstrate unexplained domain loss. Future real archival removal still needs an explicit guarded contract.
- **F7: nonblocking provenance qualification retained.** A single stored span is not semantic proof of every fact clause. The earlier private review found no incident-cause verdict or disclosure requiring another paid correction. This host patch does not alter that mechanism or claim to solve it.

The prior audit's introductory full-verification claim should be read alongside its own note that two build/report dependencies were unavailable. Its substantive findings remain useful, but that table is not independently complete packaging proof. Current public Keeper source/native/package checks are rerun and recorded here. Private live/capacity replay results remain those of the previously completed review, not a new execution: workspace maintenance removed the working exports and their recovery helper currently returns HTTP 403. No private replay result was fabricated or substituted.

## Exact implementation scope

Three host runtime files: `agents.storage.ts`, `generate.routes.ts`, `generate/retry-agents-route.ts`. One changelog entry and one regression added. Storage accepts optional explicit swipeIndex; rejects invalid numbers and absent/cross-chat targets; omission retains legacy fallback. Ordinary and retry persistence forward captured targets, including built-in/custom historical message/swipe pairs.

No schema, permissions, dependency, version, Keeper prompt/runtime, cap, audience, author-correction, evidence, atomic-rejection, or live checkpoint change. Personal RP and World State remain outside scope.

## Questions to test

1. Are message/swipe pairs preserved on every touched path, including historical targets and explicit zero?
2. Can an invalid explicit target insert/update an agent run or silently follow the active selection? Are errors strict and non-coercing?
3. Does the regression actually exercise routes, finalizer and storage? It changes selection after producing the final result, uses identical sibling prose, checks raw stored indices and visible previous output, and tests retry from zero and nonzero indices. Only model completion is mocked.
4. Do the original ordinary route and original retry route fail the new test for the claimed reasons? Does the candidate pass? Reproduce using the baseline files if dependencies are available.
5. Is there a candidate-specific regression to prior-output inheritance, batching, historical targeting or legacy omission? Separate baseline limitations from new defects.
6. Are claims appropriately limited? Deletion/reindexing, immutable swipe IDs, concurrent content/parent changes, other saveRun callers, save confirmation, mandatory recall, archive atomicity and portability are not solved. Historical forwarding has source/type coverage, not a complete lorebook end-to-end replay. No Windows/browser manual coverage or upstream CI/CodeRabbit is claimed.

Use README.md to reproduce. Verify FILE_MANIFEST.json and CANDIDATE_FILES.json. Report exact executed checks and any unavailable checks. A PASS here clears only this limited prerequisite for disposition; it does not clear archive migration, stable promotion, installation, or a paid/live call.
