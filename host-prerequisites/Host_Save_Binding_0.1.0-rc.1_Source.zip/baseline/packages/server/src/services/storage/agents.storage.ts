// ──────────────────────────────────────────────
// Storage: Agent Configs, Runs & Memory
// ──────────────────────────────────────────────
import { eq, ne, and, desc, lte, notInArray } from "../../db/file-query.js";
import type { DB } from "../../db/connection.js";
import { agentConfigs, agentRuns, agentMemory, messages, appSettings } from "../../db/schema/index.js";
import { newId, now } from "../../utils/id-generator.js";
import {
  BUILT_IN_AGENTS,
  getDefaultBuiltInAgentSettings,
  markAgentConfigDeletedSettings,
  normalizeAgentPhaseForType,
  parseAgentSettingsRecord,
  type CreateAgentConfigInput,
  type AgentResult,
  homeAgentWidgetsSchema,
} from "@marinara-engine/shared";

const BUILTIN_AGENT_ID_PREFIX = "builtin:";
const REMOVED_BUILT_IN_AGENT_TYPES = new Set(["editor"]);
type AgentRunRow = typeof agentRuns.$inferSelect;
type AgentConfigRow = typeof agentConfigs.$inferSelect;

function isBuiltInAgentType(type: string): boolean {
  return BUILT_IN_AGENTS.some((agent) => agent.id === type);
}

function suffixFromId(id: string): string {
  return id.replace(/[^a-zA-Z0-9_-]/g, "").slice(0, 8) || Date.now().toString(36);
}

function getBuiltinAgentType(agentConfigId: string): string | null {
  if (!agentConfigId.startsWith(BUILTIN_AGENT_ID_PREFIX)) return null;
  const agentType = agentConfigId.slice(BUILTIN_AGENT_ID_PREFIX.length).trim();
  return agentType.length > 0 ? agentType : null;
}

function keepLatestConfigPerType<T extends { type: string }>(rows: T[]): T[] {
  const seen = new Set<string>();
  const latestRows: T[] = [];
  for (const row of rows) {
    if (seen.has(row.type)) continue;
    seen.add(row.type);
    latestRows.push(row);
  }
  return latestRows;
}

function normalizeAgentConfigRow<T extends AgentConfigRow | null>(row: T): T {
  if (!row) return row;
  const phase = normalizeAgentPhaseForType(row.type, row.phase);
  if (phase === row.phase) return row;
  return { ...row, phase } as T;
}

function isRemovedBuiltInAgentType(type: string): boolean {
  return REMOVED_BUILT_IN_AGENT_TYPES.has(type);
}

function parseRunData(value: string): unknown {
  try {
    return JSON.parse(value);
  } catch {
    return value;
  }
}

function mergeBuiltInCreateUpdate(
  existing: AgentConfigRow,
  input: CreateAgentConfigInput,
): Partial<CreateAgentConfigInput> {
  const currentSettings = parseAgentSettingsRecord(existing.settings);
  const nextSettings = { ...currentSettings, ...(input.settings ?? {}) };
  if (input.resultType !== undefined) nextSettings.resultType = input.resultType;

  const update: Partial<CreateAgentConfigInput> = {
    name: input.name,
    description: input.description,
    phase: input.phase,
    settings: nextSettings,
  };

  if (input.connectionId !== null) update.connectionId = input.connectionId;
  if (input.imagePath !== null) update.imagePath = input.imagePath;
  if (input.promptTemplate.trim().length > 0) update.promptTemplate = input.promptTemplate;

  return update;
}

function serializeRunWithConfig(row: { agent_runs: AgentRunRow; agent_configs: AgentConfigRow }) {
  return {
    id: row.agent_runs.id,
    agentConfigId: row.agent_runs.agentConfigId,
    agentType: row.agent_configs.type,
    agentName: row.agent_configs.name,
    hideOutput: parseAgentSettingsRecord(row.agent_configs.settings).hideOutput === true,
    chatId: row.agent_runs.chatId,
    messageId: row.agent_runs.messageId,
    resultType: row.agent_runs.resultType,
    resultData: parseRunData(row.agent_runs.resultData),
    tokensUsed: row.agent_runs.tokensUsed,
    durationMs: row.agent_runs.durationMs,
    success: row.agent_runs.success === "true",
    error: row.agent_runs.error,
    createdAt: row.agent_runs.createdAt,
  };
}

export function createAgentsStorage(db: DB) {
  const widgetStateKey = (agentId: string, widgetId: string) => `agent_home_widget:${agentId}:${widgetId}`;
  async function declaredWidget(agentId: string, widgetId: string, sourceDb: DB = db) {
    const rows = await sourceDb.select().from(agentConfigs).where(eq(agentConfigs.id, agentId));
    const agent = normalizeAgentConfigRow(rows[0] ?? null);
    if (!agent || isBuiltInAgentType(agent.type)) return false;
    const settings = parseAgentSettingsRecord(agent.settings);
    const parsed = homeAgentWidgetsSchema.safeParse(settings.homeWidgets ?? []);
    return parsed.success && parsed.data.some((widget) => widget.id === widgetId);
  }
  async function getById(id: string) {
    const rows = await db.select().from(agentConfigs).where(eq(agentConfigs.id, id));
    return normalizeAgentConfigRow(rows[0] ?? null);
  }

  async function getByType(type: string) {
    if (isRemovedBuiltInAgentType(type)) return null;
    const rows = await db
      .select()
      .from(agentConfigs)
      .where(eq(agentConfigs.type, type))
      .orderBy(desc(agentConfigs.updatedAt))
      .limit(1);
    return normalizeAgentConfigRow(rows[0] ?? null);
  }

  async function getUniqueCustomType(requestedType: string, id: string) {
    const baseType = requestedType.trim() || `custom-${suffixFromId(id)}`;
    if (!(await getByType(baseType))) return baseType;

    const suffix = suffixFromId(id);
    let candidate = `${baseType}-${suffix}`;
    let attempt = 2;
    while (await getByType(candidate)) {
      candidate = `${baseType}-${suffix}-${attempt}`;
      attempt++;
    }
    return candidate;
  }

  async function listLatest() {
    const rows = await db.select().from(agentConfigs).orderBy(desc(agentConfigs.updatedAt));
    return keepLatestConfigPerType(
      rows.filter((row) => !isRemovedBuiltInAgentType(row.type)).map((row) => normalizeAgentConfigRow(row)),
    );
  }

  async function ensureBuiltinConfig(type: string) {
    const builtIn = BUILT_IN_AGENTS.find((agent) => agent.id === type);
    if (!builtIn) return null;

    const existing = await getByType(type);
    if (existing) return existing;

    const id = `${BUILTIN_AGENT_ID_PREFIX}${type}`;
    const timestamp = now();

    try {
      await db.insert(agentConfigs).values({
        id,
        type: builtIn.id,
        name: builtIn.name,
        description: builtIn.description,
        phase: normalizeAgentPhaseForType(builtIn.id, builtIn.phase),
        enabled: "true",
        connectionId: null,
        imagePath: null,
        promptTemplate: "",
        settings: JSON.stringify(getDefaultBuiltInAgentSettings(builtIn.id)),
        createdAt: timestamp,
        updatedAt: timestamp,
      });
    } catch {
      // Another request may have materialized the row first.
    }

    return (await getById(id)) ?? getByType(type);
  }

  async function resolveAgentConfigId(agentConfigId: string) {
    const builtinType = getBuiltinAgentType(agentConfigId);
    if (!builtinType) return agentConfigId;
    const config = await ensureBuiltinConfig(builtinType);
    return config?.id ?? agentConfigId;
  }

  async function removeRuntimeData(id: string) {
    await db.delete(agentRuns).where(eq(agentRuns.agentConfigId, id));
    await db.delete(agentMemory).where(eq(agentMemory.agentConfigId, id));
  }

  return {
    // ── Config CRUD ──

    async list() {
      return listLatest();
    },

    async listEnabled() {
      return listLatest();
    },

    getById,

    getByType,

    async readHomeWidgetState(agentId: string, widgetId: string) {
      if (!(await declaredWidget(agentId, widgetId))) return null;
      const rows = await db
        .select()
        .from(appSettings)
        .where(eq(appSettings.key, widgetStateKey(agentId, widgetId)));
      if (!rows[0]) return { text: "", updatedAt: null };
      try {
        const value = JSON.parse(rows[0].value) as { text: unknown; updatedAt: unknown };
        return {
          text: typeof value.text === "string" ? value.text.slice(0, 500) : "",
          updatedAt: typeof value.updatedAt === "string" ? value.updatedAt : null,
        };
      } catch {
        return { text: "", updatedAt: null };
      }
    },

    async publishHomeWidgetState(agentId: string, widgetId: string, text: string) {
      if (text.length > 500) throw new Error("Widget publication rejected");
      return db.transaction(async (tx) => {
        if (!(await declaredWidget(agentId, widgetId, tx))) throw new Error("Widget publication rejected");
        const key = widgetStateKey(agentId, widgetId);
        const updatedAt = now();
        const row = { key, value: JSON.stringify({ text, updatedAt }), updatedAt };
        await tx.insert(appSettings).values(row).onConflictDoUpdate({ target: appSettings.key, set: row });
        return { updatedAt };
      });
    },

    ensureBuiltinConfig,

    async create(input: CreateAgentConfigInput) {
      const builtInType = isBuiltInAgentType(input.type);
      if (builtInType) {
        const existing = await getByType(input.type);
        if (existing) {
          return this.update(existing.id, mergeBuiltInCreateUpdate(existing, input));
        }
      }

      const id = newId();
      const timestamp = now();
      const requestedCustomType = isRemovedBuiltInAgentType(input.type) ? `${input.type}-custom` : input.type;
      const type = builtInType ? input.type : await getUniqueCustomType(requestedCustomType, id);
      const settings = { ...(input.settings ?? {}) };
      if (input.resultType) settings.resultType = input.resultType;
      await db.insert(agentConfigs).values({
        id,
        type,
        name: input.name,
        description: input.description ?? "",
        phase: normalizeAgentPhaseForType(type, input.phase),
        enabled: "true",
        connectionId: input.connectionId ?? null,
        imagePath: input.imagePath ?? null,
        promptTemplate: input.promptTemplate ?? "",
        settings: JSON.stringify(settings),
        createdAt: timestamp,
        updatedAt: timestamp,
      });
      return this.getById(id);
    },

    async update(id: string, data: Partial<CreateAgentConfigInput>) {
      const updateFields: Record<string, unknown> = { updatedAt: now() };
      const previous = data.settings !== undefined ? await getById(id) : null;
      if (data.name !== undefined) updateFields.name = data.name;
      if (data.description !== undefined) updateFields.description = data.description;
      if (data.phase !== undefined) {
        const current = await getById(id);
        updateFields.phase = normalizeAgentPhaseForType(current?.type ?? "", data.phase);
      }
      if (data.connectionId !== undefined) updateFields.connectionId = data.connectionId;
      if (data.imagePath !== undefined) updateFields.imagePath = data.imagePath;
      if (data.promptTemplate !== undefined) updateFields.promptTemplate = data.promptTemplate;
      if (data.settings !== undefined || data.resultType !== undefined) {
        if (data.settings !== undefined) {
          const settings = { ...data.settings };
          if (data.resultType !== undefined) settings.resultType = data.resultType;
          updateFields.settings = JSON.stringify(settings);
        } else {
          const current = await getById(id);
          const currentSettings = parseAgentSettingsRecord(current?.settings);
          updateFields.settings = JSON.stringify({ ...currentSettings, resultType: data.resultType });
        }
      }
      await db.update(agentConfigs).set(updateFields).where(eq(agentConfigs.id, id));
      if (previous && data.settings) {
        const oldWidgets = homeAgentWidgetsSchema.safeParse(
          parseAgentSettingsRecord(previous.settings).homeWidgets ?? [],
        );
        const newWidgets = homeAgentWidgetsSchema.safeParse(data.settings.homeWidgets ?? []);
        if (oldWidgets.success && newWidgets.success) {
          const retained = new Set(newWidgets.data.map((widget) => widget.id));
          for (const widget of oldWidgets.data) {
            if (!retained.has(widget.id)) {
              await db.delete(appSettings).where(eq(appSettings.key, widgetStateKey(id, widget.id)));
            }
          }
        }
      }
      return this.getById(id);
    },

    async remove(id: string) {
      const agent = await getById(id);
      const widgets = homeAgentWidgetsSchema.safeParse(parseAgentSettingsRecord(agent?.settings).homeWidgets ?? []);
      if (widgets.success) {
        for (const widget of widgets.data) {
          await db.delete(appSettings).where(eq(appSettings.key, widgetStateKey(id, widget.id)));
        }
      }
      await removeRuntimeData(id);
      await db.delete(agentConfigs).where(eq(agentConfigs.id, id));
    },

    async softDeleteBuiltIn(type: string) {
      const builtIn = BUILT_IN_AGENTS.find((agent) => agent.id === type);
      if (!builtIn) return null;

      const existing = await getByType(type);
      if (existing) {
        await removeRuntimeData(existing.id);
        return this.update(existing.id, {
          settings: markAgentConfigDeletedSettings(existing.settings),
        });
      }

      return this.create({
        type: builtIn.id,
        name: builtIn.name,
        description: builtIn.description,
        phase: normalizeAgentPhaseForType(builtIn.id, builtIn.phase),
        connectionId: null,
        imagePath: null,
        promptTemplate: "",
        settings: markAgentConfigDeletedSettings(getDefaultBuiltInAgentSettings(builtIn.id)),
      });
    },

    // ── Agent Runs ──

    async saveRun(input: {
      agentConfigId: string;
      chatId: string;
      messageId: string;
      result: AgentResult;
      runId?: string;
    }) {
      const agentConfigId = await resolveAgentConfigId(input.agentConfigId);
      const id = input.runId ?? newId();
      const [message] = await db
        .select({ activeSwipeIndex: messages.activeSwipeIndex })
        .from(messages)
        .where(and(eq(messages.id, input.messageId), eq(messages.chatId, input.chatId)))
        .limit(1);
      // Omission retains the last visible turn's private context; an explicit value (including null) replaces it.
      let resultData = input.result.data;
      if (
        input.result.success &&
        resultData &&
        typeof resultData === "object" &&
        !Array.isArray(resultData) &&
        !Object.hasOwn(resultData, "agent-context") &&
        !Object.hasOwn(resultData, "agentContext")
      ) {
        const previous = await this.getPreviousOutput(agentConfigId, input.chatId, input.messageId, input.messageId);
        if (previous && typeof previous === "object" && !Array.isArray(previous)) {
          const contextKey = Object.hasOwn(previous, "agent-context") ? "agent-context" : "agentContext";
          if (Object.hasOwn(previous, contextKey)) {
            resultData = { ...resultData, "agent-context": (previous as Record<string, unknown>)[contextKey] };
          }
        }
      }
      const values = {
        id,
        agentConfigId,
        chatId: input.chatId,
        messageId: input.messageId,
        swipeIndex: message?.activeSwipeIndex ?? null,
        resultType: input.result.type,
        resultData: JSON.stringify(resultData),
        tokensUsed: input.result.tokensUsed,
        durationMs: input.result.durationMs,
        success: String(input.result.success),
        error: input.result.error,
        createdAt: now(),
      };
      const insert = db.insert(agentRuns).values(values);
      if (input.runId) {
        await insert.onConflictDoUpdate({
          target: agentRuns.id,
          set: values,
        });
      } else {
        await insert;
      }
      return id;
    },

    /** Follow visible message chronology, not the wall-clock order of manual retries. */
    async getPreviousOutput(
      agentConfigId: string,
      chatId: string,
      throughMessageId?: string,
      excludeMessageId?: string,
    ) {
      let through: { createdAt: string } | undefined;
      if (throughMessageId) {
        [through] = await db
          .select({ createdAt: messages.createdAt })
          .from(messages)
          .where(and(eq(messages.id, throughMessageId), eq(messages.chatId, chatId)))
          .limit(1);
        if (!through) return null;
      }
      const rows = await db
        .select()
        .from(agentRuns)
        .innerJoin(messages, eq(agentRuns.messageId, messages.id))
        .where(
          and(
            eq(agentRuns.agentConfigId, agentConfigId),
            eq(agentRuns.chatId, chatId),
            eq(messages.chatId, chatId),
            eq(agentRuns.success, "true"),
            through ? lte(messages.createdAt, through.createdAt) : undefined,
            excludeMessageId ? ne(messages.id, excludeMessageId) : undefined,
          ),
        )
        .orderBy(desc(messages.createdAt), desc(agentRuns.createdAt));
      const run = rows.find((row) => (row.agent_runs.swipeIndex ?? 0) === row.messages.activeSwipeIndex)?.agent_runs;
      return run ? parseRunData(run.resultData) : null;
    },

    /** Get the most recent successful run of an agent type in a given chat. */
    async getLastSuccessfulRunByType(
      agentType: string,
      chatId: string,
      options: { excludeMessageId?: string | null } = {},
    ) {
      const rows = await db
        .select()
        .from(agentRuns)
        .innerJoin(agentConfigs, eq(agentRuns.agentConfigId, agentConfigs.id))
        .where(
          and(
            eq(agentConfigs.type, agentType),
            eq(agentRuns.chatId, chatId),
            eq(agentRuns.success, "true"),
            options.excludeMessageId ? ne(agentRuns.messageId, options.excludeMessageId) : undefined,
          ),
        )
        .orderBy(desc(agentRuns.createdAt))
        .limit(1);
      return rows[0]?.agent_runs ?? null;
    },

    /** Get the most recent run of an agent type in a given chat, regardless of success. */
    async getLastRunByType(agentType: string, chatId: string) {
      const rows = await db
        .select()
        .from(agentRuns)
        .innerJoin(agentConfigs, eq(agentRuns.agentConfigId, agentConfigs.id))
        .where(and(eq(agentConfigs.type, agentType), eq(agentRuns.chatId, chatId)))
        .orderBy(desc(agentRuns.createdAt))
        .limit(1);
      return rows[0]?.agent_runs ?? null;
    },

    async hasSuccessfulRunForMessage(agentConfigId: string, chatId: string, messageId: string) {
      const resolvedAgentConfigId = await resolveAgentConfigId(agentConfigId);
      const rows = await db
        .select({ id: agentRuns.id })
        .from(agentRuns)
        .where(
          and(
            eq(agentRuns.agentConfigId, resolvedAgentConfigId),
            eq(agentRuns.chatId, chatId),
            eq(agentRuns.messageId, messageId),
            eq(agentRuns.success, "true"),
          ),
        )
        .limit(1);
      return rows.length > 0;
    },

    /** Get all echo chamber messages for a chat, ordered by creation time. */
    async getEchoMessages(chatId: string) {
      const rows = await db
        .select({ resultData: agentRuns.resultData, createdAt: agentRuns.createdAt })
        .from(agentRuns)
        .where(
          and(eq(agentRuns.chatId, chatId), eq(agentRuns.resultType, "echo_message"), eq(agentRuns.success, "true")),
        )
        .orderBy(agentRuns.createdAt);

      const messages: Array<{ characterName: string; reaction: string; timestamp: number }> = [];
      for (const row of rows) {
        try {
          const data = JSON.parse(row.resultData);
          const reactions = Array.isArray(data?.reactions) ? data.reactions : [];
          const ts = new Date(row.createdAt).getTime();
          for (const r of reactions) {
            if (
              typeof r?.characterName === "string" &&
              r.characterName.trim() &&
              typeof r.reaction === "string" &&
              r.reaction.trim()
            ) {
              messages.push({ characterName: r.characterName, reaction: r.reaction, timestamp: ts });
            }
          }
        } catch {
          /* skip malformed entries */
        }
      }
      return messages;
    },

    /** Get recent custom-agent runs for a chat, newest first. */
    async listCustomRunsForChat(chatId: string, limit = 50) {
      const finiteLimit = Number.isFinite(limit) ? limit : 50;
      const normalizedLimit = Math.max(1, Math.min(finiteLimit, 200));
      const rows = await db
        .select()
        .from(agentRuns)
        .innerJoin(agentConfigs, eq(agentRuns.agentConfigId, agentConfigs.id))
        .where(
          and(
            eq(agentRuns.chatId, chatId),
            eq(agentRuns.success, "true"),
            notInArray(
              agentConfigs.type,
              BUILT_IN_AGENTS.map((agent) => agent.id),
            ),
          ),
        )
        .orderBy(desc(agentRuns.createdAt))
        .limit(normalizedLimit);

      return rows.map((row) => serializeRunWithConfig(row));
    },

    /**
     * The recent runs of one agent type in a chat, newest first.
     *
     * getLastSuccessfulRunByType answers "what is the state now"; this answers "what has
     * this agent been doing", which is what a diagnostic panel needs. Failures are kept:
     * a run that errored is the most interesting row on the list, and dropping it would
     * make a broken agent look idle instead of broken.
     */
    async listRunsByTypeForChat(agentType: string, chatId: string, limit = 5) {
      const finiteLimit = Number.isFinite(limit) ? limit : 5;
      // 51, not 50. Callers that diff consecutive runs ask for one more than they intend
      // to show, so the oldest row still has a predecessor to be compared against; a cap
      // of exactly 50 silently removed that row and left the oldest run reporting no
      // comparison at all.
      const normalizedLimit = Math.max(1, Math.min(finiteLimit, 51));
      const rows = await db
        .select()
        .from(agentRuns)
        .innerJoin(agentConfigs, eq(agentRuns.agentConfigId, agentConfigs.id))
        .where(and(eq(agentRuns.chatId, chatId), eq(agentConfigs.type, agentType)))
        .orderBy(desc(agentRuns.createdAt))
        .limit(normalizedLimit);

      return rows.map((row) => serializeRunWithConfig(row));
    },

    async getRunWithConfig(id: string, chatId?: string) {
      const condition = chatId ? and(eq(agentRuns.chatId, chatId), eq(agentRuns.id, id)) : eq(agentRuns.id, id);
      const rows = await db
        .select()
        .from(agentRuns)
        .innerJoin(agentConfigs, eq(agentRuns.agentConfigId, agentConfigs.id))
        .where(condition)
        .limit(1);
      const row = rows[0];
      return row ? serializeRunWithConfig(row) : null;
    },

    async updateRunResultData(id: string, resultData: unknown, chatId?: string) {
      const condition = chatId ? and(eq(agentRuns.chatId, chatId), eq(agentRuns.id, id)) : eq(agentRuns.id, id);
      await db
        .update(agentRuns)
        .set({ resultData: JSON.stringify(resultData) })
        .where(condition);
      return this.getRunWithConfig(id, chatId);
    },

    // ── Agent Memory (persistent KV per agent per chat) ──

    async getMemory(agentConfigId: string, chatId: string): Promise<Record<string, unknown>> {
      const resolvedAgentConfigId = await resolveAgentConfigId(agentConfigId);
      const rows = await db
        .select()
        .from(agentMemory)
        .where(and(eq(agentMemory.agentConfigId, resolvedAgentConfigId), eq(agentMemory.chatId, chatId)));
      const mem: Record<string, unknown> = {};
      for (const row of rows) {
        try {
          mem[row.key] = JSON.parse(row.value);
        } catch {
          mem[row.key] = row.value;
        }
      }
      return mem;
    },

    async setMemory(agentConfigId: string, chatId: string, key: string, value: unknown) {
      const resolvedAgentConfigId = await resolveAgentConfigId(agentConfigId);
      const stringValue = typeof value === "string" ? value : JSON.stringify(value);
      const existing = await db
        .select()
        .from(agentMemory)
        .where(
          and(
            eq(agentMemory.agentConfigId, resolvedAgentConfigId),
            eq(agentMemory.chatId, chatId),
            eq(agentMemory.key, key),
          ),
        );

      if (existing.length > 0) {
        await db
          .update(agentMemory)
          .set({ value: stringValue, updatedAt: now() })
          .where(and(eq(agentMemory.chatId, chatId), eq(agentMemory.id, existing[0]!.id)));
      } else {
        await db.insert(agentMemory).values({
          id: newId(),
          agentConfigId: resolvedAgentConfigId,
          chatId,
          key,
          value: stringValue,
          updatedAt: now(),
        });
      }
    },

    async setMemories(agentConfigId: string, chatId: string, values: Record<string, unknown>) {
      const resolvedAgentConfigId = await resolveAgentConfigId(agentConfigId);
      const entries = Object.entries(values)
        .filter((entry): entry is [string, unknown] => entry[1] !== undefined)
        .map(([key, value]) => ({
          key,
          value: typeof value === "string" ? value : JSON.stringify(value),
        }));
      if (entries.length === 0) return;

      await db.transaction(async (tx) => {
        const existingRows = await tx
          .select()
          .from(agentMemory)
          .where(and(eq(agentMemory.agentConfigId, resolvedAgentConfigId), eq(agentMemory.chatId, chatId)));
        const existingByKey = new Map(existingRows.map((row) => [row.key, row]));
        const timestamp = now();
        const inserts: (typeof agentMemory.$inferInsert)[] = [];

        for (const entry of entries) {
          const existing = existingByKey.get(entry.key);
          if (existing) {
            await tx
              .update(agentMemory)
              .set({ value: entry.value, updatedAt: timestamp })
              .where(and(eq(agentMemory.chatId, chatId), eq(agentMemory.id, existing.id)));
          } else {
            inserts.push({
              id: newId(),
              agentConfigId: resolvedAgentConfigId,
              chatId,
              key: entry.key,
              value: entry.value,
              updatedAt: timestamp,
            });
          }
        }

        if (inserts.length > 0) {
          await tx.insert(agentMemory).values(inserts);
        }
      });
    },

    /** Delete echo chamber message runs for a specific chat. */
    async clearEchoMessages(chatId: string) {
      await db.delete(agentRuns).where(and(eq(agentRuns.chatId, chatId), eq(agentRuns.resultType, "echo_message")));
    },

    /** Delete all agent runs for a specific chat. */
    async clearRunsForChat(chatId: string) {
      await db.delete(agentRuns).where(eq(agentRuns.chatId, chatId));
    },

    /** Delete all agent memory entries for a specific chat. */
    async clearMemoryForChat(chatId: string) {
      await db.delete(agentMemory).where(eq(agentMemory.chatId, chatId));
    },

    /** Delete a specific memory key for an agent in a chat. */
    async deleteMemoryKey(agentConfigId: string, chatId: string, key: string) {
      const resolvedAgentConfigId = await resolveAgentConfigId(agentConfigId);
      await db
        .delete(agentMemory)
        .where(
          and(
            eq(agentMemory.agentConfigId, resolvedAgentConfigId),
            eq(agentMemory.chatId, chatId),
            eq(agentMemory.key, key),
          ),
        );
    },

    /** Delete all memory for a specific agent in a specific chat. */
    async clearMemoryForAgentInChat(agentConfigId: string, chatId: string) {
      const resolvedAgentConfigId = await resolveAgentConfigId(agentConfigId);
      await db
        .delete(agentMemory)
        .where(and(eq(agentMemory.agentConfigId, resolvedAgentConfigId), eq(agentMemory.chatId, chatId)));
    },
  };
}
