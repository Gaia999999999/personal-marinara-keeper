import assert from "node:assert/strict";
import { mkdtempSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { createServer } from "node:http";
import { createRequire } from "node:module";

const directory = mkdtempSync(join(tmpdir(), "marinara-advanced-memory-core-"));
process.env.DATA_DIR = directory;
process.env.FILE_STORAGE_DIR = join(directory, "storage");
process.env.NODE_ENV = "test";
process.env.LOG_LEVEL = "silent";
process.env.MARINARA_LITE = "true";

const requests: Array<{ kind: string; text: string }> = [];
let beforeSummary: (() => Promise<void>) | null = null;
let beforeEmbedding: (() => Promise<void>) | null = null;
let sceneFinishReason = "stop";
const server = createServer(async (request, response) => {
  const chunks: Buffer[] = [];
  for await (const chunk of request) chunks.push(Buffer.from(chunk));
  const body = JSON.parse(Buffer.concat(chunks).toString()) as {
    input?: string | string[];
    messages?: Array<{ content: string }>;
  };
  response.setHeader("Content-Type", "application/json");
  if (request.url?.endsWith("/embeddings")) {
    const input = Array.isArray(body.input) ? body.input : [body.input ?? ""];
    requests.push({ kind: "embedding", text: input.join("\n") });
    const callback = beforeEmbedding;
    beforeEmbedding = null;
    if (callback) await callback();
    response.end(
      JSON.stringify({
        data: input.map((text, index) => ({ index, embedding: [1, text.includes("compass") ? 1 : 0, 0.5] })),
      }),
    );
    return;
  }
  const messages = body.messages ?? [];
  const text = messages.map((message) => message.content).join("\n");
  const classification = messages[0]?.content.startsWith("Identify scene transitions") === true;
  requests.push({ kind: classification ? "classify" : "summary", text });
  let content: string;
  if (classification) {
    const source = JSON.parse(messages[1]!.content) as Array<{
      messageId: string;
      messageNumber: number;
      content: string;
    }>;
    const transitions = source.filter((message) => message.content.startsWith("SCENE_CHANGE"));
    content = JSON.stringify(
      messages[0]!.content.includes('"ends"')
        ? { ends: transitions.map((message) => ({ messageNumber: message.messageNumber - 1 })) }
        : { starts: transitions.map((message) => ({ messageId: message.messageId })) },
    );
  } else {
    const callback = beforeSummary;
    beforeSummary = null;
    if (callback) await callback();
    content = JSON.stringify({
      audience: "all",
      summary: text.includes("CORRECTED_SILVER")
        ? "CORRECTED_SILVER compass."
        : text.includes("CORRECTED_GOLD")
          ? "CORRECTED_GOLD compass."
          : "A previous compass promise matters.",
      title: "Journey",
    });
  }
  response.end(
    JSON.stringify({
      id: "memory-proof",
      object: "chat.completion",
      choices: [
        {
          index: 0,
          message: { role: "assistant", content },
          finish_reason: classification ? sceneFinishReason : "stop",
        },
      ],
      usage: { prompt_tokens: 100, completion_tokens: 10, total_tokens: 110 },
    }),
  );
});
await new Promise<void>((resolve) => server.listen(0, "127.0.0.1", resolve));
const address = server.address();
assert(address && typeof address === "object");
const baseUrl = `http://127.0.0.1:${address.port}/v1`;
const { createFileNativeDB } = await import("../../packages/server/src/db/file-backed-store.js");
const { createChatsStorage } = await import("../../packages/server/src/services/storage/chats.storage.js");
const { createConnectionsStorage } = await import("../../packages/server/src/services/storage/connections.storage.js");
const { createAdvancedMemoryService } = await import("../../packages/server/src/services/advanced-memory.js");
const { createConnectionSchema } = await import("../../packages/shared/src/schemas/connection.schema.ts");
const { DEFAULT_ADVANCED_MEMORY_SETTINGS } = await import("../../packages/shared/src/types/advanced-memory.ts");
const db = await createFileNativeDB();
const { advancedMemoryRecords } = await import("../../packages/server/src/db/schema/advanced-memory.ts");
const fullRecordReads = new Map<string, number>();
const select = db.select.bind(db);
db.select = ((...args: unknown[]) => {
  const query = (select as (...args: unknown[]) => any)(...args);
  const from = query.from.bind(query);
  query.from = (table: unknown) => {
    const builder = from(table);
    if (table === advancedMemoryRecords) {
      const where = builder.where.bind(builder);
      builder.where = (condition: { left?: unknown; right?: unknown }) => {
        if (condition.left === advancedMemoryRecords.chatId && typeof condition.right === "string")
          fullRecordReads.set(condition.right, (fullRecordReads.get(condition.right) ?? 0) + 1);
        return where(condition);
      };
    }
    return builder;
  };
  return query;
}) as typeof db.select;
const chats = createChatsStorage(db);
const memory = createAdvancedMemoryService(db);
const createChat = chats.create.bind(chats);
chats.create = async (input) => {
  const chat = await createChat(input);
  if (chat) await chats.patchMetadata(chat.id, { summaryMaxTokens: 512 });
  return chat;
};
// Legacy continuity/temporary records remain importable and deletable, but are no
// longer produced by prompt preparation or used instead of canonical Chat Summaries.
async function seedLegacyRecord(
  chatId: string,
  kind: "continuity" | "temporary",
  boundary: string,
  template?: Awaited<ReturnType<typeof memory.status>>["records"][number],
) {
  const base =
    template ??
    (await memory.status(chatId)).records.find(
      (record) => record.kind === "scene" && record.content && record.status === "closed",
    );
  assert(base);
  const id = `legacy-${kind}-${chatId}`;
  const { startIndex: _start, endIndex: _end, embeddingStatus: _embedding, ...stored } = base;
  const dependencies = [
    ...base.dependencies,
    { id: "boundary", revision: boundary },
    { id: "shared-start", revision: "" },
    { id: "budget", revision: "512" },
  ];
  await db.insert(advancedMemoryRecords).values({
    ...stored,
    id,
    kind,
    sceneId: `${kind}-${boundary}`,
    content: "Legacy continuity",
    enabled: 1,
    manualOverride: 0,
    messageIds: JSON.stringify(base.messageIds),
    audienceCharacterIds: JSON.stringify(base.audienceCharacterIds),
    dependencies: JSON.stringify(dependencies),
    embedding: null,
    embeddingSpaceId: null,
  });
  return id;
}

try {
  const connection = await createConnectionsStorage(db).create(
    createConnectionSchema.parse({
      name: "Memory proof",
      provider: "openai",
      model: "gpt-4o-mini",
      baseUrl,
      apiKey: "test-key",
      maxContext: 16_384,
      defaultForAgents: true,
      embeddingBaseUrl: baseUrl,
      embeddingModel: "memory-proof",
      treatAsLocalEndpoint: true,
    }),
  );
  const chat = await chats.create({
    name: "800-message proof",
    mode: "roleplay",
    characterIds: [],
    connectionId: connection!.id,
  });
  assert(chat);
  await chats.patchMetadata(chat.id, {
    advancedMemory: {
      ...DEFAULT_ADVANCED_MEMORY_SETTINGS,
      enabled: true,
      maxContextTokens: 16_384,
      summaryBudgetTokens: 512,
    },
  });
  await chats.createMessagesBatch(
    chat.id,
    Array.from({ length: 800 }, (_, index) => ({
      role: index % 2 ? ("assistant" as const) : ("user" as const),
      content: `${index === 0 ? "Date: Spring 14\n" : index === 400 ? "SCENE_CHANGE\nDate: Spring 15\n" : ""}Message ${index}: the compass promise continues along the road.`,
    })),
  );
  const source = await chats.listMessages(chat.id);
  const controller = new AbortController();
  await assert.rejects(
    memory.initialize(chat.id, {
      signal: controller.signal,
      onProgress: (event) => {
        if (event.stage === "classifying" && event.completed > 0) controller.abort(new Error("pause proof"));
      },
    }),
  );
  const classifiedBeforeResume = requests.filter((request) => request.kind === "classify").length;
  assert.equal(classifiedBeforeResume, 1);
  await memory.initialize(chat.id);
  const resumedFirst = requests.filter((request) => request.kind === "classify")[classifiedBeforeResume]!;
  assert(!resumedFirst.text.includes('"content":"Message 0:'), "resume uses the durable classification checkpoint");
  assert.equal((await memory.status(chat.id)).job.status, "ready");
  assert(
    (fullRecordReads.get(chat.id) ?? 0) <= 8,
    "initializing 800 messages reads the archive only a bounded number of times",
  );

  const settledRequests = requests.length;
  await memory.initialize(chat.id);
  assert.equal(requests.length, settledRequests, "unchanged messages reuse summaries and vectors");
  const readonly = await memory.prepare({
    chatId: chat.id,
    messages: source,
    audienceCharacterIds: [],
    budgetTokens: 50_000,
    readOnly: true,
  });
  assert.equal(requests.length, settledRequests, "preview makes no provider or embedding call");
  assert.equal(readonly.messageIds.length, 800);
  const summariesBeforePrepare = requests.filter((request) => request.kind === "summary").length;
  const prepared = await memory.prepare({
    chatId: chat.id,
    messages: source,
    audienceCharacterIds: [],
    budgetTokens: 1200,
  });
  assert(prepared.currentSceneSummary, "a large ongoing scene gets a temporary prefix summary");
  assert.equal(prepared.chatSummary, null, "scene recaps do not populate a parallel constant-summary store");
  assert(prepared.currentSceneSummary.includes("Spring 15"), "ongoing-source excerpts retain source dates");
  assert(prepared.messageIds.includes(source.at(-1)!.id), "the latest message remains exact history");
  assert(prepared.receipt.estimatedTokensAfter <= 1200);
  await memory.validatePrepared(chat.id, source, prepared.receipt);
  assert(
    (await memory.status(chat.id)).records.some((record) => record.kind === "scene" && record.status === "open"),
    "prefix compression leaves the scene open",
  );

  assert(
    !(await memory.status(chat.id)).records.some(
      (record) => record.kind === "continuity" || record.kind === "temporary",
    ),
    "reading memory never saves a new summary",
  );
  assert.equal(
    requests.filter((request) => request.kind === "summary").length,
    summariesBeforePrepare,
    "prompt fitting adds no summary calls",
  );

  const historicalSource = source.slice(0, 80);
  const historicalStart = requests.length;
  const historical = await memory.prepare({
    chatId: chat.id,
    messages: historicalSource,
    audienceCharacterIds: [],
    budgetTokens: 900,
  });
  assert(
    !requests.slice(historicalStart).some((request) => request.text.includes("Message 799:")),
    "historical summaries never consume future messages",
  );
  await memory.validatePrepared(chat.id, historicalSource, historical.receipt);

  await chats.patchMetadata(chat.id, {
    macroVariables: { material: "CORRECTED_GOLD" },
    summaryEntries: [
      {
        id: "correction",
        kind: "rolling",
        origin: "manual",
        content: "{{getvar::material}} compass",
        enabled: true,
        title: "Correction",
        sourceMode: "range",
        messageIds: source.slice(0, 10).map((message) => message.id),
        rangeStartIndex: 1,
        rangeEndIndex: 10,
        tokenEstimate: 6,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      },
    ],
  });
  const corrected = await memory.prepare({
    chatId: chat.id,
    messages: source,
    audienceCharacterIds: [],
    budgetTokens: 1400,
  });
  assert(
    corrected.chatSummary?.includes("CORRECTED_GOLD"),
    "user corrections contribute to the sole continuity summary",
  );
  await assert.rejects(
    memory.validatePrepared(chat.id, source, prepared.receipt),
    /summary corrections|memory changed/iu,
  );
  await chats.patchMetadata(chat.id, { macroVariables: { material: "CORRECTED_SILVER" } });
  const revisedVariable = await memory.prepare({
    chatId: chat.id,
    messages: source,
    audienceCharacterIds: [],
    budgetTokens: 1400,
  });
  assert(
    revisedVariable.chatSummary?.includes("CORRECTED_SILVER"),
    "manual summary variables resolve and invalidate cached derived text when changed",
  );
  await assert.rejects(
    memory.validatePrepared(chat.id, source, corrected.receipt),
    /summary corrections|memory changed/iu,
  );
  await chats.updateMessageContent(source[0]!.id, "Edited promise.");
  await assert.rejects(
    memory.prepare({
      chatId: chat.id,
      messages: source,
      audienceCharacterIds: [],
      budgetTokens: 50_000,
      readOnly: true,
    }),
    /history changed/iu,
  );

  const privateChat = await chats.create({
    name: "Audience proof",
    mode: "roleplay",
    characterIds: ["alice", "bob", "narrator"],
    connectionId: connection!.id,
  });
  assert(privateChat);
  await chats.createMessagesBatch(
    privateChat.id,
    Array.from({ length: 12 }, (_, index) => ({
      role: index % 2 ? ("assistant" as const) : ("user" as const),
      content: `${index === 6 ? "SCENE_CHANGE " : ""}${index < 6 ? "PRIVATE_SECRET" : "Shared road"} turn ${index}`,
    })),
  );
  const privateSource = await chats.listMessages(privateChat.id);
  await chats.patchMetadata(privateChat.id, {
    groupChatMode: "individual",
    advancedMemory: {
      ...DEFAULT_ADVANCED_MEMORY_SETTINGS,
      enabled: true,
      maxContextTokens: 16_384,
      summaryBudgetTokens: 512,
      narratorCharacterId: "narrator",
      knowledgeStarts: { alice: null, bob: privateSource[6]!.id },
      knowledgeConfirmed: true,
    },
  });
  await memory.initialize(privateChat.id);
  const bob = await memory.prepare({
    chatId: privateChat.id,
    messages: privateSource,
    audienceCharacterIds: ["bob"],
    budgetTokens: 3000,
    readOnly: true,
  });
  assert(
    bob.messageIds.every((id) => privateSource.slice(6).some((message) => message.id === id)),
    "late joiner sees only permitted source history",
  );
  const narrator = await memory.prepare({
    chatId: privateChat.id,
    messages: privateSource,
    audienceCharacterIds: ["narrator"],
    budgetTokens: 3000,
    readOnly: true,
  });
  assert(narrator.messageIds.includes(privateSource[0]!.id));
  const beforeHistoricalPolicy = privateSource.slice(0, 4);
  await chats.updateMessageExtra(privateSource[10]!.id, { conversationStartForCharacterIds: ["alice"] });
  const alicePast = await memory.prepare({
    chatId: privateChat.id,
    messages: beforeHistoricalPolicy,
    audienceCharacterIds: ["alice"],
    budgetTokens: 3000,
  });
  await memory.validatePrepared(privateChat.id, beforeHistoricalPolicy, alicePast.receipt);

  const hiddenSceneChat = await chats.create({
    name: "Pantalone-only hidden scene",
    mode: "roleplay",
    characterIds: ["maukie", "pantalone", "narrator"],
    connectionId: connection!.id,
  });
  assert(hiddenSceneChat);
  await chats.patchMetadata(hiddenSceneChat.id, {
    groupChatMode: "individual",
    advancedMemory: {
      ...DEFAULT_ADVANCED_MEMORY_SETTINGS,
      enabled: true,
      narratorCharacterId: "narrator",
      knowledgeStarts: { maukie: null, pantalone: null },
    },
  });
  await chats.createMessagesBatch(hiddenSceneChat.id, [
    {
      role: "user",
      content: "Pantalone enters the private office alone.",
      extra: { hiddenFromAICharacterIds: ["maukie"] },
    },
    {
      role: "assistant",
      characterId: "pantalone",
      content: "PANTALONE_PRIVATE_SECRET: The ledger belongs to Pantalone.",
      extra: { hiddenFromAICharacterIds: ["maukie"] },
    },
    { role: "user", content: "SCENE_CHANGE Everyone meets at the compass shop." },
  ]);
  await memory.initialize(hiddenSceneChat.id);
  const hiddenSceneSource = await chats.listMessages(hiddenSceneChat.id);
  const privateRecaps = (await memory.status(hiddenSceneChat.id)).records.filter(
    (record) => record.kind === "scene" && record.content && record.status === "closed",
  );
  assert(privateRecaps.some((record) => record.audienceCharacterIds.includes("pantalone")));
  assert(
    privateRecaps.every((record) => !record.audienceCharacterIds.includes("maukie")),
    "initial processing must never assign a fully hidden Pantalone scene to Maukie",
  );
  const maukieRecall = await memory.prepare({
    chatId: hiddenSceneChat.id,
    messages: hiddenSceneSource,
    audienceCharacterIds: ["maukie"],
    budgetTokens: 3000,
    readOnly: true,
  });
  assert.equal(maukieRecall.recalledScenes, null);
  assert.equal(maukieRecall.recalledMessages, null);
  assert.deepEqual(maukieRecall.messageIds, [hiddenSceneSource[2]!.id]);

  await assert.rejects(
    memory.updateRecord(
      hiddenSceneChat.id,
      privateRecaps.find((record) => record.audienceCharacterIds.includes("pantalone"))!.id,
      { audienceCharacterIds: ["maukie"] },
    ),
    /hidden from a selected character/,
    "manual scene access cannot bypass hidden source messages",
  );
  const audienceChat = await chats.create({
    name: "POV shifts preserve editable memories",
    mode: "roleplay",
    characterIds: ["maukie", "pantalone", "narrator"],
    connectionId: connection!.id,
  });
  assert(audienceChat);
  await chats.createMessagesBatch(
    audienceChat.id,
    Array.from({ length: 9 }, (_, index) => ({
      role: "user" as const,
      content: `${index === 2 || index === 6 ? "SCENE_CHANGE " : ""}The brass compass promise ${index}.`,
      extra:
        index === 6
          ? { isConversationStart: true }
          : index === 7
            ? { conversationStartForCharacterIds: ["pantalone"] }
            : undefined,
    })),
  );
  const audienceSource = await chats.listMessages(audienceChat.id);
  await chats.patchMetadata(audienceChat.id, {
    groupChatMode: "individual",
    advancedMemory: {
      ...DEFAULT_ADVANCED_MEMORY_SETTINGS,
      enabled: true,
      narratorCharacterId: "narrator",
      knowledgeStarts: { maukie: null, pantalone: audienceSource[2]!.id },
      retrieveMinMessages: 1,
      retrieveMaxMessages: 3,
    },
  });
  await memory.initialize(audienceChat.id);
  const editable = (await memory.status(audienceChat.id)).records.find(
    (record) =>
      record.kind === "scene" &&
      record.content &&
      record.messageIds.includes(audienceSource[3]!.id) &&
      record.audienceCharacterIds.includes("pantalone"),
  )!;
  assert(editable, "the initial archive includes scenes between confirmed knowledge and a later personal cutoff");
  const requestCount = requests.length;
  await memory.updateRecord(audienceChat.id, editable.id, { audienceCharacterIds: ["maukie"] });
  const repaired = await memory.updateRecord(audienceChat.id, editable.id, { audienceCharacterIds: ["pantalone"] });
  assert.equal(requests.length, requestCount, "audience corrections make no model or embedding calls");
  const repairedScene = repaired.records.find((record) => record.id === editable.id)!;
  assert.deepEqual(repairedScene.audienceCharacterIds, ["pantalone"]);
  assert.equal(repairedScene.content, editable.content);
  assert.equal(repairedScene.embeddingStatus, "vectorized", "audience-only edits reuse the existing vector");
  const recallFor = (id: string) =>
    memory.prepare({
      chatId: audienceChat.id,
      messages: audienceSource,
      audienceCharacterIds: [id],
      budgetTokens: 4000,
      readOnly: true,
    });
  const pantaloneRecall = await recallFor("pantalone");
  assert.deepEqual(
    pantaloneRecall.messageIds,
    audienceSource.slice(7).map((message) => message.id),
    "personal flags still trim live messages",
  );
  assert(pantaloneRecall.receipt.recalledSceneIds.includes(editable.sceneId));
  assert(
    pantaloneRecall.receipt.recalledMessageIds.some((id) => editable.messageIds.includes(id)),
    "existing indexed excerpts are reusable for a corrected, eligible audience",
  );
  assert(
    !(await recallFor("maukie")).receipt.recalledSceneIds.includes(editable.sceneId),
    "removed audience loses access immediately",
  );
  assert(
    (await recallFor("narrator")).receipt.recalledSceneIds.includes(editable.sceneId),
    "narrator retains the shared scene",
  );
  const beforeMaintenance = requests.filter((request) => request.kind === "summary").length;
  await memory.initialize(audienceChat.id, { detectScenes: false });
  assert.equal(
    requests.filter((request) => request.kind === "summary").length,
    beforeMaintenance,
    "maintenance preserves the correction without generating replacement summaries",
  );
  assert(!(await recallFor("maukie")).receipt.recalledSceneIds.includes(editable.sceneId));
  assert((await recallFor("pantalone")).receipt.recalledSceneIds.includes(editable.sceneId));
  await memory.updateRecord(audienceChat.id, editable.id, {
    audienceCharacterIds: ["maukie", "pantalone"],
    content: "CORRECTED_GOLD compass promise.",
  });
  assert(
    (await recallFor("maukie")).receipt.recalledSceneIds.includes(editable.sceneId),
    "granting access again clears the earlier exclusion",
  );
  await assert.rejects(
    memory.updateRecord(audienceChat.id, editable.id, { audienceCharacterIds: ["stranger"] }),
    /Choose characters/,
  );
  await assert.rejects(
    memory.updateRecord(audienceChat.id, editable.id, { audienceCharacterIds: ["narrator"] }),
    /narrator already has access/,
  );

  const editedContent = "CORRECTED_GOLD compass promise.\nThe road continues.";
  await memory.updateRecord(audienceChat.id, editable.id, { content: editedContent });
  const beforeReindexRequests = requests.length;
  await memory.reindex(audienceChat.id);
  const reindexedScene = (await memory.status(audienceChat.id)).records.find((record) => record.id === editable.id);
  assert.equal(reindexedScene?.content, editedContent, "reindex preserves manual summary text");
  assert.deepEqual(reindexedScene?.audienceCharacterIds, ["maukie", "pantalone"]);
  assert.equal(reindexedScene?.embeddingStatus, "vectorized");
  assert(
    requests.slice(beforeReindexRequests).every((request) => request.kind === "embedding"),
    "reindexing existing edited memories only makes embedding calls",
  );

  const recallChat = await chats.create({
    name: "Exact recall proof",
    mode: "roleplay",
    characterIds: [],
    connectionId: connection!.id,
  });
  assert(recallChat);
  await chats.patchMetadata(recallChat.id, {
    advancedMemory: {
      ...DEFAULT_ADVANCED_MEMORY_SETTINGS,
      enabled: true,
      maxContextTokens: 16_384,
      summaryBudgetTokens: 256,
      retrieveMinMessages: 1,
      retrieveMaxMessages: 3,
    },
  });
  await chats.createMessagesBatch(
    recallChat.id,
    Array.from({ length: 60 }, (_, index) => ({
      role: index % 2 ? ("assistant" as const) : ("user" as const),
      content:
        index === 5
          ? "Date: Spring 14\nLuna promised to return the silver compass on Sunday."
          : index === 25
            ? "The following morning, Luna corrected the promise: the silver compass returns on Tuesday, never Sunday."
            : index >= 56
              ? "What was Luna's promise about the silver compass and its later correction?"
              : `${index === 40 ? "SCENE_CHANGE " : ""}The cartographer studied ancient maps and measured every mountain ridge carefully along the long winding road.`,
    })),
  );
  const recallSource = await chats.listMessages(recallChat.id);
  const { createGameStateStorage } = await import("../../packages/server/src/services/storage/game-state.storage.js");
  const gameStates = createGameStateStorage(db);
  const { characterTrackerLockKey } = await import("../../packages/shared/src/utils/tracker-field-locks.ts");
  const hiddenNpc = {
    characterId: "",
    name: "HIDDEN_NPC_NAME",
    emoji: "",
    mood: "neutral",
    appearance: null,
    outfit: null,
    thoughts: null,
    stats: [],
    customFields: {},
  };
  const trackerBase = {
    chatId: recallChat.id,
    swipeIndex: 0,
    date: "Spring 14",
    time: "Noon",
    location: "Committed Map Room",
    weather: null,
    temperature: null,
    presentCharacters: [
      {
        characterId: "luna",
        name: "Luna",
        emoji: "",
        mood: "compass",
        appearance: null,
        outfit: null,
        thoughts: "TRACKER_SECRET_NEVER_INCLUDE",
        stats: [],
        customFields: { relationship: "compass promise" },
      },
    ],
    recentEvents: [],
    playerStats: null,
    personaStats: null,
    committed: true,
    hiddenTrackerFields: { [characterTrackerLockKey(hiddenNpc, 1, "name")]: true },
  };
  trackerBase.presentCharacters.push(hiddenNpc);
  await gameStates.create({ ...trackerBase, messageId: recallSource[5]!.id });
  await gameStates.create({
    ...trackerBase,
    messageId: recallSource[57]!.id,
    location: "UNCOMMITTED_FORBIDDEN",
    committed: false,
  });
  await gameStates.create({ ...trackerBase, messageId: recallSource[58]!.id });
  const trackerRequests = requests.length;
  await memory.initialize(recallChat.id);
  const trackedClassification = requests
    .slice(trackerRequests)
    .filter((request) => request.kind === "classify")
    .map((request) => request.text)
    .join("\n");
  assert(trackedClassification.includes("Committed Map Room"), "classifier can reuse bounded committed scene hints");
  assert(
    !trackedClassification.includes("HIDDEN_NPC_NAME"),
    "explicitly hidden NPC presence names never reach classification",
  );
  assert(
    !trackedClassification.includes("UNCOMMITTED_FORBIDDEN") &&
      !trackedClassification.includes("TRACKER_SECRET_NEVER_INCLUDE"),
    "uncommitted tracker state and private thoughts are never classification hints",
  );

  await memory.prepare({ chatId: recallChat.id, messages: recallSource, audienceCharacterIds: [], budgetTokens: 1800 });
  const beforeLexical = requests.length;
  const exactRecall = await memory.prepare({
    chatId: recallChat.id,
    messages: recallSource,
    audienceCharacterIds: [],
    budgetTokens: 1800,
    readOnly: true,
  });
  assert.equal(requests.length, beforeLexical);

  assert(exactRecall.recalledRecordIds.length > 0);
  assert(
    exactRecall.recalledRecordIds.every(
      (id) => id in exactRecall.receipt.recordRevisions && id !== exactRecall.receipt.checkpointId,
    ),
    "optional recall exposes actual persisted record IDs separately from mandatory summary revisions",
  );
  assert(
    exactRecall.recalledScenes?.includes("returns on Tuesday"),
    "lexical recall includes the later correction exactly",
  );
  assert.equal(exactRecall.receipt.recalledMessageIds.length, 3, "the scene contributes one bounded excerpt");
  assert.equal(exactRecall.recalledMessages, null, "the scene recap and excerpt use the same scene section");
  assert(exactRecall.recalledScenes?.includes("story timeframe: Spring 14 → The following morning"));
  assert(exactRecall.recalledScenes.includes("story timeframe: The following morning"));
  assert(exactRecall.recalledScenes.includes("Excerpt:\nMessages #25–#27"));
  const { estimateChatSummaryTokens } = await import("../../packages/shared/src/index.ts");
  assert(
    estimateChatSummaryTokens(exactRecall.chatSummary ?? "") <= 256,
    "the entire constant summary, including timeframe labels, respects its configured maximum",
  );
  const { eq: timelineEq } = await import("../../packages/server/src/db/file-query.ts");
  await db
    .update(advancedMemoryRecords)
    .set({ timeline: null })
    .where(timelineEq(advancedMemoryRecords.chatId, recallChat.id));
  const beforeLegacyTimeline = requests.length;
  const legacyTimeline = await memory.prepare({
    chatId: recallChat.id,
    messages: recallSource,
    audienceCharacterIds: [],
    budgetTokens: 1800,
    readOnly: true,
  });
  assert(
    legacyTimeline.recalledScenes?.includes("Spring 14 → The following morning"),
    "legacy archives recover known timeframes from validated source IDs",
  );
  assert(
    (await memory.status(recallChat.id)).records.some((record) => record.timeline?.includes("Spring 14")),
    "legacy inspector timelines use the same fallback",
  );
  assert.equal(requests.length, beforeLegacyTimeline, "legacy timeline recovery makes no model or embedding calls");

  const excerptRecords = (await memory.status(recallChat.id)).records.filter((record) => record.kind === "excerpt");
  assert(excerptRecords.length > 0, "zero limits are tested with an existing excerpt archive");
  for (const record of excerptRecords) {
    assert.equal(record.startIndex, recallSource.findIndex((message) => message.id === record.messageIds[0]) + 1);
    assert.equal(record.endIndex, recallSource.findIndex((message) => message.id === record.messageIds.at(-1)) + 1);
  }
  const fullScene = (await memory.status(recallChat.id)).records.find(
    (record) => record.kind === "scene" && record.status === "closed",
  );
  assert(fullScene);
  assert.equal(fullScene.startIndex, recallSource.findIndex((message) => message.id === fullScene.startMessageId) + 1);
  assert.equal(fullScene.endIndex, recallSource.findIndex((message) => message.id === fullScene.endMessageId) + 1);
  await memory.updateSettings(recallChat.id, { retrieveMinMessages: 0, retrieveMaxMessages: 0 });
  await assert.rejects(
    memory.validatePrepared(recallChat.id, recallSource, exactRecall.receipt),
    /settings or summary corrections changed/,
    "a previously prepared prompt cannot keep cached excerpts after disabling recall",
  );
  const noExcerpts = await memory.prepare({
    chatId: recallChat.id,
    messages: recallSource,
    audienceCharacterIds: [],
    budgetTokens: 1800,
    readOnly: true,
  });
  assert.equal(noExcerpts.recalledMessages, null);
  assert.deepEqual(noExcerpts.receipt.recalledMessageIds, []);
  assert.equal(noExcerpts.chatSummary, exactRecall.chatSummary, "zero excerpt limits preserve required continuity");
  assert.equal(noExcerpts.currentSceneSummary, exactRecall.currentSceneSummary);
  assert(noExcerpts.recalledScenes, "zero excerpt limits still permit relevant scene recall");
  assert(
    excerptRecords.every(
      (record) =>
        !noExcerpts.recalledRecordIds.includes(record.id) && !(record.id in noExcerpts.receipt.recordRevisions),
    ),
    "disabled excerpt recall contributes no cached record dependencies",
  );
  const { createAdvancedMemoryPlacement, resolveAdvancedMemoryPrompt } =
    await import("../../packages/server/src/services/prompt/advanced-memory-prompt.js");
  for (const format of ["xml", "markdown", "none"] as const) {
    const placements = [
      createAdvancedMemoryPlacement("chat_summary", format),
      createAdvancedMemoryPlacement("recalled_scenes", format),
      createAdvancedMemoryPlacement("recalled_messages", format),
    ];
    const messages = [{ role: "system", content: placements.map((placement) => placement.token).join("\n") }];
    const withoutExcerpts = resolveAdvancedMemoryPrompt(messages, placements, noExcerpts)
      .map((message) => message.content)
      .join("\n");
    assert.doesNotMatch(withoutExcerpts, /Below is a small excerpt|Recalled Messages|recalled_messages/);
    assert.match(withoutExcerpts, /Below is a summary|Included below are recalled memories/);
    assert.match(
      resolveAdvancedMemoryPrompt(messages, placements, exactRecall)
        .map((message) => message.content)
        .join("\n"),
      /Excerpt:\s+Messages #/,
      "nonzero limits retain historical excerpt prompt placement",
    );
  }
  await memory.updateSettings(recallChat.id, { retrieveMinMessages: 0, retrieveMaxMessages: 3 });
  const optionalExcerpts = await memory.prepare({
    chatId: recallChat.id,
    messages: recallSource,
    audienceCharacterIds: [],
    budgetTokens: 1800,
    readOnly: true,
  });
  assert(optionalExcerpts.recalledScenes?.includes("returns on Tuesday"), "0/N can still recall relevant excerpts");
  assert(optionalExcerpts.receipt.recalledMessageIds.length > 0);
  assert.deepEqual(
    (await memory.status(recallChat.id)).records.filter((record) => record.kind === "excerpt"),
    excerptRecords,
    "changing excerpt limits does not delete or rewrite archived records",
  );
  for (const message of recallSource.slice(-4))
    await chats.updateMessageContent(message.id, "What is the temperature and pressure inside Jupiter's atmosphere?");
  const unrelatedSource = await chats.listMessages(recallChat.id);
  // Refresh only source-derived mandatory preparation before observing the pure lexical path.
  await memory.prepare({
    chatId: recallChat.id,
    messages: unrelatedSource,
    audienceCharacterIds: [],
    budgetTokens: 1800,
  });
  const beforeUnrelated = requests.length;
  const unrelated = await memory.prepare({
    chatId: recallChat.id,
    messages: unrelatedSource,
    audienceCharacterIds: [],
    budgetTokens: 1800,
    readOnly: true,
  });
  assert.equal(requests.length, beforeUnrelated);
  assert.equal(unrelated.recalledScenes, null, "common words alone do not recall unrelated scenes");
  assert.equal(unrelated.recalledMessages, null, "common words alone do not recall unrelated source messages");
  assert(unrelated.receipt.reasons.includes("no-relevant-recall"));
  await memory.updateSettings(recallChat.id, { retrieveMinMessages: 1, retrieveMaxMessages: 3 });

  const resumeChat = await chats.create({
    name: "Paid summary resume",
    mode: "roleplay",
    characterIds: [],
    connectionId: connection!.id,
  });
  assert(resumeChat);
  await chats.patchMetadata(resumeChat.id, {
    advancedMemory: {
      ...DEFAULT_ADVANCED_MEMORY_SETTINGS,
      enabled: true,
      maxContextTokens: 16_384,
      summaryBudgetTokens: 512,
    },
  });
  await chats.createMessagesBatch(
    resumeChat.id,
    Array.from({ length: 500 }, (_, index) => ({
      role: "user" as const,
      content: `${index === 450 ? "SCENE_CHANGE " : ""}Paid batch message ${index}: a compass promise across the mountains.`,
    })),
  );
  const summaryController = new AbortController();
  const summaryResumeStart = requests.length;
  await assert.rejects(
    memory.initialize(resumeChat.id, {
      signal: summaryController.signal,
      onProgress: (event) => {
        if (event.stage === "summarizing" && event.completed === 1 && event.total > 1)
          summaryController.abort(new Error("pause paid summary"));
      },
    }),
  );
  const paidBatch = requests.slice(summaryResumeStart).find((request) => request.kind === "summary");
  assert(paidBatch);
  assert(
    !(await memory.status(resumeChat.id)).records.some((record) => record.kind === "scene" && record.content),
    "partial summaries remain private work",
  );
  await memory.initialize(resumeChat.id);
  assert.equal(
    requests
      .slice(summaryResumeStart)
      .filter((request) => request.kind === "summary" && request.text === paidBatch.text).length,
    1,
    "resume never repeats the completed paid summary batch",
  );

  const resumeSource = await chats.listMessages(resumeChat.id);
  const resumePrepared = await memory.prepare({
    chatId: resumeChat.id,
    messages: resumeSource,
    audienceCharacterIds: [],
    budgetTokens: 1000,
  });
  assert(resumePrepared.currentSceneSummary);
  const legacyId = await seedLegacyRecord(resumeChat.id, "continuity", resumeSource[449]!.id);
  await seedLegacyRecord(resumeChat.id, "temporary", resumeSource[449]!.id);
  await memory.updateRecord(resumeChat.id, legacyId, {
    content: "IMPORTED_CONTINUITY_CORRECTION",
  });
  const memoryExport = await memory.exportMemory(resumeChat.id);
  const importChat = await chats.create({
    name: "Standalone memory identity",
    mode: "roleplay",
    characterIds: [],
    connectionId: connection!.id,
  });
  assert(importChat);
  await chats.patchMetadata(importChat.id, {
    advancedMemory: {
      ...DEFAULT_ADVANCED_MEMORY_SETTINGS,
      enabled: true,
      maxContextTokens: 16_384,
      summaryBudgetTokens: 512,
    },
  });
  await chats.createMessagesBatch(
    importChat.id,
    resumeSource.map((message) => ({ role: message.role as "user" | "assistant", content: message.content })),
  );
  const importSource = await chats.listMessages(importChat.id);
  const readsBeforeImport = fullRecordReads.get(importChat.id) ?? 0;
  const importedMemory = await memory.importMemory(importChat.id, memoryExport);
  assert(importedMemory.imported > 100);
  assert(
    (fullRecordReads.get(importChat.id) ?? 0) - readsBeforeImport <= 4,
    "standalone import reuses one archive snapshot across records",
  );
  const importedContinuity = importedMemory.records.find(
    (record) => record.kind === "continuity" && record.content === "IMPORTED_CONTINUITY_CORRECTION",
  );
  assert(
    importedContinuity && importedContinuity.sceneId === `continuity-${importSource[449]!.id}`,
    "continuity import keeps its actual boundary anchor rather than the record's first source message",
  );
  assert(
    importedMemory.records.some(
      (record) => record.kind === "temporary" && record.sceneId === `temporary-${importSource[449]!.id}`,
    ),
  );
  const importedPrepared = await memory.prepare({
    chatId: importChat.id,
    messages: importSource,
    audienceCharacterIds: [],
    budgetTokens: 1000,
  });
  assert.equal(importedPrepared.chatSummary, null, "legacy continuity cannot replace Chat Summaries");
  assert.equal(
    (await memory.importMemory(importChat.id, memoryExport)).imported,
    0,
    "repeat import preserves local identities and edits",
  );

  const { eq } = await import("../../packages/server/src/db/file-query.ts");
  await db.delete(advancedMemoryRecords).where(eq(advancedMemoryRecords.id, importedContinuity.id));
  const reorderedExport = {
    ...memoryExport,
    records: [...memoryExport.records].sort(
      (left, right) => Number(right.record.kind === "continuity") - Number(left.record.kind === "continuity"),
    ),
  };
  assert.equal((await memory.importMemory(importChat.id, reorderedExport)).imported, 1);
  const reorderedPrepared = await memory.prepare({
    chatId: importChat.id,
    messages: importSource,
    audienceCharacterIds: [],
    budgetTokens: 1000,
  });
  assert.equal(reorderedPrepared.chatSummary, null, "import order cannot re-enable the retired continuity store");

  const dependencySource = await chats.create({
    name: "Standalone dependency source",
    mode: "roleplay",
    characterIds: ["alice"],
    connectionId: connection!.id,
  });
  assert(dependencySource);
  await chats.createMessagesBatch(
    dependencySource.id,
    Array.from({ length: 4 }, (_, index) => ({
      role: "user" as const,
      content: `${index === 3 ? "SCENE_CHANGE " : ""}Dependency source turn ${index}: the compass promise.`,
      extra: index === 3 ? { isConversationStart: true } : undefined,
    })),
  );
  const dependencyMessages = await chats.listMessages(dependencySource.id);
  const dependencySettings = {
    ...DEFAULT_ADVANCED_MEMORY_SETTINGS,
    enabled: true,
    maxContextTokens: 16_384,
    summaryBudgetTokens: 512,
    knowledgeStarts: { alice: null },
  };
  await chats.patchMetadata(dependencySource.id, {
    groupChatMode: "individual",
    advancedMemory: dependencySettings,
    summaryEntries: [
      {
        id: "required-manual-summary",
        kind: "rolling",
        origin: "manual",
        content: "CORRECTED_GOLD compass",
        enabled: true,
        title: "Required correction",
        sourceMode: "range",
        messageIds: dependencyMessages.slice(0, 2).map((message) => message.id),
        rangeStartIndex: 1,
        rangeEndIndex: 2,
        tokenEstimate: 6,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      },
    ],
  });
  await memory.initialize(dependencySource.id);
  const sourceManualScene = (await memory.status(dependencySource.id)).records.find(
    (record) => record.kind === "scene" && record.content,
  );
  assert(sourceManualScene);
  await memory.updateRecord(dependencySource.id, sourceManualScene.id, {
    content: "IMPORTED_DISABLED_SCENE_CORRECTION",
  });
  const dependencyPrepared = await memory.prepare({
    chatId: dependencySource.id,
    messages: dependencyMessages,
    audienceCharacterIds: [],
    audienceMode: "owner",
    budgetTokens: 3000,
  });
  assert(dependencyPrepared.chatSummary?.includes("CORRECTED_GOLD"));
  const legacyDependencyId = await seedLegacyRecord(
    dependencySource.id,
    "continuity",
    dependencyMessages[2]!.id,
    sourceManualScene,
  );
  await memory.updateRecord(dependencySource.id, legacyDependencyId, {
    content: "IMPORTED_MISSING_SUMMARY_CORRECTION",
  });
  const dependencyExport = await memory.exportMemory(dependencySource.id);
  // Older releases kept generated-summary dependencies on manually edited scenes.
  // Preserve that legacy fixture to test unsupported import and explicit recovery.
  dependencyExport.records.find((entry) => entry.record.id === sourceManualScene.id)!.record.dependencies =
    sourceManualScene.dependencies;
  const exportedDependency = dependencyExport.records.find((entry) => entry.record.id === legacyDependencyId);
  assert(
    exportedDependency?.valid &&
      exportedDependency.record.dependencies.some((dependency) => dependency.id === "summary:required-manual-summary"),
  );

  const sourceMetadata = JSON.parse((await chats.getById(dependencySource.id))!.metadata);
  await chats.patchMetadata(dependencySource.id, {
    summaryEntries: sourceMetadata.summaryEntries.map((entry: Record<string, unknown>) => ({
      ...entry,
      title: "Renamed constant summary",
      updatedAt: new Date(Date.now() + 1_000).toISOString(),
    })),
  });
  const savedCorrection = await memory.updateRecord(dependencySource.id, sourceManualScene.id, {
    content: "IMPORTED_DISABLED_SCENE_CORRECTION\nBlank lines removed.",
  });
  assert.equal(
    savedCorrection.records.find((record) => record.id === sourceManualScene.id)?.embeddingStatus,
    "pending",
    "saving a scene correction accepts its text independently of old generated-summary dependencies",
  );
  const reindexRequests = requests.length;
  await memory.reindex(dependencySource.id);
  const reindexedCorrection = await memory.status(dependencySource.id);
  assert.equal(reindexedCorrection.job.status, "ready");
  assert.equal(
    reindexedCorrection.records.find((record) => record.id === sourceManualScene.id)?.embeddingStatus,
    "vectorized",
  );
  assert(requests.slice(reindexRequests).every((request) => request.kind === "embedding"));

  const accessCorrectionChat = await chats.create({
    name: "Correcting a scene from Maukie to Pantalone",
    mode: "roleplay",
    characterIds: ["maukie", "pantalone"],
    connectionId: connection!.id,
  });
  assert(accessCorrectionChat);
  await chats.createMessagesBatch(
    accessCorrectionChat.id,
    dependencyMessages.map((message) => ({ role: "user" as const, content: message.content })),
  );
  const accessSource = await chats.listMessages(accessCorrectionChat.id);
  await chats.patchMetadata(accessCorrectionChat.id, {
    groupChatMode: "individual",
    advancedMemory: {
      ...dependencySettings,
      knowledgeStarts: { maukie: null, pantalone: accessSource[3]!.id },
    },
    summaryEntries: sourceMetadata.summaryEntries.map((entry: Record<string, unknown>) => ({
      ...entry,
      messageIds: accessSource.slice(0, 2).map((message) => message.id),
    })),
  });
  await memory.initialize(accessCorrectionChat.id);
  const accessScene = (await memory.status(accessCorrectionChat.id)).records.find(
    (record) => record.kind === "scene" && record.content && record.audienceCharacterIds.includes("maukie"),
  )!;
  assert(accessScene.dependencies.length > 0);
  await memory.updateSettings(accessCorrectionChat.id, { knowledgeStarts: { maukie: null, pantalone: null } });
  const accessMetadata = JSON.parse((await chats.getById(accessCorrectionChat.id))!.metadata);
  await chats.patchMetadata(accessCorrectionChat.id, {
    summaryEntries: accessMetadata.summaryEntries.map((entry: Record<string, unknown>) => ({
      ...entry,
      enabled: false,
    })),
  });
  await memory.updateRecord(accessCorrectionChat.id, accessScene.id, { audienceCharacterIds: ["pantalone"] });
  const beforeAccessReindex = requests.length;
  await memory.reindex(accessCorrectionChat.id);
  const indexedAccessScene = (await memory.status(accessCorrectionChat.id)).records.find(
    (record) => record.id === accessScene.id,
  )!;
  assert.equal(indexedAccessScene.content, accessScene.content, "an audience-only correction preserves summary text");
  assert.deepEqual(indexedAccessScene.audienceCharacterIds, ["pantalone"]);
  assert.equal(indexedAccessScene.embeddingStatus, "vectorized");
  assert(requests.slice(beforeAccessReindex).every((request) => request.kind === "embedding"));
  await memory.initialize(accessCorrectionChat.id);
  assert.equal(
    (await memory.status(accessCorrectionChat.id)).records.find((record) => record.id === accessScene.id)?.content,
    accessScene.content,
    "later preparation also preserves the corrected scene",
  );
  await chats.updateMessageExtra(accessSource[0]!.id, { hiddenFromAICharacterIds: ["pantalone"] });
  await memory.updateRecord(accessCorrectionChat.id, accessScene.id, { content: accessScene.content });
  for (const messageId of accessScene.messageIds)
    await chats.updateMessageExtra(messageId, { hiddenFromAICharacterIds: ["pantalone"] });
  await assert.rejects(
    memory.updateRecord(accessCorrectionChat.id, accessScene.id, { content: accessScene.content }),
    /no longer available to its selected characters/,
    "saving a correction cannot grant access to an entirely hidden scene",
  );

  const dependencyTarget = await chats.create({
    name: "Standalone dependency target",
    mode: "roleplay",
    characterIds: ["alice"],
    connectionId: connection!.id,
  });
  assert(dependencyTarget);
  await chats.createMessagesBatch(
    dependencyTarget.id,
    dependencyMessages.map((message) => ({ role: "user" as const, content: message.content })),
  );
  const targetMessages = await chats.listMessages(dependencyTarget.id);
  await chats.patchMetadata(dependencyTarget.id, {
    groupChatMode: "individual",
    advancedMemory: { ...dependencySettings, knowledgeStarts: { alice: targetMessages[2]!.id } },
  });
  await memory.initialize(dependencyTarget.id);
  const localScene = (await memory.status(dependencyTarget.id)).records.find(
    (record) => record.kind === "scene" && record.content,
  );
  assert(localScene);
  await memory.updateRecord(dependencyTarget.id, localScene.id, {
    content: "LOCAL_CORRECTION_UNCHANGED",
    enabled: false,
  });
  const beforeImportMetadata = (await chats.getById(dependencyTarget.id))!.metadata;
  const importWithMissingDependencies = {
    ...dependencyExport,
    records: [
      ...dependencyExport.records.map((transfer) =>
        transfer.record.kind === "excerpt"
          ? { ...transfer, record: { ...transfer.record, audienceCharacterIds: ["alice"] } }
          : transfer,
      ),
      {
        ...exportedDependency,
        record: {
          ...exportedDependency.record,
          id: "valid-import-control",
          kind: "temporary",
          sceneId: `temporary-${dependencyMessages[1]!.id}`,
          audienceCharacterIds: [],
          content: "VALID_IMPORTED_CONTROL",
          dependencies: [],
        },
      },
      {
        ...exportedDependency,
        record: {
          ...exportedDependency.record,
          id: "missing-record-control",
          kind: "continuity",
          sceneId: `continuity-${dependencyMessages[1]!.id}`,
          audienceCharacterIds: [],
          content: "MISSING_RECORD_CORRECTION",
          dependencies: [{ id: "record:unavailable-record", revision: "unknown" }],
        },
      },
      {
        ...exportedDependency,
        record: {
          ...exportedDependency.record,
          id: "macro-control",
          kind: "temporary",
          sceneId: `temporary-${dependencyMessages[2]!.id}`,
          audienceCharacterIds: [],
          content: "INCOMPATIBLE_MACRO_CORRECTION",
          dependencies: [{ id: "macro-variables", revision: "not-the-target-variables" }],
        },
      },
    ],
  };
  const dependencyImport = await memory.importMemory(dependencyTarget.id, importWithMissingDependencies);
  for (const content of ["MISSING_RECORD_CORRECTION", "INCOMPATIBLE_MACRO_CORRECTION"]) {
    const imported = dependencyImport.records.find((record) => record.content === content);
    assert(
      imported && !imported.enabled,
      `${content} remains inspectable but disabled without its source dependencies`,
    );
  }
  assert(
    dependencyImport.records.some(
      (record) =>
        record.kind === "excerpt" &&
        record.audienceCharacterIds.includes("alice") &&
        record.messageIds.includes(targetMessages[0]!.id) &&
        !record.enabled,
    ),
    "an imported excerpt outside current character knowledge is disabled",
  );
  assert(
    dependencyImport.records.some(
      (record) => record.kind === "excerpt" && !record.audienceCharacterIds.length && record.enabled,
    ),
    "valid imported source records stay enabled",
  );
  assert(
    dependencyImport.records.some((record) => record.content === "VALID_IMPORTED_CONTROL" && record.enabled),
    "a newly inserted compatible memory stays enabled",
  );
  const retainedLocal = dependencyImport.records.find((record) => record.id === localScene.id);
  assert.equal(retainedLocal?.content, "LOCAL_CORRECTION_UNCHANGED");
  assert.equal(retainedLocal?.enabled, false);
  assert.equal(
    (await chats.getById(dependencyTarget.id))!.metadata,
    beforeImportMetadata,
    "standalone memory import does not change target metadata authority",
  );

  const maintenanceTarget = await chats.create({
    name: "Disabled import maintenance",
    mode: "roleplay",
    characterIds: ["alice"],
    connectionId: connection!.id,
  });
  assert(maintenanceTarget);
  await chats.createMessagesBatch(
    maintenanceTarget.id,
    dependencyMessages.map((message) => ({ role: "user" as const, content: message.content })),
  );
  await chats.patchMetadata(maintenanceTarget.id, { groupChatMode: "individual", advancedMemory: dependencySettings });
  const maintenanceImport = await memory.importMemory(maintenanceTarget.id, dependencyExport);
  const disabledImportedScene = maintenanceImport.records.find(
    (record) => record.content === "IMPORTED_DISABLED_SCENE_CORRECTION",
  );
  assert(disabledImportedScene && !disabledImportedScene.enabled && disabledImportedScene.manualOverride);
  await memory.initialize(maintenanceTarget.id);
  const maintenanceStatus = await memory.status(maintenanceTarget.id);
  assert.equal(
    maintenanceStatus.job.status,
    "ready",
    "disabled unsupported manual imports do not block initialization",
  );
  assert.deepEqual(
    maintenanceStatus.records.find((record) => record.id === disabledImportedScene.id),
    disabledImportedScene,
    "maintenance preserves the disabled correction for inspection",
  );
  const maintainedPrompt = await memory.prepare({
    chatId: maintenanceTarget.id,
    messages: await chats.listMessages(maintenanceTarget.id),
    audienceCharacterIds: [],
    audienceMode: "owner",
    budgetTokens: 1000,
  });
  assert(
    ![
      maintainedPrompt.chatSummary,
      maintainedPrompt.currentSceneSummary,
      maintainedPrompt.recalledScenes,
      maintainedPrompt.recalledMessages,
    ].some((part) => part?.includes("IMPORTED_DISABLED_SCENE_CORRECTION")),
    "disabled correction text remains excluded from generation",
  );
  await memory.updateRecord(maintenanceTarget.id, disabledImportedScene.id, { enabled: true });
  await assert.rejects(
    memory.initialize(maintenanceTarget.id),
    /manually corrected memory.*changed sources/iu,
    "enabled stale manual corrections still require explicit review",
  );
  const blockedCorrection = (await memory.status(maintenanceTarget.id)).job;
  assert.equal(blockedCorrection.reviewRecordId, disabledImportedScene.id);
  assert.match(blockedCorrection.error!, /messages #1–#3 \(alice\)/u);
  assert.equal(
    (await memory.status(maintenanceTarget.id)).records.find((record) => record.id === disabledImportedScene.id)
      ?.content,
    "IMPORTED_DISABLED_SCENE_CORRECTION",
  );

  const beforeStaleReindex = requests.length;
  await memory.reindex(maintenanceTarget.id);
  assert(requests.slice(beforeStaleReindex).every((request) => request.kind === "embedding"));
  assert.equal(
    (await memory.status(maintenanceTarget.id)).records.find((record) => record.id === disabledImportedScene.id)
      ?.embeddingStatus,
    "stale",
    "reindex keeps an unreviewed legacy correction excluded instead of approving or regenerating it",
  );
  await memory.updateRecord(maintenanceTarget.id, disabledImportedScene.id, {
    content: disabledImportedScene.content,
  });
  await memory.reindex(maintenanceTarget.id);
  assert.equal(
    (await memory.status(maintenanceTarget.id)).records.find((record) => record.id === disabledImportedScene.id)
      ?.embeddingStatus,
    "vectorized",
    "saving the unchanged correction recovers a legacy stale scene without regeneration",
  );

  await memory.updateRecord(maintenanceTarget.id, disabledImportedScene.id, { enabled: false });
  const editedExcerpt = (await memory.status(maintenanceTarget.id)).records.find(
    (record) => record.kind === "excerpt" && !record.audienceCharacterIds.length && record.messageIds.length === 3,
  );
  assert(editedExcerpt);
  await memory.updateRecord(maintenanceTarget.id, editedExcerpt.id, {
    content: "DISABLED_EXCERPT_CORRECTION",
    enabled: false,
  });
  await chats.updateMessageContent(
    editedExcerpt.messageIds[0]!,
    "The source promise changed after editing this excerpt.",
  );
  const beforeExcerptMaintenance = (await memory.status(maintenanceTarget.id)).records.find(
    (record) => record.id === editedExcerpt.id,
  );
  await memory.initialize(maintenanceTarget.id);
  const afterExcerptMaintenance = await memory.status(maintenanceTarget.id);
  assert.equal(
    afterExcerptMaintenance.job.status,
    "ready",
    "a disabled corrected excerpt does not block maintenance after its source changes",
  );
  assert.deepEqual(
    afterExcerptMaintenance.records.find((record) => record.id === editedExcerpt.id),
    beforeExcerptMaintenance,
    "the disabled excerpt remains unchanged and inspectable",
  );
  await memory.updateRecord(maintenanceTarget.id, editedExcerpt.id, { enabled: true });
  await memory.initialize(maintenanceTarget.id);
  assert.equal(
    (await memory.status(maintenanceTarget.id)).job.status,
    "ready",
    "editing source text does not invalidate an existing excerpt",
  );
  assert.equal(
    (await memory.status(maintenanceTarget.id)).records.find((record) => record.id === editedExcerpt.id)?.content,
    "DISABLED_EXCERPT_CORRECTION",
  );

  const joinedChat = await chats.create({
    name: "Joined waiter cancellation",
    mode: "roleplay",
    characterIds: [],
    connectionId: connection!.id,
  });
  assert(joinedChat);
  await chats.patchMetadata(joinedChat.id, {
    advancedMemory: {
      ...DEFAULT_ADVANCED_MEMORY_SETTINGS,
      enabled: true,
      maxContextTokens: 16_384,
      summaryBudgetTokens: 512,
    },
  });
  await chats.createMessagesBatch(joinedChat.id, [
    { role: "user", content: "A compass promise." },
    { role: "assistant", content: "SCENE_CHANGE A new room." },
  ]);
  let releaseSummary: () => void = () => {};
  let summaryEntered: () => void = () => {};
  const heldSummary = new Promise<void>((resolve) => {
    releaseSummary = resolve;
  });
  const enteredSummary = new Promise<void>((resolve) => {
    summaryEntered = resolve;
  });
  beforeSummary = async () => {
    summaryEntered();
    await heldSummary;
  };
  const sharedInitialization = memory.initialize(joinedChat.id);
  await enteredSummary;
  try {
    const waiterController = new AbortController();
    const waiter = memory.initialize(joinedChat.id, { signal: waiterController.signal, blocking: true });
    const cancelledWait = assert.rejects(waiter, /joined waiter stopped/iu);
    waiterController.abort(new Error("joined waiter stopped"));
    await cancelledWait;
  } finally {
    releaseSummary();
  }
  await sharedInitialization;
  assert.equal(
    (await memory.status(joinedChat.id)).job.status,
    "ready",
    "cancelling a joined caller does not stop shared preparation",
  );

  // An archive edit must not wait for a slow background model response.
  const editableScene = (await memory.status(joinedChat.id)).records.find(
    (record) => record.kind === "scene" && record.content,
  )!;
  for (const action of ["toggle", "delete"] as const) {
    if (action === "delete") await memory.updateRecord(joinedChat.id, editableScene.id, { enabled: true });
    // Changed derived inputs still require new work; a source typo no longer does.
    await db
      .update(advancedMemoryRecords)
      .set({ dependencies: JSON.stringify([{ id: "macro-variables", revision: "previous-input" }]) })
      .where(eq(advancedMemoryRecords.id, editableScene.id));
    const waiting = new Promise<void>((resolve) => {
      summaryEntered = resolve;
    });
    const held = new Promise<void>((resolve) => {
      releaseSummary = resolve;
    });
    beforeSummary = async () => {
      summaryEntered();
      await held;
    };
    const background = memory.initialize(joinedChat.id, { blocking: false }).then(
      () => null,
      (error: unknown) => error,
    );
    await waiting;
    let timeout: ReturnType<typeof setTimeout> | undefined;
    try {
      await assert.rejects(memory.updateRecord(joinedChat.id, "missing", { enabled: false }), /not found/);
      await assert.rejects(memory.updateRecord(joinedChat.id, editableScene.id, { content: " " }), /Memory text/);
      await assert.rejects(
        memory.updateRecord(joinedChat.id, editableScene.id, {}),
        /must include content, timeframe, enabled or audience/,
      );
      await assert.rejects(memory.deleteRecord(joinedChat.id, editableScene.sceneId), /Only a saved summary/);
      assert.equal((await memory.status(joinedChat.id)).job.status, "running", "invalid edits do not cancel paid work");
      const mutation =
        action === "toggle"
          ? memory.updateRecord(joinedChat.id, editableScene.id, { enabled: false })
          : memory.deleteRecord(joinedChat.id, editableScene.id);
      const changed = await Promise.race([
        mutation,
        new Promise<never>((_, reject) => {
          timeout = setTimeout(() => reject(new Error(`${action} waited for the background model`)), 2000);
        }),
      ]);
      assert.notEqual(changed.job.status, "running", "the response includes settled cancellation progress");
      const saved = changed.records.find((record) => record.id === editableScene.id);
      if (action === "toggle") assert.equal(saved?.enabled, false);
      else assert.equal(saved, undefined);
      assert(await background, "the interrupted model operation cannot overwrite the user's edit");
    } finally {
      clearTimeout(timeout);
      releaseSummary();
      await background;
    }
  }
  const callsBeforeDeletedResume = requests.length;
  await memory.initialize(joinedChat.id);
  assert(
    !requests.slice(callsBeforeDeletedResume).some((request) => request.kind === "summary"),
    "resume keeps the deleted scene suppressed while refreshing changed source excerpts",
  );
  assert(!(await memory.status(joinedChat.id)).records.some((record) => record.id === editableScene.id));
  assert.equal(
    (await memory.status(joinedChat.id)).unpreparedScenes?.filter((scene) => scene.deleted).length,
    1,
    "deleted scene summaries are offered only for explicit recovery",
  );

  const requireServer = createRequire(new URL("../../packages/server/package.json", import.meta.url));
  const Fastify = requireServer("fastify") as typeof import("fastify").default;
  const { advancedMemoryRoutes } = await import("../../packages/server/src/routes/advanced-memory.routes.js");
  const routeApp = Fastify();
  routeApp.decorate("db", db);
  await routeApp.register(advancedMemoryRoutes, { prefix: "/api/chats" });
  try {
    const hiddenCorrection = await routeApp.inject({
      method: "PATCH",
      url: `/api/chats/${accessCorrectionChat.id}/advanced-memory/records/${accessScene.id}`,
      payload: { content: accessScene.content },
    });
    assert.equal(hiddenCorrection.statusCode, 400, "inaccessible scene sources are a correction validation error");
    assert.match(hiddenCorrection.json().error, /no longer available to its selected characters/);
    for (const limits of [
      { retrieveMinMessages: 0, retrieveMaxMessages: 0 },
      { retrieveMinMessages: 0, retrieveMaxMessages: 3 },
      { retrieveMinMessages: 1, retrieveMaxMessages: 3 },
    ]) {
      const updated = await routeApp.inject({
        method: "PATCH",
        url: `/api/chats/${recallChat.id}/advanced-memory/settings`,
        payload: limits,
      });
      assert.equal(updated.statusCode, 200, "zero and positive excerpt limits are accepted by the settings API");
      const persisted = await routeApp.inject({ method: "GET", url: `/api/chats/${recallChat.id}/advanced-memory` });
      assert.equal(persisted.statusCode, 200);
      assert.equal(persisted.json().settings.retrieveMinMessages, limits.retrieveMinMessages);
      assert.equal(persisted.json().settings.retrieveMaxMessages, limits.retrieveMaxMessages);
      assert.equal(persisted.json().settings.enabled, true, "zero limits do not reset the remaining settings");
    }
    const invalidReindex = await routeApp.inject({
      method: "POST",
      url: `/api/chats/${joinedChat.id}/advanced-memory/reindex`,
      payload: { debugMode: "invalid" },
    });
    assert.equal(invalidReindex.statusCode, 400);
    assert.match(
      invalidReindex.json().error,
      /debugMode/,
      "reindex exposes the same validation detail as initialization",
    );
    let releaseEmbedding = () => {};
    const heldEmbedding = new Promise<void>((resolve) => {
      releaseEmbedding = resolve;
    });
    beforeEmbedding = () => heldEmbedding;
    const beforeRouteReindex = requests.length;
    try {
      const reindexResponse = await routeApp.inject({
        method: "POST",
        url: `/api/chats/${audienceChat.id}/advanced-memory/reindex`,
        payload: {},
      });
      assert.equal(reindexResponse.statusCode, 202);
      assert.equal(reindexResponse.json().job.status, "running", "reindex acknowledges persisted progress before 202");
      assert.equal(reindexResponse.json().job.stage, "indexing");
      await memory.cancel(audienceChat.id);
    } finally {
      releaseEmbedding();
      beforeEmbedding = null;
    }
    await memory.reindex(audienceChat.id);
    assert.equal((await memory.status(audienceChat.id)).job.status, "ready");
    assert(
      requests.slice(beforeRouteReindex).every((request) => request.kind === "embedding"),
      "cancel/retry reindex never starts scene or summary generation",
    );
    let releaseFirstIndex = () => {};
    let firstIndexEntered = () => {};
    const firstIndexReady = new Promise<void>((resolve) => {
      firstIndexEntered = resolve;
    });
    const firstIndexGate = new Promise<void>((resolve) => {
      releaseFirstIndex = resolve;
    });
    beforeEmbedding = async () => {
      firstIndexEntered();
      await firstIndexGate;
    };
    const firstIndex = memory.reindex(audienceChat.id, { blocking: false });
    await firstIndexReady;
    const firstIndexId = (await memory.status(audienceChat.id)).job.id;
    const queuedJobIds: Array<string | undefined> = [];
    const queuedIndex = memory.reindex(audienceChat.id, {
      blocking: true,
      onProgress: (job) => queuedJobIds.push(job.id),
    });
    releaseFirstIndex();
    await Promise.all([firstIndex, queuedIndex]);
    assert(queuedJobIds.length > 0);
    assert(
      queuedJobIds.every((id) => id !== firstIndexId),
      "queued reindex progress belongs to its own job, never the existing operation",
    );
    const invalidSettings = { retrieveMinMessages: 10, retrieveMaxMessages: 2 };
    assert.equal(
      (
        await routeApp.inject({
          method: "POST",
          url: `/api/chats/${joinedChat.id}/advanced-memory/initialize`,
          payload: { settings: invalidSettings },
        })
      ).statusCode,
      400,
    );
    assert.equal(
      (
        await routeApp.inject({
          method: "PATCH",
          url: `/api/chats/${joinedChat.id}/advanced-memory/settings`,
          payload: invalidSettings,
        })
      ).statusCode,
      400,
    );
    assert.equal(
      (
        await routeApp.inject({
          method: "PATCH",
          url: `/api/chats/${chat.id}/advanced-memory/records/${(await memory.status(chat.id)).records.find((record) => record.content)!.id}`,
          payload: { content: "   " },
        })
      ).statusCode,
      400,
    );
    assert.equal(
      (
        await routeApp.inject({
          method: "PATCH",
          url: `/api/chats/${joinedChat.id}/advanced-memory/records/not-found`,
          payload: { enabled: false },
        })
      ).statusCode,
      404,
    );
    assert.equal(
      (
        await routeApp.inject({
          method: "GET",
          url: `/api/chats/${joinedChat.id}/advanced-memory/records/not-found/sources`,
        })
      ).statusCode,
      404,
    );
    const legacyTemplate = (await memory.status(chat.id)).records.find((record) => record.content)!;
    for (const kind of ["continuity", "temporary"] as const) {
      const legacy = await seedLegacyRecord(chat.id, kind, source[449]!.id, legacyTemplate);
      const beforeDelete = await chats.listMessages(chat.id);
      const response = await routeApp.inject({
        method: "DELETE",
        url: `/api/chats/${chat.id}/advanced-memory/records/${legacy}`,
      });
      assert.equal(response.statusCode, 200, response.body);
      assert(!response.json().records.some((record: { id: string }) => record.id === legacy));
      assert.deepEqual(
        await chats.listMessages(chat.id),
        beforeDelete,
        "deleting legacy summaries preserves source messages",
      );
      await seedLegacyRecord(chat.id, kind, source[449]!.id, legacyTemplate);
    }
    const beforeReset = await memory.status(chat.id);
    assert.deepEqual(
      new Set(beforeReset.records.map((record) => record.kind)),
      new Set(["scene", "continuity", "temporary", "excerpt"]),
    );
    const resetSource = await chats.listMessages(chat.id);
    const resetResponse = await routeApp.inject({ method: "DELETE", url: `/api/chats/${chat.id}/advanced-memory` });
    assert.equal(resetResponse.statusCode, 200);
    const cleared = resetResponse.json();
    assert.deepEqual(cleared.records, []);
    assert.equal(cleared.job.status, "idle");
    assert.equal(cleared.job.completed, 0);
    assert.equal(cleared.job.processedMessageId, undefined);
    assert.equal(cleared.job.classifiedMessageId, undefined);
    assert.equal(cleared.latestReceipt, undefined);
    assert.deepEqual(cleared.settings, beforeReset.settings);
    assert.deepEqual(await chats.listMessages(chat.id), resetSource, "reset never edits the original transcript");
    assert.deepEqual(
      await db.select().from(advancedMemoryRecords).where(eq(advancedMemoryRecords.chatId, chat.id)),
      [],
    );
  } finally {
    await routeApp.close();
  }
  const failureApp = Fastify();
  failureApp.decorate(
    "db",
    new Proxy(db, {
      get(target, key, receiver) {
        if (key === "select")
          return () => {
            throw new Error("Unexpected storage failure");
          };
        return Reflect.get(target, key, receiver);
      },
    }),
  );
  await failureApp.register(advancedMemoryRoutes, { prefix: "/api/chats" });
  try {
    assert.equal(
      (
        await failureApp.inject({
          method: "PATCH",
          url: `/api/chats/${joinedChat.id}/advanced-memory/settings`,
          payload: {},
        })
      ).statusCode,
      500,
      "unknown storage failures remain server errors",
    );
  } finally {
    await failureApp.close();
  }

  const markerChat = await chats.create({
    name: "Historical marker compaction",
    mode: "roleplay",
    characterIds: ["alice"],
    connectionId: connection!.id,
  });
  assert(markerChat);
  await chats.patchMetadata(markerChat.id, {
    groupChatMode: "individual",
    advancedMemory: {
      ...DEFAULT_ADVANCED_MEMORY_SETTINGS,
      enabled: true,
      maxContextTokens: 16_384,
      summaryBudgetTokens: 512,
      knowledgeStarts: { alice: null },
    },
  });
  await chats.createMessagesBatch(
    markerChat.id,
    Array.from({ length: 40 }, (_, index) => ({
      role: "user" as const,
      content: `Earlier allowed compass promise ${index} remains part of this historical conversation.`,
      extra: index === 35 ? { conversationStartForCharacterIds: ["alice"] } : undefined,
    })),
  );
  const markerSource = await chats.listMessages(markerChat.id);
  const historicalMarker = await memory.prepare({
    chatId: markerChat.id,
    messages: markerSource.slice(0, 30),
    audienceCharacterIds: ["alice"],
    budgetTokens: 700,
  });
  assert(historicalMarker.currentSceneSummary, "historical prefix must compact despite a later manual start");
  await memory.validatePrepared(markerChat.id, markerSource.slice(0, 30), historicalMarker.receipt);
  await assert.rejects(
    memory.prepare({
      chatId: markerChat.id,
      messages: markerSource,
      audienceCharacterIds: [],
      budgetTokens: 3000,
      readOnly: true,
    }),
    /requires a responding character/iu,
  );
  const owner = await memory.prepare({
    chatId: markerChat.id,
    messages: markerSource,
    audienceCharacterIds: [],
    audienceMode: "owner",
    budgetTokens: 3000,
    readOnly: true,
  });
  assert(
    owner.messageIds.every((id) => markerSource.slice(35).some((message) => message.id === id)),
    "explicit owner mode keeps manual start rules",
  );

  const hiddenMiddleChat = await chats.create({
    name: "Private partial cache",
    mode: "roleplay",
    characterIds: ["alice", "bob"],
    connectionId: connection!.id,
  });
  assert(hiddenMiddleChat);
  await chats.patchMetadata(hiddenMiddleChat.id, {
    groupChatMode: "individual",
    advancedMemory: {
      ...DEFAULT_ADVANCED_MEMORY_SETTINGS,
      enabled: true,
      maxContextTokens: 16_384,
      summaryBudgetTokens: 512,
      knowledgeStarts: { alice: null, bob: null },
    },
  });
  await chats.createMessagesBatch(
    hiddenMiddleChat.id,
    Array.from({ length: 300 }, (_, index) => ({
      role: "user" as const,
      content: `${index === 250 ? "SCENE_CHANGE " : ""}${index === 50 ? "HIDDEN_MIDDLE_SECRET" : "Shared compass promise along the mountain path. ".repeat(2)} ${index}.`,
      extra: index === 50 ? { hiddenFromAI: true } : index === 51 ? { hiddenFromAICharacterIds: ["bob"] } : undefined,
    })),
  );
  const privateController = new AbortController();
  const beforePrivateCache = requests.length;
  await assert.rejects(
    memory.initialize(hiddenMiddleChat.id, {
      signal: privateController.signal,
      onProgress: (event) => {
        if (event.stage === "summarizing" && event.completed === 1 && event.total > 1)
          privateController.abort(new Error("pause scoped summary"));
      },
    }),
  );
  assert.equal(
    (await memory.status(hiddenMiddleChat.id)).job.status,
    "cancelled",
    "a discontiguous scoped partial result can checkpoint before cancellation",
  );
  const firstPrivateBatch = requests.slice(beforePrivateCache).find((request) => request.kind === "summary");
  assert(firstPrivateBatch?.text.includes("HIDDEN_MIDDLE_SECRET"), "global hides stay in resumable summary batches");
  const privateResumeStart = requests.length;
  await memory.initialize(hiddenMiddleChat.id);
  assert.notEqual(
    requests.slice(privateResumeStart).find((request) => request.kind === "summary")?.text,
    firstPrivateBatch.text,
    "scoped summary resumes after its already paid batch",
  );

  const confirmationChat = await chats.create({
    name: "Confirmation progress",
    mode: "roleplay",
    characterIds: ["newcomer"],
    connectionId: connection!.id,
  });
  assert(confirmationChat);
  await chats.createMessagesBatch(confirmationChat.id, [{ role: "user", content: "Earlier conversation." }]);
  await chats.patchMetadata(confirmationChat.id, {
    groupChatMode: "individual",
    advancedMemory: { ...DEFAULT_ADVANCED_MEMORY_SETTINGS, enabled: true },
  });
  let confirmationShown = false;
  await assert.rejects(
    memory.initialize(confirmationChat.id, {
      blocking: true,
      onProgress: (event) => {
        if (event.status === "needs_confirmation") confirmationShown = !!event.id && event.blocking === true;
      },
    }),
  );
  assert(confirmationShown, "first-use knowledge confirmation carries a blocking drawer job");

  const raceChat = await chats.create({
    name: "Source race",
    mode: "roleplay",
    characterIds: [],
    connectionId: connection!.id,
  });
  assert(raceChat);
  await chats.createMessagesBatch(raceChat.id, [
    { role: "user", content: "Original event." },
    { role: "assistant", content: "SCENE_CHANGE A new room." },
  ]);
  await chats.patchMetadata(raceChat.id, {
    advancedMemory: {
      ...DEFAULT_ADVANCED_MEMORY_SETTINGS,
      enabled: true,
      maxContextTokens: 16_384,
      summaryBudgetTokens: 512,
    },
  });
  const raceSource = await chats.listMessages(raceChat.id);
  beforeSummary = async () => {
    await chats.updateMessageContent(raceSource[0]!.id, "Changed while summarizing.");
  };
  await assert.rejects(memory.initialize(raceChat.id), /messages changed|sources.*changed/iu);
  assert(
    !(await memory.status(raceChat.id)).records.some((record) => record.kind === "scene" && record.content),
    "a stale model result is not committed",
  );
  const cadenceChat = await chats.create({
    name: "Post-generation scene cadence",
    mode: "roleplay",
    characterIds: [],
    connectionId: connection!.id,
  });
  assert(cadenceChat);
  await memory.updateSettings(cadenceChat.id, {
    enabled: true,
    maxContextTokens: 16_384,
    summaryBudgetTokens: 512,
    sceneCheckInterval: 5,
  });
  await memory.initialize(cadenceChat.id);
  const classifyCount = () => requests.filter((request) => request.kind === "classify").length;
  const beforeOngoing = classifyCount();
  await chats.createMessagesBatch(
    cadenceChat.id,
    Array.from({ length: 4 }, (_, index) => ({
      role: index % 2 ? ("assistant" as const) : ("user" as const),
      content: `Recent scene message ${index}.`,
    })),
  );
  await memory.prepare({
    chatId: cadenceChat.id,
    messages: await chats.listMessages(cadenceChat.id),
    audienceCharacterIds: [],
    budgetTokens: 3000,
  });
  assert.equal(classifyCount(), beforeOngoing, "ongoing pre-generation preparation never calls the scene classifier");
  assert.equal(
    await memory.getSceneCheck(cadenceChat.id),
    null,
    "four new messages are below the default five-message cadence",
  );
  await chats.createMessage({
    chatId: cadenceChat.id,
    role: "assistant",
    content: "The fifth message closes a later episode.",
  });
  const cadenceSource = await chats.listMessages(cadenceChat.id);
  const sceneRequest = await memory.getSceneCheck(cadenceChat.id);
  assert(sceneRequest);
  assert.deepEqual(
    sceneRequest.messages.map((message) => message.messageId),
    cadenceSource.map((message) => message.id),
  );
  assert(
    await memory.commitSceneCheck(cadenceChat.id, sceneRequest, {
      ends: [{ messageNumber: 2 }, { messageNumber: 4 }],
    }),
  );
  const pendingScenes = (await memory.status(cadenceChat.id)).unpreparedScenes!;
  assert.deepEqual(
    pendingScenes.map(({ startIndex, endIndex }) => [startIndex, endIndex]),
    [
      [1, 2],
      [3, 4],
    ],
    "closed scenes without summaries remain visible",
  );
  const repairRequests = requests.length;
  const repairState = JSON.parse((await chats.getById(cadenceChat.id))!.metadata).advancedMemoryState;
  await chats.patchMetadata(cadenceChat.id, {
    advancedMemoryState: { ...repairState, status: "error", error: "The summary provider stopped responding." },
  });
  await memory.initialize(cadenceChat.id, { sceneId: pendingScenes[0]!.sceneId });
  assert.equal(
    (await memory.status(cadenceChat.id)).job.error,
    null,
    "successful recovery clears the previous summary failure",
  );
  assert.equal(
    JSON.parse((await chats.getById(cadenceChat.id))!.metadata).advancedMemoryState.sceneCheckMessageId,
    repairState.sceneCheckMessageId,
    "targeted recovery preserves scene-check cadence",
  );
  const afterRepairJob = (await memory.status(cadenceChat.id)).job;
  const beforeRepairRetry = requests.length;
  await memory.initialize(cadenceChat.id, { sceneId: pendingScenes[0]!.sceneId });
  assert.deepEqual((await memory.status(cadenceChat.id)).job, afterRepairJob);
  assert.equal(requests.length, beforeRepairRetry, "retrying a completed repair is a no-op");
  assert.equal(requests.slice(repairRequests).filter((request) => request.kind === "summary").length, 1);
  assert(
    !requests.slice(repairRequests).some((request) => request.kind === "classify"),
    "targeted repair does not reclassify history",
  );
  assert.deepEqual(
    (await memory.status(cadenceChat.id)).unpreparedScenes!.map(({ startIndex, endIndex }) => [startIndex, endIndex]),
    [[3, 4]],
  );
  // A missing scaffold must not make the range disappear either.
  await db.delete(advancedMemoryRecords).where(eq(advancedMemoryRecords.id, pendingScenes[1]!.sceneId));
  const existingRecoveredRow = (
    await db.select().from(advancedMemoryRecords).where(eq(advancedMemoryRecords.chatId, cadenceChat.id))
  ).find((record) => record.kind === "scene" && record.content)!;
  await db.insert(advancedMemoryRecords).values({
    ...existingRecoveredRow,
    id: "obsolete-overlapping-summary",
    endMessageId: cadenceSource[3]!.id,
    messageIds: JSON.stringify(cadenceSource.slice(0, 4).map((message) => message.id)),
  });
  assert.deepEqual(
    (await memory.status(cadenceChat.id)).unpreparedScenes!.map(({ startIndex, endIndex }) => [startIndex, endIndex]),
    [[3, 4]],
  );
  await memory.maintain(cadenceChat.id);
  assert.deepEqual((await memory.status(cadenceChat.id)).unpreparedScenes, []);
  const cadenceRecords = (await memory.status(cadenceChat.id)).records;
  assert.equal(
    cadenceRecords.filter((record) => record.kind === "scene" && record.status === "closed").length,
    2,
    "one delayed decision retains multiple scene boundaries",
  );
  assert.equal(
    classifyCount(),
    beforeOngoing,
    "tracker commits and archive maintenance do not launch another classifier",
  );
  const editedScene = cadenceRecords.find((record) => record.kind === "scene" && record.status === "closed")!;
  await memory.updateRecord(cadenceChat.id, editedScene.id, { content: "CORRECTED_GOLD compass." });
  await memory.reindex(cadenceChat.id);
  await chats.updateMessageContent(cadenceSource[0]!.id, "A corrected compass promise.");
  await chats.updateMessageExtra(cadenceSource[0]!.id, {
    isConversationStart: true,
    attachments: [{ type: "image", url: "/later-illustration.png" }],
  });
  const afterTypo = (await memory.status(cadenceChat.id)).records.find((record) => record.id === editedScene.id)!;
  assert.equal(
    await memory.getSceneCheck(cadenceChat.id),
    null,
    "old edits and illustrations do not restart scene checks",
  );
  assert.equal(afterTypo.embeddingStatus, "vectorized", "text edits and illustrations keep saved scene indexes");
  assert.equal(afterTypo.content, "CORRECTED_GOLD compass.");
  const typoRequests = requests.length;
  await memory.maintain(cadenceChat.id);
  assert.equal(requests.length, typoRequests, "unchanged scene ranges reuse completed summaries and vectors");
  await chats.updateMessageExtra(cadenceSource[4]!.id, { isConversationStart: true });
  const recallCurrent = async () =>
    memory.prepare({
      chatId: cadenceChat.id,
      messages: await chats.listMessages(cadenceChat.id),
      audienceCharacterIds: [],
      budgetTokens: 3000,
      readOnly: true,
    });
  assert(
    (await recallCurrent()).recalledScenes?.includes("A corrected compass promise."),
    "recall uses edited source text without reindexing",
  );
  const swipe = await chats.addSwipe(cadenceSource[1]!.id, "ACTIVE_SWIPE compass promise.");
  const swipedRecall = await recallCurrent();
  assert.equal(
    await memory.getSceneCheck(cadenceChat.id),
    null,
    "switching swipes is not a new message for scene-check cadence",
  );
  assert(swipedRecall.recalledScenes?.includes("ACTIVE_SWIPE compass promise."));
  assert(!swipedRecall.recalledScenes?.includes("Recent scene message 1."));
  await chats.setActiveSwipe(cadenceSource[1]!.id, 0);
  assert.equal(swipe.index, 1);
  const restoredRecall = await recallCurrent();
  assert(restoredRecall.recalledScenes?.includes("Recent scene message 1."));
  assert(!restoredRecall.recalledScenes?.includes("ACTIVE_SWIPE compass promise."));
  const beforeSwipeMaintenance = requests.length;
  await memory.maintain(cadenceChat.id);
  assert.equal(requests.length, beforeSwipeMaintenance, "switching swipes retains completed indexes");
  assert.equal(
    (await memory.status(cadenceChat.id)).records.filter((record) => record.kind === "scene" && record.content).length,
    2,
    "switching swipes does not duplicate scenes",
  );
  // Repairing a different gap must leave a genuinely blocked correction intact.
  await db
    .update(advancedMemoryRecords)
    .set({ dependencies: JSON.stringify([{ id: "macro-variables", revision: "old-input" }]) })
    .where(eq(advancedMemoryRecords.id, editedScene.id));
  await db.delete(advancedMemoryRecords).where(eq(advancedMemoryRecords.sceneId, pendingScenes[1]!.sceneId));
  const beforeIsolatedRepair = (await memory.status(cadenceChat.id)).records.find(
    (record) => record.id === editedScene.id,
  )!;
  await chats.patchMetadata(cadenceChat.id, {
    advancedMemoryState: {
      ...JSON.parse((await chats.getById(cadenceChat.id))!.metadata).advancedMemoryState,
      status: "error",
      error: "Review the saved correction.",
      reviewRecordId: editedScene.id,
    },
  });
  await memory.initialize(cadenceChat.id, { sceneId: pendingScenes[1]!.sceneId });
  const isolatedRepair = await memory.status(cadenceChat.id);
  assert.deepEqual(
    isolatedRepair.records.find((record) => record.id === editedScene.id),
    beforeIsolatedRepair,
  );
  assert.equal(isolatedRepair.job.reviewRecordId, editedScene.id);
  assert.equal(isolatedRepair.job.status, "error");
  assert.deepEqual(isolatedRepair.unpreparedScenes, []);
  await memory.updateRecord(cadenceChat.id, editedScene.id, { content: "CORRECTED_GOLD compass." });
  await chats.createMessagesBatch(
    cadenceChat.id,
    Array.from({ length: 5 }, (_, index) => ({ role: "assistant" as const, content: `New window message ${index}.` })),
  );
  sceneFinishReason = "error";
  await assert.rejects(memory.checkScenesAfterGeneration(cadenceChat.id), /did not complete/);
  assert.equal(
    JSON.parse((await chats.getById(cadenceChat.id))!.metadata as string).advancedMemoryState.sceneCheckMessageId,
    cadenceSource[4]!.id,
    "valid-looking JSON from an errored completion cannot advance the scene cursor",
  );
  sceneFinishReason = "stop";
  const beforeConcurrentChecks = classifyCount();
  await Promise.all([
    memory.checkScenesAfterGeneration(cadenceChat.id),
    memory.checkScenesAfterGeneration(cadenceChat.id),
  ]);
  assert.equal(
    classifyCount() - beforeConcurrentChecks,
    1,
    "concurrent due checks share the committed cursor rather than rebilling the same window",
  );
  assert(
    (await memory.status(cadenceChat.id)).records.some(
      (record) => record.id === editedScene.id && record.content === "CORRECTED_GOLD compass." && record.manualOverride,
    ),
    "post-generation scaffolds preserve manual scene corrections",
  );
  const latestSceneSource = await chats.listMessages(cadenceChat.id);
  const olderCheck = await memory.getSceneCheck(cadenceChat.id, { force: true, asOfMessageId: cadenceSource[4]!.id });
  assert(olderCheck);
  assert.equal(
    await memory.commitSceneCheck(cadenceChat.id, olderCheck, { ends: [] }),
    false,
    "an older regenerated window cannot overwrite a later checked timeline",
  );
  assert.equal(
    JSON.parse((await chats.getById(cadenceChat.id))!.metadata as string).advancedMemoryState.sceneCheckMessageId,
    latestSceneSource.at(-1)!.id,
  );
  const staleCheck = await memory.getSceneCheck(cadenceChat.id, { force: true });
  assert(staleCheck);
  await chats.updateMessageContent(latestSceneSource.at(-1)!.id, "A changed latest swipe opens a new room.");
  assert.equal(
    await memory.commitSceneCheck(cadenceChat.id, staleCheck, { ends: [] }),
    false,
    "a changed source cannot commit an old scene decision",
  );
  assert.equal(await memory.getSceneCheck(cadenceChat.id), null, "editing checked text does not advance the cadence");
  const changedCheck = await memory.getSceneCheck(cadenceChat.id, { force: true });
  assert(changedCheck);
  assert(
    await memory.commitSceneCheck(cadenceChat.id, changedCheck, {
      ends: [{ messageNumber: latestSceneSource.length - 1 }],
    }),
  );
  await memory.maintain(cadenceChat.id);
  await chats.updateMessageContent(latestSceneSource.at(-1)!.id, "The rerolled reply stays in the same room.");
  const rerolledCheck = await memory.getSceneCheck(cadenceChat.id, { force: true });
  assert(rerolledCheck);
  assert(await memory.commitSceneCheck(cadenceChat.id, rerolledCheck, { ends: [] }));
  assert(
    !(await memory.status(cadenceChat.id)).records.some(
      (record) => record.id === `scene-${latestSceneSource.at(-1)!.id}`,
    ),
    "the old swipe's boundary is removed when its replacement has none",
  );
  assert.equal(
    (await chats.listMessages(cadenceChat.id)).length,
    latestSceneSource.length,
    "delayed and replaced decisions never delete source history",
  );
  const filteredCheck = await memory.getSceneCheck(cadenceChat.id, { force: true });
  assert(filteredCheck);
  await chats.createMessage({ chatId: cadenceChat.id, role: "user", content: "A further source message." });
  const filteredNewCheck = await memory.getSceneCheck(cadenceChat.id, { force: true });
  assert(filteredNewCheck);
  const withheld = filteredNewCheck.messages[0]!;
  await assert.rejects(
    memory.commitSceneCheck(
      cadenceChat.id,
      { ...filteredNewCheck, messages: filteredNewCheck.messages.slice(1) },
      { ends: [{ messageNumber: withheld.messageNumber }] },
    ),
    /invalid scene decision/,
    "tracker output cannot use an ID omitted from its character-scoped payload",
  );
  const preservedEnd = filteredNewCheck.messages[2]!;
  const preservedBoundary = (await chats.listMessages(cadenceChat.id))[preservedEnd.messageNumber]!.id;
  assert(
    await memory.commitSceneCheck(cadenceChat.id, filteredNewCheck, {
      ends: [{ messageNumber: preservedEnd.messageNumber }],
    }),
  );
  await chats.createMessage({ chatId: cadenceChat.id, role: "assistant", content: "Another tracker-scoped reply." });
  const partialWindow = await memory.getSceneCheck(cadenceChat.id, { force: true });
  assert(partialWindow && partialWindow.windowStartMessageId !== preservedBoundary);
  assert(
    await memory.commitSceneCheck(
      cadenceChat.id,
      {
        ...partialWindow,
        messages: partialWindow.messages.filter((message) => message.messageId !== preservedEnd.messageId),
      },
      { ends: [] },
    ),
  );
  assert(
    (await memory.status(cadenceChat.id)).records.some((record) => record.id === `scene-${preservedBoundary}`),
    "a filtered tracker cannot erase a valid boundary whose source was never sent to it",
  );

  const deferredHistory = await chats.create({
    name: "Explicit historical segmentation",
    mode: "roleplay",
    characterIds: [],
    connectionId: connection!.id,
  });
  assert(deferredHistory);
  await memory.updateSettings(deferredHistory.id, {
    enabled: true,
    maxContextTokens: 16_384,
    summaryBudgetTokens: 512,
  });
  await chats.createMessagesBatch(deferredHistory.id, [
    { role: "user", content: "An older scene." },
    { role: "assistant", content: "SCENE_CHANGE The party reaches another town." },
  ]);
  const beforeDeferred = classifyCount();
  await memory.maintain(deferredHistory.id);
  assert.equal(classifyCount(), beforeDeferred);
  await memory.prepare({
    chatId: deferredHistory.id,
    messages: await chats.listMessages(deferredHistory.id),
    audienceCharacterIds: [],
    budgetTokens: 3000,
  });
  assert.equal(
    classifyCount(),
    beforeDeferred,
    "ordinary recall never backfills history or reruns the scene classifier",
  );
  await chats.createMessage({
    chatId: deferredHistory.id,
    role: "assistant",
    content: "SCENE_CHANGE Another episode begins.",
  });
  const pendingSource = await chats.listMessages(deferredHistory.id);
  let signalInitialSummary!: () => void;
  let releaseInitialSummary!: () => void;
  const initialSummaryEntered = new Promise<void>((resolve) => {
    signalInitialSummary = resolve;
  });
  const initialSummaryHeld = new Promise<void>((resolve) => {
    releaseInitialSummary = resolve;
  });
  beforeSummary = async () => {
    signalInitialSummary();
    await initialSummaryHeld;
  };
  let signalResetTransaction!: () => void;
  let releaseResetTransaction!: () => void;
  const resetTransactionEntered = new Promise<void>((resolve) => {
    signalResetTransaction = resolve;
  });
  const resetTransactionHeld = new Promise<void>((resolve) => {
    releaseResetTransaction = resolve;
  });
  const originalTransaction = db.transaction.bind(db);
  let holdResetTransaction = false;
  db.transaction = (async (...args: Parameters<typeof originalTransaction>) => {
    if (holdResetTransaction) {
      holdResetTransaction = false;
      signalResetTransaction();
      await resetTransactionHeld;
    }
    return originalTransaction(...args);
  }) as typeof db.transaction;
  let queuedReset: ReturnType<typeof memory.reset> | undefined;
  let pendingInitialization: Promise<void> | undefined;
  try {
    pendingInitialization = memory.initialize(deferredHistory.id, {
      onProgress: (event) => {
        if (event.status !== "ready" || queuedReset) return;
        holdResetTransaction = true;
        queuedReset = memory.reset(deferredHistory.id);
      },
    });
    await initialSummaryEntered;
    const pendingPreparation = memory.prepare({
      chatId: deferredHistory.id,
      messages: pendingSource,
      audienceCharacterIds: [],
      budgetTokens: 3000,
    });
    const preparationBeforeReset = await pendingPreparation;
    await memory.validatePrepared(deferredHistory.id, pendingSource, preparationBeforeReset.receipt);
    releaseInitialSummary();
    await resetTransactionEntered;
    await assert.rejects(
      memory.initialize(deferredHistory.id),
      /being reset/iu,
      "pending prepare cannot overwrite the reset operation after its initialization wait",
    );
    await assert.rejects(
      memory.prepare({
        chatId: deferredHistory.id,
        messages: pendingSource,
        audienceCharacterIds: [],
        budgetTokens: 3000,
        readOnly: true,
      }),
      /being reset/iu,
    );
    releaseResetTransaction();
    await pendingInitialization;
    await queuedReset;
    await assert.rejects(
      memory.validatePrepared(deferredHistory.id, pendingSource, preparationBeforeReset.receipt),
      /changed/iu,
    );
    const postResetPreview = await memory.prepare({
      chatId: deferredHistory.id,
      messages: pendingSource,
      audienceCharacterIds: [],
      budgetTokens: 3000,
      readOnly: true,
    });
    await memory.validatePrepared(deferredHistory.id, pendingSource, postResetPreview.receipt);
    assert.deepEqual(
      (await memory.status(deferredHistory.id)).records,
      [],
      "read-only preparation waits for a consistent reset snapshot and never recreates records",
    );
  } finally {
    releaseInitialSummary();
    releaseResetTransaction();
    db.transaction = originalTransaction;
    await pendingInitialization?.catch(() => undefined);
    await queuedReset?.catch(() => undefined);
  }

  const pauseChat = await chats.create({
    name: "Initial preparation stays paused",
    mode: "roleplay",
    characterIds: [],
    connectionId: connection!.id,
  });
  assert(pauseChat);
  await chats.createMessagesBatch(pauseChat.id, [
    { role: "user", content: "An earlier compass promise." },
    { role: "assistant", content: "The first promise is kept." },
    { role: "user", content: "SCENE_CHANGE A second compass journey." },
    { role: "assistant", content: "The second journey continues." },
    { role: "user", content: "SCENE_CHANGE The present scene." },
  ]);
  await memory.updateSettings(pauseChat.id, { enabled: true, summaryBudgetTokens: 512 });
  let signalPausedSummary!: () => void;
  let releasePausedSummary!: () => void;
  const pausedSummaryEntered = new Promise<void>((resolve) => (signalPausedSummary = resolve));
  const heldPausedSummary = new Promise<void>((resolve) => (releasePausedSummary = resolve));
  beforeSummary = async () => {
    beforeSummary = async () => {
      signalPausedSummary();
      await heldPausedSummary;
    };
  };
  const initialPreparation = memory.initialize(pauseChat.id);
  const pausedPreparation = assert.rejects(initialPreparation, /cancel|abort/iu);
  try {
    await pausedSummaryEntered;
    await memory.cancel(pauseChat.id);
    await pausedPreparation;
    const keptSummary = (await memory.status(pauseChat.id)).records.find(
      (record) => record.kind === "scene" && record.content,
    );
    assert(keptSummary, "pausing initial setup retains already completed summaries");
    await chats.createMessage({
      chatId: pauseChat.id,
      role: "assistant",
      content: "A new reply while memory is paused.",
    });
    const pausedService = createAdvancedMemoryService(db); // A fresh service reads the persisted pause state.
    const callsWhilePaused = requests.length;
    assert.equal(
      await pausedService.getSceneCheck(pauseChat.id, { force: true }),
      null,
      "paused scene checks cannot enter a tracker batch",
    );
    await pausedService.checkScenesAfterGeneration(pauseChat.id, { maxRequestInputTokens: 1000 });
    assert.equal(requests.length, callsWhilePaused, "a new reply cannot restart paid background work while paused");
    assert.equal((await pausedService.status(pauseChat.id)).job.status, "cancelled");
    assert.equal((await pausedService.status(pauseChat.id)).job.paused, true);
    const pausedSource = await chats.listMessages(pauseChat.id);
    const pausedPrompt = await pausedService.prepare({
      chatId: pauseChat.id,
      messages: pausedSource,
      audienceCharacterIds: [],
      budgetTokens: 4000,
      readOnly: true,
    });
    assert.equal(
      pausedPrompt.messageIds.at(-1),
      pausedSource.at(-1)!.id,
      "saved-memory reads still support a new reply",
    );
    assert.equal(
      (await pausedService.status(pauseChat.id)).records.find((record) => record.id === keptSummary.id)?.content,
      keptSummary.content,
    );
  } finally {
    releasePausedSummary();
    await initialPreparation.catch(() => undefined);
  }
  const beforeExplicitResume = requests.length;
  await memory.initialize(pauseChat.id);
  assert(
    requests.slice(beforeExplicitResume).some((request) => request.kind === "summary"),
    "explicit Resume finishes unfinished summaries",
  );
  assert.equal((await memory.status(pauseChat.id)).job.status, "ready");
  assert.equal((await memory.status(pauseChat.id)).job.paused, false);
  await memory.cancel(pauseChat.id);
  await memory.reindex(pauseChat.id);
  assert.equal((await memory.status(pauseChat.id)).job.paused, false, "explicit reindex resumes processing");
  await memory.cancel(pauseChat.id);
  await memory.reset(pauseChat.id);
  assert.notEqual((await memory.status(pauseChat.id)).job.paused, true, "reset clears the user pause");

  const switchChat = await chats.create({
    name: "Normal recall cancels preparation",
    mode: "roleplay",
    characterIds: [],
    connectionId: connection!.id,
  });
  assert(switchChat);
  await chats.createMessagesBatch(switchChat.id, [
    { role: "user", content: "Keep the compass promise while switching recall." },
    { role: "assistant", content: "SCENE_CHANGE The journey resumes." },
  ]);
  await memory.updateSettings(switchChat.id, { enabled: true, summaryBudgetTokens: 512 });
  const switchSource = await chats.listMessages(switchChat.id);
  let signalSwitchSummary!: () => void;
  let releaseSwitchSummary!: () => void;
  const switchSummaryEntered = new Promise<void>((resolve) => (signalSwitchSummary = resolve));
  const heldSwitchSummary = new Promise<void>((resolve) => (releaseSwitchSummary = resolve));
  beforeSummary = async () => {
    signalSwitchSummary();
    await heldSwitchSummary;
  };
  const runningBeforeSwitch = memory.initialize(switchChat.id);
  const cancelledBySwitch = assert.rejects(runningBeforeSwitch, /cancel|abort/iu);
  const switchApp = Fastify();
  switchApp.decorate("db", db);
  const { chatsRoutes } = await import("../../packages/server/src/routes/chats.routes.js");
  await switchApp.register(chatsRoutes, { prefix: "/api/chats" });
  try {
    await switchSummaryEntered;
    const realUpdate = db.update.bind(db);
    db.update = ((...args: Parameters<typeof db.update>) => {
      const builder = realUpdate(...args);
      const set = builder.set.bind(builder);
      builder.set = ((values: Record<string, unknown>) => {
        if (typeof values.metadata === "string" && JSON.parse(values.metadata).advancedMemory?.enabled === false) {
          throw new Error("Synthetic mode-write failure");
        }
        return set(values);
      }) as typeof builder.set;
      return builder;
    }) as typeof db.update;
    try {
      const failedSwitch = await switchApp.inject({
        method: "PATCH",
        url: `/api/chats/${switchChat.id}/metadata`,
        payload: { enableMemoryRecall: true },
      });
      assert.equal(failedSwitch.statusCode, 500, failedSwitch.body);
      assert.equal((await memory.status(switchChat.id)).settings.enabled, true);
      assert.equal(
        (await memory.status(switchChat.id)).job.status,
        "running",
        "a failed normal-mode write must not cancel the still-enabled worker",
      );
      await assert.rejects(memory.updateSettings(switchChat.id, { enabled: false }), /Synthetic mode-write failure/u);
      assert.equal(
        (await memory.status(switchChat.id)).job.status,
        "running",
        "a failed Advanced settings write must also preserve the worker",
      );
    } finally {
      db.update = realUpdate;
    }
    const switched = await switchApp.inject({
      method: "PATCH",
      url: `/api/chats/${switchChat.id}/metadata`,
      payload: { enableMemoryRecall: true },
    });
    assert.equal(switched.statusCode, 200, switched.body);
    await cancelledBySwitch; // Must finish before the blocked provider is released.
    const switchedStatus = await memory.status(switchChat.id);
    assert.equal(switchedStatus.settings.enabled, false);
    assert.equal(switchedStatus.job.status, "cancelled", "switching modes cancels instead of leaving an error");
    assert.equal(switchedStatus.job.error, null);
    assert.equal(JSON.parse((await chats.getById(switchChat.id))!.metadata).enableMemoryRecall, true);
    assert.deepEqual(await chats.listMessages(switchChat.id), switchSource);
  } finally {
    releaseSwitchSummary();
    await runningBeforeSwitch.catch(() => undefined);
    await switchApp.close();
  }

  const resetChat = await chats.create({
    name: "Reset during preparation",
    mode: "roleplay",
    characterIds: ["alice"],
    connectionId: connection!.id,
  });
  assert(resetChat);
  await chats.createMessagesBatch(resetChat.id, [
    { role: "user", content: "Keep this original compass promise." },
    { role: "assistant", content: "SCENE_CHANGE The journey resumes." },
  ]);
  const resetSettings = {
    ...DEFAULT_ADVANCED_MEMORY_SETTINGS,
    enabled: true,
    maxContextTokens: 16_384,
    summaryBudgetTokens: 512,
    knowledgeStarts: { alice: null },
  };
  await chats.patchMetadata(resetChat.id, { groupChatMode: "individual", advancedMemory: resetSettings });
  const beforeResetSource = await chats.listMessages(resetChat.id);
  const emptyArchivePrompt = await memory.prepare({
    chatId: resetChat.id,
    messages: beforeResetSource,
    audienceCharacterIds: ["alice"],
    budgetTokens: 1800,
    readOnly: true,
  });
  assert.deepEqual(emptyArchivePrompt.receipt.recordRevisions, {});
  await chats.updateMessageExtra(beforeResetSource.at(-1)!.id, {
    advancedMemoryReceipt: emptyArchivePrompt.receipt,
    unrelatedExtra: "preserve me",
  });
  const preservedResetSource = await chats.listMessages(resetChat.id);
  assert((await memory.status(resetChat.id)).latestReceipt);
  let signalResetSummary!: () => void;
  let releaseResetSummary!: () => void;
  let finishedResetSummary!: () => void;
  const resetSummaryEntered = new Promise<void>((resolve) => (signalResetSummary = resolve));
  const heldResetSummary = new Promise<void>((resolve) => (releaseResetSummary = resolve));
  const resetSummaryFinished = new Promise<void>((resolve) => (finishedResetSummary = resolve));
  beforeSummary = async () => {
    signalResetSummary();
    await heldResetSummary;
    finishedResetSummary();
  };
  const runningBeforeReset = memory.initialize(resetChat.id);
  const cancelledByReset = assert.rejects(runningBeforeReset, /reset|abort/iu);
  try {
    await resetSummaryEntered;
    assert.equal(
      (await memory.updateSettings(resetChat.id, { enabled: true })).job.status,
      "running",
      "idempotent Advanced enable must not cancel active preparation when normal recall is already off",
    );
    const resetting = memory.reset(resetChat.id);
    await assert.rejects(memory.initialize(resetChat.id), /being reset/iu);
    const resetResult = await resetting;
    await cancelledByReset;
    assert.equal(resetResult.job.status, "idle", "old cancellation cleanup cannot overwrite reset progress");
    assert.deepEqual(resetResult.settings, resetSettings, "reset preserves confirmed character knowledge boundaries");
    assert.equal(resetResult.latestReceipt, undefined);
    await assert.rejects(
      memory.validatePrepared(resetChat.id, preservedResetSource, emptyArchivePrompt.receipt),
      /settings or summary corrections changed/iu,
      "reset also invalidates cached prompts that depended on no archive record",
    );
  } finally {
    releaseResetSummary();
    await runningBeforeReset.catch(() => undefined);
  }
  await resetSummaryFinished;
  assert.deepEqual(
    await db.select().from(advancedMemoryRecords).where(eq(advancedMemoryRecords.chatId, resetChat.id)),
    [],
    "a cancelled provider response cannot recreate records or partial summary work after reset",
  );
  assert.deepEqual(await chats.listMessages(resetChat.id), preservedResetSource);
  assert.equal((await memory.status(resetChat.id)).job.status, "idle");
  await memory.initialize(resetChat.id);
  const restarted = await memory.status(resetChat.id);
  assert.equal(restarted.job.status, "ready", "Prepare can rebuild memory from the untouched chat after reset");
  assert(restarted.records.some((record) => record.kind === "scene" && record.content));
  assert(restarted.records.some((record) => record.kind === "excerpt"));
  assert.deepEqual(await chats.listMessages(resetChat.id), preservedResetSource);
  const backlog = await chats.create({
    name: "Initial history behind a recent-only scene checkpoint",
    mode: "roleplay",
    characterIds: [],
    connectionId: connection!.id,
  });
  assert(backlog);
  await memory.updateSettings(backlog.id, { enabled: true, maxContextTokens: 16_384, summaryBudgetTokens: 512 });
  await chats.createMessagesBatch(
    backlog.id,
    Array.from({ length: 120 }, (_, index) => ({
      role: "user" as const,
      content: `${[30, 75, 117].includes(index) ? "SCENE_CHANGE " : ""}Historical event ${index}. ${"The journey continued. ".repeat(20)}`,
    })),
  );
  const backlogSource = await chats.listMessages(backlog.id);
  const recentCheck = await memory.getSceneCheck(backlog.id);
  assert(recentCheck);
  assert(
    await memory.commitSceneCheck(backlog.id, recentCheck, { ends: [{ messageNumber: 117 }] }),
    "the recent-only checkpoint must be committed before backfill",
  );
  const beforeBackfill = requests.length;
  const pauseBackfill = new AbortController();
  await assert.rejects(
    memory.initialize(backlog.id, {
      signal: pauseBackfill.signal,
      onProgress: (event) => {
        if (event.stage === "classifying" && event.completed > 0) pauseBackfill.abort(new Error("pause backfill"));
      },
    }),
  );
  await memory.initialize(backlog.id);
  await memory.prepare({ chatId: backlog.id, messages: backlogSource, audienceCharacterIds: [], budgetTokens: 50000 });
  const historicalCalls = requests.slice(beforeBackfill).filter((request) => request.kind === "classify");
  assert(historicalCalls.length > 1, "initial history spans multiple provider context windows");
  assert(backlogSource.every((message) => historicalCalls.some((request) => request.text.includes(message.id))));
  assert.deepEqual(
    (await memory.status(backlog.id)).records
      .filter((record) => record.kind === "scene" && record.status === "closed")
      .map((record) => [record.startIndex, record.endIndex]),
    [
      [1, 30],
      [31, 75],
      [76, 117],
    ],
    "recent-only closed scaffolds must not cause initial preparation to skip older scenes",
  );
  console.info(
    "Advanced Memory core regression passed (800 messages, resume, scope, compaction, previews, corrections and races).",
  );
} finally {
  beforeSummary = null;
  await db._fileStore.close();
  await new Promise<void>((resolve) => server.close(() => resolve()));
  rmSync(directory, { recursive: true, force: true });
}
