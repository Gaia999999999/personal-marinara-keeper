# Focused read-only review: native-assisted Keeper retention

This package completes the lead's disposition of the corrected Host Save-Binding audit and independently tests the separate native-memory architecture suggestion. **The corrected scoped F2 PASS is accepted. Do not reopen or re-audit that unchanged patch unless you find a concrete new defect.**

Read DISPOSITION.md, PROPOSED_RETENTION_CONTRACT.md and VERIFICATION.json. The exact original host candidate is included for reference. No earlier attachment or private campaign export is needed for this review.

## Your task

Audit the proposed retention boundary, not a fictional implemented archive. No repository edits, installation, live/provider calls, settings changes, seed imports or campaign advancement.

1. Verify the manifest and run `python3 verify-preflight.py`. Separate execution, source inspection and supplied logs. For Node probes, use README.md and a throwaway pinned host checkout with dependencies; state unavailable checks plainly.
2. Independently confirm or challenge the demonstrated boundary: optional native recall can be absent; native summaries are not exact immutable Keeper records; native transfer covers its own identities; v2.5.1 does not contain this local F2 patch.
3. Challenge the lead's chosen direction: active causal/knowledge pins in Keeper, native optional episodic recall, and **exact accepted native Keeper snapshots** as the first cold-store design to investigate. Is there a concrete counterexample that makes this reuse unsafe or more complex than a separate content-addressed store? Trace the actual host behavior; do not assume existing run rows are immutable.
4. Determine which host contracts must exist before any row can leave active state. Focus on accepted-root selection, deletion/overwrite, required pre-prose dependency resolution, atomic publication receipts, audience preservation, and native export/import/branch lineage. Do not claim the F2 fix already provides these.
5. Check that “active” includes quiet cast, unresolved obligations, negated/conditional constraints, standing author corrections and reasons governing relationships. Scene age, completion labels, matching holders or a later rescue must not silently erase them.
6. Give **PROCEED TO IMPLEMENTATION / REVISE CONTRACT / BLOCKED BY A SPECIFIC HOST PREREQUISITE** with narrow justified changes and executable or source-traced counterexamples. A design verdict is not runtime, migration, installation, capacity or live-play clearance.

Do not recommend raising caps, deleting history, treating summaries as authority, broad model-authored retire, fuzzy recovery, or automatic retry. Do not invent a new record list or assert runtime coverage from inspected transcripts. The authoritative host proof here is c565014 plus the reviewed F2 patch; v2.5.1 is targeted read-only source evidence, not a tested port.

The owner returns your report to the lead for disposition. No owner play is requested by this package.
