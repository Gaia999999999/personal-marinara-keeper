import assert from "node:assert/strict";
import { mkdtempSync, readdirSync, readFileSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";

const dir = mkdtempSync(join(tmpdir(), "marinara-durable-checkpoint-"));
process.env.DATA_DIR = dir;
process.env.FILE_STORAGE_DIR = join(dir, "storage");
process.env.NODE_ENV = "production";
process.env.LOG_LEVEL = "silent";
const { createFileNativeDB } = await import("../../packages/server/src/db/file-backed-store.js");
const { createChatsStorage } = await import("../../packages/server/src/services/storage/chats.storage.js");
const { createAgentsStorage } = await import("../../packages/server/src/services/storage/agents.storage.js");
const { agentRuns, messages } = await import("../../packages/server/src/db/schema/index.js");
let failNext = false;
let writeFailures = 0;
const db = await createFileNativeDB({
  beforeTableWrite: (table) => {
    if (failNext && table.startsWith("agent_runs/")) {
      failNext = false;
      writeFailures++;
      throw new Error("Injected real file-write failure");
    }
  },
});
const agents = createAgentsStorage(db);
const chats = createChatsStorage(db);
try {
  const chat = await chats.create({ name: "Synthetic durable storage", mode: "roleplay", characterIds: [] });
  const agent = await agents.create({
    name: "Synthetic checkpoint",
    type: "durable-fixture",
    phase: "post_processing",
    promptTemplate: "fixture",
  });
  await db
    .insert(messages)
    .values({
      id: "checkpoint-message",
      chatId: chat.id,
      role: "assistant",
      content: "Fixture",
      createdAt: "2026-10-21T00:00:00.000Z",
    });
  await chats.addSwipe("checkpoint-message", "Fixture", true);
  function input(text: string) {
    return {
      agentConfigId: agent.id,
      chatId: chat.id,
      messageId: "checkpoint-message",
      swipeIndex: 0,
      requireDurable: true,
      result: {
        agentId: agent.id,
        agentType: agent.type,
        type: "context_injection" as const,
        data: { text, "agent-context": null },
        tokensUsed: 0,
        durationMs: 0,
        success: true,
        error: null,
      },
    };
  }
  await agents.saveRun(input("ACCEPTED_BASELINE"));
  const before = await db.select().from(agentRuns);
  const diskRows = () =>
    readdirSync(join(db._fileStore.rootDir, "tables", "agent_runs"))
      .filter((name) => name.endsWith(".json"))
      .flatMap((name) => JSON.parse(readFileSync(join(db._fileStore.rootDir, "tables", "agent_runs", name), "utf8")));
  assert.deepEqual(diskRows(), before, "durable save returns only after bytes reach disk");
  failNext = true;
  await assert.rejects(agents.saveRun(input("REJECTED_NEW_RUN")), /Injected real file-write failure/);
  assert.equal(writeFailures, 1);
  assert.deepEqual(await db.select().from(agentRuns), before, "failed flush rolls back memory");
  await db._fileStore.flush();
  assert.deepEqual(diskRows(), before, "failed proposal cannot reappear on later flush");
  failNext = true;
  await assert.rejects(
    agents.saveRun({ ...input("REJECTED_UPSERT"), runId: before[0].id }),
    /Injected real file-write failure/,
  );
  assert.deepEqual(await db.select().from(agentRuns), before, "failed upsert preserves previous accepted bytes");
  await db._fileStore.flush();
  assert.deepEqual(diskRows(), before);
  for (const swipeIndex of [-1, 0.5, NaN, Infinity, Number.MAX_SAFE_INTEGER + 1, 99]) {
    await assert.rejects(agents.saveRun({ ...input("INVALID"), swipeIndex }));
  }
  await assert.rejects(agents.saveRun({ ...input("FOREIGN"), chatId: "foreign" }));
  await assert.rejects(agents.saveRun({ ...input("MISSING"), messageId: "missing" }));
  assert.deepEqual(await db.select().from(agentRuns), before);
  await agents.saveRun(input("RECOVERED"));
  const recovered = await db.select().from(agentRuns);
  assert.equal(recovered.length, 2);
  assert.deepEqual(diskRows(), recovered);
  await db._fileStore.close();
  const reopened = await createFileNativeDB();
  try {
    assert.deepEqual(await reopened.select().from(agentRuns), recovered, "fresh open sees only accepted checkpoints");
  } finally {
    await reopened._fileStore.close();
  }
  console.log(
    "PASS: real file-write failure, insert/upsert rollback, later flush, fresh open, eight durable target rejection controls, recovery",
  );
} finally {
  failNext = false;
  await db._fileStore.close();
  assert.ok(dir.replaceAll("\\", "/").startsWith(tmpdir().replaceAll("\\", "/") + "/marinara-durable-checkpoint-"));
  rmSync(dir, { recursive: true, force: true });
}
