// F1 red/green demonstration using each version's real source pipeline.
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
import assert from 'node:assert/strict';
const here=path.dirname(fileURLToPath(import.meta.url)),results=[];
for(const [dir,version,expected] of [['reviewedRc1','4.1.7-rc.1',false],['candidate','4.1.7-rc.2',true]]){
 const root=path.join(here,dir),{makeRuntime,PACKAGE_ID}=await import(pathToFileURL(path.join(root,'package/server.mjs'))),{baseline,context}=await import(pathToFileURL(path.join(root,'tests/fixtures.mjs')));
 const prompt=fs.readFileSync(path.join(root,`Keeper_Prompt_v${version}.txt`),'utf8'),section=prompt.split('COMPLETE AUTHOR CORRECTION EXAMPLE')[1].split('INITIALIZATION AND AUDIENCE EXAMPLES')[0];
 const declared=[...section.matchAll(/^(E6[1-4]): "([^\n]+)"$/gm)].map(m=>({id:m[1],text:m[2]}));
 const source=section.match(/^Example source: (.+)$/m)?.[1]??'<ooc>'+declared.map(s=>s.text).join(' ')+'</ooc>';
 const p=await makeRuntime().prepareContext({agent:{id:'chunk-audit',type:PACKAGE_ID,phase:'post_processing',settings:{contextSize:24,jsonContextOutput:false}},context:{...context(source,'Acknowledged.'),loadPreviousOutput:async()=>baseline()}});assert(!p.blocked,p.blocked);
 const actual=p.sources.filter(s=>s.kind==='author'&&s.current),matches=JSON.stringify(actual.map(s=>s.text))===JSON.stringify(declared.map(s=>s.text));assert.equal(matches,expected);
 const t=JSON.parse(section.split('\n').find(line=>line.startsWith('{"turn"')));
 const shared=t.access[0].evidence.filter(id=>t.changes[1].evidence.includes(id));
 if(expected){assert.deepEqual(shared,['E62']);assert.equal(new Set(actual.map(s=>s.origin)).size,1);}
 results.push({version,declaredCount:declared.length,realCount:actual.length,realLengths:actual.map(s=>s.text.length),declaredSpansMatchRealPipeline:matches,sharedCustodyAndPlanIds:shared});
}
console.log(JSON.stringify({allExpectedResultsObserved:true,results,scope:'rc.1 symbolic example mismatch reproduced; rc.2 real-source example and shared span confirmed. No model call.'},null,2));
