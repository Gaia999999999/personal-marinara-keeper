import {buildSources,hash} from './sources.mjs';
import {requireValid,applyDelta,baselineHash} from './keeper-core.mjs';

export const PACKAGE_ID='personal-character-memory-v4-1';
const PROTOCOL='keeper-v41-runtime-1';
export function readSeed(notes) {
  const matches=[...String(notes??'').matchAll(/\[KEEPER_V41_SEED\]([\s\S]*?)\[\/KEEPER_V41_SEED\]/g)];
  if(matches.length>1) throw new Error('Keeper v4.1: multiple seeds; select one audited starting point.');
  return matches.length ? requireValid(matches[0][1].trim()) : null;
}
async function loadBase(agent,context) {
  if(typeof context.loadPreviousOutput!=='function') throw new Error('Keeper v4.1: host selected-history output API is required.');
  const previous=await context.loadPreviousOutput(agent.id);
  if(previous!=null) return {baseline:requireValid(previous),origin:'previous'};
  const seed=readSeed(context.authorNotes);
  if(seed) return {baseline:seed,origin:'seed'};
  if(String(context.chatSummary??'').trim() || (context.recentMessages??[]).filter(m=>m.role==='user').length>1) {
    throw new Error('Keeper v4.1: existing story needs an audited v4.1 seed. The new package does not silently migrate v4/Redline memory.');
  }
  return {baseline:null,origin:'fresh'};
}
export function makeRuntime() {
  return {
    async prepareContext({agent,context}) {
      if(agent.type!==PACKAGE_ID || agent.phase!=='post_processing') throw new Error('Keeper v4.1: wrong package identity or phase.');
      if(agent.settings?.jsonContextOutput!==false) throw new Error('Keeper v4.1: JSON Context Output must be OFF.');
      const loaded=await loadBase(agent,context);
      const {sources,anchor}=buildSources(context,8);
      // The previous accepted reply may be outside the eight-message evidence window.
      // Preserve everything and explicitly mark missing coverage instead of rebuilding it.
      const gap=loaded.baseline && !sources.some(s=>s.id===loaded.baseline.anchor.reply_ref)
        ? {id:`window_${loaded.baseline.revision}`,detail:'Prior accepted reply is outside the available evidence window. Carry its state; intermediate changes are not certified.'} : null;
      return {protocol:PROTOCOL,agent_id:agent.id,chat_id:context.chatId,
        ...loaded,base_hash:baselineHash(loaded.baseline),anchor,sources,gap,
        budget:{used_characters:loaded.baseline?JSON.stringify(loaded.baseline).length:0,target_characters:16000,max_characters:22000,
          rows:Object.fromEntries(['cast','relations','ledger','plans','directives'].map(g=>[g,loaded.baseline?.[g]?.length??0]))},
        instruction:'Emit the bounded character_memory.delta.v4.1 transaction. The runtime merges and validates it before publishing ONE complete shared checkpoint. Do not echo baseline, sources or reasoning.'};
    },
    async finalizeResult({agent,context,preparedContext:prep,result}) {
      if(!result.success) return result;
      if(!prep || prep.protocol!==PROTOCOL || prep.agent_id!==agent.id || prep.chat_id!==context.chatId || agent.type!==PACKAGE_ID || agent.phase!=='post_processing') {
        throw new Error('Keeper v4.1: preparation/identity missing or mismatched; refusing unchecked output.');
      }
      if(result.agentId!==agent.id || result.type!=='context_injection' || agent.settings?.jsonContextOutput!==false) {
        throw new Error('Keeper v4.1: wrong result identity, type, or JSON mode.');
      }
      const latest=await loadBase(agent,context);
      const current=buildSources(context,8);
      if(baselineHash(latest.baseline)!==prep.base_hash || latest.origin!==prep.origin || current.anchor.turn_key!==prep.anchor.turn_key || hash(current.sources)!==hash(prep.sources)) {
        throw new Error('Keeper v4.1: baseline/evidence changed during generation; retry against the selected story.');
      }
      const state=applyDelta(result.data,prep);
      return {...result,data:{text:JSON.stringify(state)}};
    }
  };
}
export async function activate({api}) {return api.registerService(`agent-runtime:${PACKAGE_ID}`,makeRuntime());}
