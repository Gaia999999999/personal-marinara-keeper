import assert from 'node:assert/strict';
import path from 'node:path';
import { pathToFileURL } from 'node:url';

// Evidence-only probe. Use an isolated pinned host checkout, never an owner's data directory.
const root = process.env.HOST_ROOT;
assert(root, 'Set HOST_ROOT to the pinned isolated host checkout.');
process.env.NODE_ENV = 'test';
process.env.MARINARA_LITE = 'true';
process.env.LOG_LEVEL = 'silent';
const host = relative => import(pathToFileURL(path.join(root, relative)).href);
const { prepareAdvancedMemoryContext } = await host('packages/server/src/services/generation/advanced-memory-context.ts');
const { createAdvancedMemoryPlacement } = await host('packages/server/src/services/prompt/advanced-memory-prompt.ts');
const { recallLongTermMemory } = await host('packages/server/src/services/generation/long-term-memory-runtime.ts');
const { registerCapabilityService } = await host('packages/server/src/services/capability-packages/capability-service-registry.service.ts');
const { advancedMemorySourceFingerprint } = await host('packages/server/src/services/advanced-memory.ts');
const { remapAdvancedMemoryMetadata } = await host('packages/server/src/services/advanced-memory-transfer.ts');

const results = [];
const source = [{ id: 'current-user', role: 'user', content: 'We reach the next doorway.', activeSwipeIndex: 0 }];
const placements = [createAdvancedMemoryPlacement('recalled_scenes', 'xml')];
const active = 'ACTIVE_PIN: Nora remains wary because an earlier abandonment is unresolved. A later rescue can coexist with gratitude; it does not establish full trust.';
const historic = 'ARCHIVED_EVENT: The bridge incident led to the earlier abandonment.';
let recalled = historic;
// Only memory selection is stubbed. The real complete-request assembler decides whether to omit recall.
const service = {
  async prepare() {
    return {
      messageIds: ['current-user'], chatSummary: null, currentSceneSummary: null,
      recalledScenes: recalled, recalledMessages: null, recalledRecordIds: ['historical-record'],
      receipt: {
        sourceFingerprint: 'synthetic', policyRevision: 'synthetic',
        recordRevisions: { 'historical-record': 'synthetic-revision' },
        estimatedTokensBefore: 0, estimatedTokensAfter: 0, budgetTokens: 3000,
        boundaryMessageId: null, checkpointId: null,
        recalledSceneIds: ['historical-scene'], recalledMessageIds: [], reasons: [],
      },
    };
  },
};
const input = {
  service, chatId: 'synthetic-proof', settings: { maxContextTokens: 3000 },
  sourceMessages: source,
  messages: [
    { role: 'system', content: active + '\n' + placements[0].token, contextKind: 'prompt' },
    ...source.map(m => ({ ...m, contextKind: 'history' })),
  ],
  placements, audienceCharacterIds: [], maxContext: 4000, maxTokens: 512,
  toProviderMessages: messages => messages,
};
const small = await prepareAdvancedMemoryContext(input);
assert(JSON.stringify(small.providerMessages).includes(historic));
assert(JSON.stringify(small.providerMessages).includes(active));
results.push('small optional historical recall is included alongside a fixed active pin');

recalled = historic.repeat(3000);
const tight = await prepareAdvancedMemoryContext(input);
assert(!JSON.stringify(tight.providerMessages).includes('ARCHIVED_EVENT:'));
assert(JSON.stringify(tight.providerMessages).includes(active));
assert.deepEqual(tight.receipt.recalledSceneIds, []);
assert.deepEqual(tight.receipt.recordRevisions, {});
assert(tight.receipt.reasons.includes('Optional recall omitted to fit the complete formatted request.'));
results.push('real request assembly succeeds without optional history under budget pressure; fixed active pin survives');

const ltmInput = { chatId: 'synthetic-proof', chatMode: 'roleplay', characterIds: [], messages: [], debugMode: false };
assert.equal(await recallLongTermMemory(ltmInput), null);
results.push('absent LTM service returns no recall without blocking');
let throwRecall = false;
const unregister = registerCapabilityService('long-term-memory:runtime', {
  async recall() { if (throwRecall) throw Error('synthetic unavailable service'); return { text: historic }; },
  async recordPromptAccepted() {},
});
try {
  assert.equal((await recallLongTermMemory(ltmInput)).text, historic);
  throwRecall = true;
  assert.equal(await recallLongTermMemory(ltmInput), null);
  results.push('real LTM wrapper includes a successful result and continues with null after service failure');
} finally { unregister(); }

assert.notEqual(
  advancedMemorySourceFingerprint(source),
  advancedMemorySourceFingerprint([{ ...source[0], activeSwipeIndex: 1 }]),
);
results.push('native memory fingerprints distinguish identical-text sibling swipe selection');

const metadata = {
  advancedMemory: { enabled: true, knowledgeStarts: { nora: 'old-message' }, knowledgeConfirmed: true },
  arbitraryArchive: { sourceMessageId: 'old-message' },
};
const remapped = remapAdvancedMemoryMetadata(metadata, new Map([['old-message', 'new-message']]), ['nora']);
assert.equal(remapped.advancedMemory.knowledgeStarts.nora, 'new-message');
assert.equal(remapped.advancedMemory.knowledgeConfirmed, false);
assert.equal(remapped.arbitraryArchive.sourceMessageId, 'old-message');
assert.equal(metadata.advancedMemory.knowledgeStarts.nora, 'old-message');
results.push('native metadata transfer remaps its own supported anchors, not arbitrary external archive references');

console.info(JSON.stringify({ pass: true, groups: results.length, results, paidProviderCalls: 0,
  limits: 'Synthetic prepared-memory/service fixtures; actual host formatting, fallback, fingerprint and remapping code. No semantic extraction, live campaign, or archive-retirement proof.' }, null, 2));
