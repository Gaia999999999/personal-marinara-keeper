# Scope and qualifications

This public edition changes packaging and local-path presentation only. Candidate, regression, F2 and patch bytes retain their recorded identities. Existing runtime test results are supplied evidence; no implementation or expensive regression tests were repeated for this package.

The prior full host check and ten relevant suites passed. The existing tracker-sections failure reproduced identically on baseline and candidate at WORLD_SENTINEL placement, line 201 (caller line 239); this remains a limitation, not a pass. Early environment failures remain visible in the labeled evidence. Fresh reconstruction and source/hash/manifest checks for public packaging are not additional runtime passes.

Durable opt-in covers successful capability results with registered finalizers on ordinary post-processing and manual retry. Other saveRun callers/effects, pre-generation injection caches, illustrator/built-in lorebook contracts, immutable history, deletion/reindexing, cold retirement, recall, portability, and multi-store atomicity remain outside this repair. Existing storage rollback is inherited; power-loss/hardware durability and persistent disk-plus-rollback failure are not certified.

The original full audit ZIP and local source checkpoint are unchanged and remain the original Argon handoff. The compact public edition references the pinned upstream archive rather than embedding it; reproduction therefore requires that exact public download or verified cached bytes and dependency registry/cache access. It omits the supplied independent report and unchanged native ZIP as unnecessary public payloads, retaining relevant source identities.

No private campaign exports or real credentials are intended or included. Account/path redaction does not turn supplied logs into fresh executions or prove candidate correctness. No browser/manual play, owner installation, paid providers, upstream CI/CodeRabbit, merge, promotion, migration or independent audit acceptance is claimed. The independent Argon engineering gate remains pending.
