from pathlib import Path
import hashlib,json,sys
root=Path(__file__).resolve().parent;host=Path(sys.argv[1]).resolve();manifest=json.loads((root/'CANDIDATE_FILES.json').read_text())
for name,row in manifest.items():
 p=host/name
 if row['baseSHA256'] is None:
  if p.exists():raise SystemExit('Existing new-file target: '+name)
 elif not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=row['baseSHA256']:raise SystemExit('Wrong baseline: '+name)
 if hashlib.sha256((root/'candidate'/name).read_bytes()).hexdigest()!=row['candidateSHA256']:raise SystemExit('Corrupt candidate: '+name)
for name in manifest:
 p=host/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((root/'candidate'/name).read_bytes())
print('Applied verified source candidate; no user data touched.')
