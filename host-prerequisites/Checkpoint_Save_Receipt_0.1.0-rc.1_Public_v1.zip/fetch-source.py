"""Explicitly download the pinned public upstream source; verify before saving."""
import argparse
import hashlib
import json
from pathlib import Path
import urllib.request

parser = argparse.ArgumentParser()
parser.add_argument('destination', type=Path)
args = parser.parse_args()
root = Path(__file__).resolve().parent
reference = json.loads((root/'PUBLIC_SOURCE_REFERENCES.json').read_text(encoding='utf-8'))['upstreamHost']
assert not args.destination.exists(), 'Destination must not exist.'
with urllib.request.urlopen(reference['downloadURL'], timeout=90) as response:
    data = response.read()
assert len(data) == reference['bytes'], 'Source archive size mismatch.'
assert hashlib.sha256(data).hexdigest() == reference['sha256'], 'Source archive SHA-256 mismatch.'
args.destination.parent.mkdir(parents=True, exist_ok=True)
with args.destination.open('xb') as stream:
    stream.write(data)
assert hashlib.sha256(args.destination.read_bytes()).hexdigest() == reference['sha256']
print('Pinned public host source downloaded and verified; no dependencies installed.')
